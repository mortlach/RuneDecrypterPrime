from __future__ import annotations
from typing import Tuple, Dict, Callable, Any

# Only import for type hints to avoid circular import at runtime
def _pull_N(kwargs: dict, default: int = 29) -> int:
    """Prefer explicit 'alphabet_size' or 'N' if provided by caller; otherwise default to 29."""
    if "alphabet_size" in kwargs and kwargs["alphabet_size"] is not None:
        return int(kwargs["alphabet_size"])
    if "N" in kwargs and kwargs["N"] is not None:
        return int(kwargs["N"])
    return default


def _make_vigenere_like_spec(**kwargs):
    """
    Best-effort creation of a Vigenère *wrapper*. If the runtime doesn't expose
    CipherSpec.wrapper(core="vigenere"), gracefully fall back to a generic user_map2
    that implements ct = (pt + k) mod N.
    """
    from rune_decrypter_prime.api.specs import CipherSpec  # lazy import
    # Try the official wrapper constructor if present
    wrapper_ctor = getattr(CipherSpec, "wrapper", None)
    if callable(wrapper_ctor):
        return wrapper_ctor(core="vigenere")

    # Fallback to a user_map2 that behaves like Vigenère.
    N = _pull_N(kwargs)
    def f(pt: int, k: int) -> int:
        return (pt + k) % N
    resolver_limit_raw = kwargs.get("resolver_limit", 8193)
    resolver_limit = 8193 if resolver_limit_raw is None else int(resolver_limit_raw)
    return CipherSpec.user_map2(
        function=f,
        N=N,
        degeneracy="forbid",
        resolver="first",
        per_pos_limit=29,
        resolver_limit=resolver_limit,
    )


# patche_old_ui/wrappers.py
from types import SimpleNamespace as _NS
from typing import Union as _Union

from rune_decrypter_prime.ciphers import registry as _cipher_registry

def cipher_instance(spec_or_name: _Union[str, object], **overrides):
    """
    Materialise a concrete cipher instance from a name or CipherSpec.
    - If a name is given, build a minimal spec with that name, apply overrides, then construct.
    - If a CipherSpec is given, apply overrides to a shallow copy and construct.

    Returns: live cipher object implementing encrypt(...)/decrypt(...).
    """
    if isinstance(spec_or_name, str):
        name = spec_or_name
        spec = _NS(name=name)
    else:
        spec = spec_or_name
        name = getattr(spec, "name", None)
        if not name:
            raise ValueError("CipherSpec must have a 'name' attribute")

    if overrides:
        base = _NS(**getattr(spec, "__dict__", {}))
        for k, v in overrides.items():
            setattr(base, k, v)
        spec = base

    ctor = _cipher_registry.get(name)  # uses  cipher registry
    return ctor(spec)


class by_name:
    """
    UX registry for cipher wrappers. Every handler accepts **kwargs so callers
    can pass extra params without signature explosions (e.g., key_len, default_key, N).
    """

    @staticmethod
    def cipher_instance(name: str, **overrides):
        return cipher_instance(name, **overrides)

    @classmethod
    def cipher(cls, name: str, **kwargs) -> "CipherSpec":
        spec, _ = cls._get(name, **kwargs)
        return spec

    @classmethod
    def cipher_with_key(
        cls, name: str, **kwargs
    ) -> Tuple["CipherSpec", "KeySpec | tuple[KeySpec, KeySpec] | None"]:
        return cls._get(name, **kwargs)

    # ---------------- registry core ---------------- #

    @classmethod
    def _get(cls, name: str, **kwargs) -> Tuple["CipherSpec", "KeySpec | tuple[KeySpec, KeySpec] | None"]:
        key = name.lower().strip()
        if key not in cls._REG:
            raise KeyError(f"Unknown cipher '{name}'. Available: {sorted(cls._REG)}")
        return cls._REG[key](**kwargs)

    # ---------------- handlers ---------------- #
    # IMPORTANT: Lazy-import patche_old_ui.api types inside handlers to avoid circular import.

    @staticmethod
    def _vigenere(*, key_len: int | None = None, default_key: bool = False, **kwargs: Any):
        """Vigenère wrapper → core 'vigenere' (or generic-map fallback)."""
        from rune_decrypter_prime.api.specs import KeySpec  # lazy
        spec = _make_vigenere_like_spec(**kwargs)
        key = KeySpec.repeat(len=key_len) if (default_key and key_len and key_len > 0) else None
        return spec, key

    @staticmethod
    def _caesar(*, key_len: int | None = None, default_key: bool = False, **kwargs: Any):
        """Caesar as period-1 Vigenère on the UX surface (uses same wrapper/fallback)."""
        from rune_decrypter_prime.api.specs import KeySpec  # lazy
        spec = _make_vigenere_like_spec(**kwargs)
        # ignore key_len; caesar is period 1
        key = KeySpec.repeat(len=1) if default_key else None
        return spec, key

    @staticmethod
    def _affine(
        *, key_len: int | None = None, default_key: bool = False,
        degeneracy: str = "forbid", resolver: str = "first", per_pos_limit: int = 29,
        resolver_limit: int = 8193, **kwargs: Any
    ):
        """
        Affine cipher: ct = (a * pt + b) mod N
        Implemented using generic user_map3 (pt, a, b) → ct.
        """
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec  # lazy
        N = _pull_N(kwargs)
        def f(pt: int, a: int, b: int) -> int:
            return (a * pt + b) % N

        spec = CipherSpec.user_map3(
            function=f, N=N, degeneracy=degeneracy, resolver=resolver,
            per_pos_limit=per_pos_limit, resolver_limit=resolver_limit,
        )
        if default_key:
            L = key_len if (key_len and key_len > 0) else 1
            return spec, (KeySpec.repeat(len=L), KeySpec.repeat(len=L))
        return spec, None

    @staticmethod
    def _xor_mod(
        *, key_len: int | None = None, default_key: bool = False,
        degeneracy: str = "allow", resolver: str = "expand_beam", per_pos_limit: int = 29,
        resolver_limit: int = 8193, **kwargs: Any
    ):
        """'xor-mod' cipher: ct = (pt ^ k) % N."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec  # lazy
        N = _pull_N(kwargs)
        def f(pt: int, k: int) -> int:
            return (pt ^ k) % N

        spec = CipherSpec.user_map2(
            function=f, N=N, degeneracy=degeneracy, resolver=resolver,
            per_pos_limit=per_pos_limit, resolver_limit=resolver_limit,
        )
        key = KeySpec.repeat(len=key_len) if (default_key and key_len and key_len > 0) else None
        return spec, key

    @staticmethod
    def _beaufort(
        *, key_len: int | None = None, default_key: bool = False,
        degeneracy: str = "forbid", resolver: str = "first", per_pos_limit: int = 29,
        resolver_limit: int = 8193, **kwargs: Any
    ):
        """Classical Beaufort: ct = (k - pt) mod N"""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec  # lazy
        N = _pull_N(kwargs)
        def f(pt: int, k: int) -> int:
            return (k - pt) % N

        spec = CipherSpec.user_map2(
            function=f, N=N, degeneracy=degeneracy, resolver=resolver,
            per_pos_limit=per_pos_limit, resolver_limit=resolver_limit,
        )
        key = KeySpec.repeat(len=key_len) if (default_key and key_len and key_len > 0) else None
        return spec, key

    @staticmethod
    def _variant_vigenere(
        *, key_len: int | None = None, default_key: bool = False,
        degeneracy: str = "forbid", resolver: str = "first", per_pos_limit: int = 29,
        resolver_limit: int = 8193, **kwargs: Any
    ):
        """Variant Vigenère (aka Beaufort-variant): ct = (pt - k) mod N"""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec  # lazy
        N = _pull_N(kwargs)
        def f(pt: int, k: int) -> int:
            return (pt - k) % N

        spec = CipherSpec.user_map2(
            function=f, N=N, degeneracy=degeneracy, resolver=resolver,
            per_pos_limit=per_pos_limit, resolver_limit=resolver_limit,
        )
        key = KeySpec.repeat(len=key_len) if (default_key and key_len and key_len > 0) else None
        return spec, key

    @staticmethod
    def _hill(*, key_n: int | None = None, default_key: bool = False, **kwargs: Any):
        """
        Hill cipher wrapper. 'key_n' is the matrix size n (key length = n*n).
        Falls back to n=2 if not provided.
        """
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec  # lazy import
        n = int(key_n) if key_n and key_n > 1 else 2
        N = _pull_N(kwargs)  # alphabet size, defaults to 29

        # Prefer a concrete core wrapper if present; otherwise just name it "hill".
        # api.py exposes an internal '_wrapper' builder, we reuse it for consistency.
        spec = getattr(CipherSpec, "_wrapper")(name="hill", core_name="hill", N=N)

        key = KeySpec.matrix(n=n, A=N) if default_key else None
        return spec, key


    # @staticmethod
    # def _columnar(
    #     *, key_len: int | None = None, default_key: bool = False,
    #     degeneracy: str = "forbid", resolver: str = "first", per_pos_limit: int = 1, **kwargs: Any
    # ):
    #     """Columnar transposition: values unchanged, positions permuted."""
    #     from rune_decrypter_prime.patche_old_ui.api import CipherSpec, KeySpec
    #     N = _pull_N(kwargs)
    #     def f(pt: int, k: int) -> int:
    #         return pt
    #     spec = CipherSpec.user_map2(function=f, N=N,
    #                                 degeneracy=degeneracy, resolver=resolver,
    #                                 per_pos_limit=per_pos_limit)
    #     # todo add this to other ciphers
    #     key = KeySpec.permutation(key_len) if (default_key and key_len and key_len > 0) else None
    #     return spec, key

    @staticmethod
    def _railfence(
        *,
        rails: int | None = None,
        min_rails: int | None = None,
        max_rails: int | None = None,
        default_key: bool = False,
        **kwargs: Any,
    ):
        """Railfence cipher: scalar key controlling the number of rails."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec

        spec = CipherSpec._wrapper(name="railfence", core_name="railfence")
        extras = spec.extra

        if rails is not None:
            fixed = int(rails)
            if fixed < 2:
                raise ValueError("railfence requires rails >= 2")
            extras["rails"] = fixed
            extras["min_rails"] = fixed
            extras["max_rails"] = fixed
        else:
            min_hint = max(2, int(min_rails) if min_rails is not None else 2)
            if max_rails is None:
                max_hint = max(min_hint, 8)
            else:
                max_hint = max(min_hint, int(max_rails))
            extras["min_rails"] = min_hint
            extras["max_rails"] = max_hint

        key = KeySpec.scalar(max_val=extras["max_rails"]) if default_key else None
        return spec, key

    @staticmethod
    def _autokey(
        *,
        seed_len: int | None = None,
        alphabet_size: int | None = None,
        default_key: bool = False,
        **kwargs: Any,
    ):
        """Autokey cipher: search over the seed of length `seed_len`."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec

        seed = int(seed_len) if seed_len is not None else 3
        if seed <= 0:
            raise ValueError("autokey requires seed_len >= 1")
        alphabet = int(alphabet_size) if alphabet_size is not None else 29
        if alphabet <= 0:
            raise ValueError("autokey alphabet_size must be positive")

        spec = CipherSpec._wrapper(name="autokey", core_name="autokey", N=alphabet)
        spec.extra["seed_length"] = seed
        spec.extra["alphabet_size"] = alphabet

        key = KeySpec.repeat(len=seed) if default_key else None
        return spec, key

    @staticmethod
    def _route(
        *, cols: int | None = None, default_key: bool = False, **kwargs: Any
    ):
        """Route cipher: permute column order in a grid."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec
        N = _pull_N(kwargs)
        def f(pt: int, k: int) -> int:
            return pt
        resolver_limit_raw = kwargs.get("resolver_limit", 8193)
        resolver_limit = 8193 if resolver_limit_raw is None else int(resolver_limit_raw)
        spec = CipherSpec.user_map2(
            function=f, N=N,
            degeneracy="forbid", resolver="first",
            per_pos_limit=29, resolver_limit=resolver_limit,
        )
        #key = KeySpec.permutation(cols) if (default_key and cols and cols > 0) else None
        key = KeySpec.permutation(len=cols) if (default_key and cols and cols > 0) else None
        return spec, key

    @staticmethod
    def _double_transposition(
        *, key_len1: int | None = None, key_len2: int | None = None,
        default_key: bool = False, **kwargs: Any
    ):
        """Double transposition: two permutations applied in sequence."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec
        N = _pull_N(kwargs)
        def f(pt: int, k: int) -> int:
            return pt
        resolver_limit_raw = kwargs.get("resolver_limit", 8193)
        resolver_limit = 8193 if resolver_limit_raw is None else int(resolver_limit_raw)
        spec = CipherSpec.user_map2(
            function=f, N=N,
            degeneracy="forbid", resolver="first",
            per_pos_limit=29, resolver_limit=resolver_limit,
        )
        if default_key and key_len1 and key_len2:
            return spec, (KeySpec.permutation(key_len1), KeySpec.permutation(key_len2))
        return spec, None

    @staticmethod
    def _blockperm(
        *, block_size: int | None = None, default_key: bool = False, **kwargs: Any
    ):
        """Block permutation cipher: permute letters inside fixed-size blocks."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec
        N = _pull_N(kwargs)
        def f(pt: int, k: int) -> int:
            return pt
        resolver_limit_raw = kwargs.get("resolver_limit", 8193)
        resolver_limit = 8193 if resolver_limit_raw is None else int(resolver_limit_raw)
        spec = CipherSpec.user_map2(
            function=f, N=N,
            degeneracy="forbid", resolver="first",
            per_pos_limit=29, resolver_limit=resolver_limit,
        )
        #key = KeySpec.permutation(block_size) if (default_key and block_size and block_size > 0) else None
        key = KeySpec.permutation(len=block_size) if (default_key and block_size and block_size > 0) else None
        return spec, key

    @staticmethod
    def _foursquare(
        *, default_key: bool = False, **kwargs: Any
    ):
        """Four-square cipher: two keyword squares (two permutations of 25)."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec
        N = _pull_N(kwargs)
        def f(p1: int, p2: int, k1: list[int], k2: list[int]) -> tuple[int,int]:
            return (p1, p2)
        resolver_limit_raw = kwargs.get("resolver_limit", 8193)
        resolver_limit = 8193 if resolver_limit_raw is None else int(resolver_limit_raw)
        spec = CipherSpec.user_map3(
            function=f, N=N,
            degeneracy="allow", resolver="expand_beam",
            per_pos_limit=29, resolver_limit=resolver_limit,
        )
        if default_key:
            return spec, (KeySpec.permutation(len=25), KeySpec.permutation(len=25))
        return spec, None

    @staticmethod
    def _columnar(
        *, key_len: int | None = None, key_length: int | None = None,
        default_key: bool = False, **kwargs: Any
    ):
        """
        Columnar transposition wrapper. Accepts either `key_len` or `key_length`
        so callers can provide the permutation width irrespective of the alias.
        The resolved length is stored in `spec.extra` for direct cipher_instance()
        use (encryption previews/tests) where no CipherConfig exists yet.
        """
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec

        spec = CipherSpec._wrapper(name="columnar", core_name="columnar")
        cols = key_length if key_length else key_len
        if cols is not None:
            cols = int(cols)
            if cols > 0:
                if cols > 255:
                    raise ValueError("columnar requires columns <= 255 (uint8 key limit)")
                spec.extra["key_length"] = cols
        key = None
        if default_key and cols and cols > 0:
            key = KeySpec.permutation(len=cols)
        return spec, key

    @staticmethod
    def _mono(*, key_len: int | None = None, default_key: bool = False, **kwargs: Any):
        """
        Monoalphabetic substitution (permutation of N symbols).
        UX wrapper that targets the core 'substitution' cipher.
        """
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec  # lazy
        # Reuse the generic wrapper hook just like _columnar does
        spec = CipherSpec._wrapper(name="substitution", core_name="substitution")
        # For mono, a “key” is a permutation of the alphabet (length = N)
        if default_key:
            N = _pull_N(kwargs)
            L = key_len if (key_len and key_len > 0) else N
            return spec, KeySpec.permutation(len=L)
        return spec, None

    @staticmethod
    def _periodic_substitution(
        *,
        period: int | None = None,
        alphabet_size: int | None = None,
        default_key: bool = False,
        **kwargs: Any,
    ):
        """Periodic substitution cipher wrapper."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec
        if period is None or int(period) <= 0:
            raise ValueError("periodic_substitution requires period >= 1")
        A = int(alphabet_size) if alphabet_size is not None else _pull_N(kwargs)
        if A <= 0:
            raise ValueError("periodic_substitution requires alphabet_size >= 1")

        spec = CipherSpec._wrapper(name="periodic_substitution", core_name="periodic_substitution", N=A)
        spec.extra["period"] = int(period)
        spec.extra["alphabet_size"] = int(A)

        key = KeySpec.periodic_substitution(period=int(period), alphabet_size=int(A)) if default_key else None
        return spec, key

    @staticmethod
    def _periodic_columnar(
        *,
        period: int | None = None,
        columns: int | None = None,
        cols: int | None = None,
        order: str | None = None,
        alphabet_size: int | None = None,
        default_key: bool = False,
        **kwargs: Any,
    ):
        """Periodic substitution + columnar transposition wrapper."""
        from rune_decrypter_prime.api.specs import CipherSpec, KeySpec
        if period is None or int(period) <= 0:
            raise ValueError("periodic_columnar requires period >= 1")
        col_raw = columns if columns is not None else cols
        if col_raw is None or int(col_raw) <= 0:
            raise ValueError("periodic_columnar requires columns >= 1")
        if int(col_raw) > 255:
            raise ValueError("periodic_columnar requires columns <= 255 (uint8 column limit)")
        A = int(alphabet_size) if alphabet_size is not None else _pull_N(kwargs)
        if A <= 0:
            raise ValueError("periodic_columnar requires alphabet_size >= 1")

        spec = CipherSpec._wrapper(name="periodic_columnar", core_name="periodic_columnar", N=A)
        spec.extra["period"] = int(period)
        spec.extra["columns"] = int(col_raw)
        spec.extra["alphabet_size"] = int(A)
        spec.extra["order"] = str(order or "sub_then_col")

        key = (
            KeySpec.periodic_columnar(period=int(period), columns=int(col_raw), alphabet_size=int(A))
            if default_key
            else None
        )
        return spec, key


    _REG: Dict[str, Callable[..., Tuple["CipherSpec", "KeySpec | tuple[KeySpec, KeySpec] | None"]]] = {
        "vigenere": _vigenere.__func__,
        "caesar": _caesar.__func__,
        "affine": _affine.__func__,
        "xor-mod": _xor_mod.__func__,
        "beaufort": _beaufort.__func__,
        "variant-vigenere": _variant_vigenere.__func__,
        "columnar": _columnar.__func__,
        "railfence": _railfence.__func__,
        "autokey": _autokey.__func__,
        "route": _route.__func__,
        "double_transposition": _double_transposition.__func__,
        "blockperm": _blockperm.__func__,
        "foursquare": _foursquare.__func__,
        "mono": _mono.__func__,
        "substitution": _mono.__func__,
        "periodic_substitution": _periodic_substitution.__func__,
        "periodic_columnar": _periodic_columnar.__func__,
        "hill": _hill.__func__,
    }
