"""Unified façade that selects the NumPy or Torch rune scorer at runtime."""
from __future__ import annotations
from typing import Any, Iterable, Sequence, Dict
import numpy as np

from rune_decrypter_prime.utils.runeglish import Runeglish
from rune_decrypter_prime.backends.xp import select_backend
from rune_decrypter_prime.core.types import Device

class UnifiedRuneScorer:
    """
    Unified scorer façade (config-first).

    Selection rule:
      - If cfg_cipher.device starts with "cuda" and CUDA is available -> Torch backend
      - Else -> NumPy backend

    Public contract (stable across backends):
      • score(pt: Iterable[int], wli) -> float
      • batch_score(pts: Sequence[Iterable[int]], wlis) -> np.ndarray
      • to_text(pt: Iterable[int]) -> str
      • telemetry() -> {"impl": "...", "device": "...", "dtype": "float32", ...}
    """

    def __init__(self, cfg_cipher, cfg_scorer_params, tables: Any | None = None):
        self.cfg_cipher = cfg_cipher
        self.cfg_scorer = cfg_scorer_params
        self._backend_name = "numpy"
        self._backend = None

        device_req = "auto"
        cfg_device = getattr(cfg_cipher, "device", None)
        if isinstance(cfg_device, str):
            device_req = (cfg_device or "auto").strip().lower() or "auto"
        elif isinstance(cfg_device, Device):
            device_req = cfg_device.value
        elif cfg_device is not None:
            device_req = str(cfg_device).strip().lower() or "auto"

        dev_name, _xp = select_backend(device_req)
        if dev_name == "cuda":
            from rune_decrypter_prime.scoring.torch_rune_scorer import RuneScorerTorch
            self._backend = RuneScorerTorch(cfg_cipher, cfg_scorer_params, tables=tables)
            self._backend_name = "torch"
        if self._backend is None:
            from rune_decrypter_prime.scoring.rune_scorer import RuneScorer
            self._backend = RuneScorer(cfg_cipher, cfg_scorer_params)
            self._backend_name = "numpy"

    # ---------- Public API (delegate) ----------

    def score(self, plaintext: Iterable[int], wli_windows=None) -> float:
        return float(self._backend.score(plaintext, wli_windows))

    def batch_score(self, pts: Sequence[Iterable[int]], wlis=None) -> np.ndarray:
        return np.asarray(self._backend.batch_score(pts, wlis), dtype=np.float32)

    def batch_score_with_raw(self, pts: Sequence[Iterable[int]], wlis=None) -> tuple[np.ndarray, np.ndarray]:
        if hasattr(self._backend, "batch_score_with_raw"):
            try:
                return self._backend.batch_score_with_raw(pts, wlis)
            except Exception:
                pass
        pct = np.asarray(self._backend.batch_score(pts, wlis), dtype=np.float32)
        return pct, pct.copy()

    def score_with_raw(self, plaintext: Iterable[int], wli_windows=None) -> tuple[float, float]:
        if hasattr(self._backend, "score_with_raw"):
            try:
                return self._backend.score_with_raw(plaintext, wli_windows)
            except Exception:
                pass
        pct = float(self._backend.score(plaintext, wli_windows))
        return pct, pct

    def supports_raw(self) -> bool:
        if hasattr(self._backend, "supports_raw"):
            try:
                return bool(self._backend.supports_raw())
            except Exception:
                return False
        return False

    def to_text(self, plaintext: Iterable[int]) -> str:
        # Prefer backend's to_text if available; else deterministic fallback.
        if hasattr(self._backend, "to_text"):
            try:
                return self._backend.to_text(plaintext)
            except Exception:
                pass
        # Fallback uses configured word-breaks if present
        wb = getattr(self.cfg_cipher, "wli_data", []) or []
        arr = np.asarray(plaintext, dtype=np.uint8).reshape(-1)
        # TODO(docs): Confirm correct fallback helper (Runeglish vs RuneAlphabet).
        return Runeglish.np_to_text(arr, wb)  # retain behaviour; name kept in comments

    # ---------- Telemetry (no guessing) ----------

    def telemetry(self) -> Dict[str, Any]:
        # Ask backend first
        if hasattr(self._backend, "telemetry"):
            try:
                tel = dict(self._backend.telemetry() or {})
            except Exception:
                tel = {}
        else:
            tel = {}

        # Normalise required keys
        tel.setdefault("impl", "torch" if self._backend_name == "torch" else "numpy")

        # Device preference: prefer backend-provided; else cfg/device or cpu
        if "device" not in tel or not tel["device"]:
            dev = getattr(self.cfg_cipher, "device", None)
            if isinstance(dev, Device):
                tel["device"] = dev.value
            elif isinstance(dev, str):
                tel["device"] = dev.strip().lower() or ("cuda" if self._backend_name == "torch" else "cpu")
            else:
                tel["device"] = "cuda" if self._backend_name == "torch" else "cpu"

        tel.setdefault("backend", self._backend_name)

        # DType is fixed float32 for both current backends
        tel.setdefault("dtype", "float32")
        return tel
