# `tutorials/v1/dev/Beginner_Tutorial_Run.py`

> Purpose: minimal "hello world" run that prints score and where to find telemetry.

Audience: Hands‑on
Time: 2-3 minutes
Outcome: Run a seeded example, locate `META.json` and `logs/app.jsonl`
Prereqs: Python 3.11+, repo installed (`pip install -e .[dev]`)

