# Tooling Recipes

This page captures repeatable commands for documentation QA and symbol maintenance. Each tool writes into the canonical `output/` tree so artefacts are easy to inspect and share.

---

## Docs Lint Runner

- **Command:** `python tools/docs_lint/run_docs_lint.py --label preflight`
- **What it does:** wraps `tools/docs_lint/docs_lint.py`, scans Markdown for syntax issues, broken links, and coverage gaps, then emits JSON + Markdown reports.
- **Outputs:** `output/tools/docs_lint/<timestamp>__docs_lint__<label>__<git>/docs_lint_report.json` and `.md`.
- **When to run:** before publishing docs or when updating references/links. Include the run folder in review attachments if lint fails in CI.

Notes:
- Use a descriptive `--label` (e.g., `--label release-notes`) to keep multiple runs organised.
- The runner automatically refreshes the symbol index before linting (writes to `tools/out/project_symbol_index.txt`). Pass `--no-refresh-symbols` if you want to reuse an existing index.
- It gracefully falls back to `nogit` if the repo hash is unavailable, so it works even in exported tarballs.

---

## Output Guard (CI-friendly)

- **Command:** `python tools/ci/validate_outputs.py -- <your-command>`
- **What it does:** runs a command and asserts that any created/modified files live under `output/`. Fails with a non-zero exit if writes occur elsewhere.
- **Examples:**
  - `python tools/ci/validate_outputs.py -- python tools/docs_lint/run_docs_lint.py --label audit`
  - `python tools/ci/validate_outputs.py -- python tools/repo_utils/make_release_src.py`
- **Outputs:** unchanged; this script only reports offenders. Use it to harden public tools before release.

Notes:
- Excludes typical VCS/venv/caches. It checks regular files by mtime/size delta.
- Prefer adding this step to CI around tooling invocations to prevent path leaks and keep artefacts under `output/`.

---

## Symbol Index (optional manual refresh)

- **Command:** `python tools/symbols/generate_symbol_index.py --root src/rune_decrypter_prime > tools/out/project_symbol_index.txt`
- **Purpose:** generates a lightweight class/function inventory consumed by the docs lint coverage step. Feed the resulting file into version control if the public API changes.
- **Output hygiene:** redirect stdout into `tools/out/project_symbol_index.txt` (or `output/share/...` if you prefer the timestamped tree) so the docs lint runner can read it automatically.
- **Customisation:** update `ROOT` inside `tools/symbols/generate_symbol_index.py` if your module layout changes.

The docs lint runner already refreshes the index for you; run this command manually only when you need a snapshot outside the lint workflow (e.g., pre-commit hooks or editor extensions).
