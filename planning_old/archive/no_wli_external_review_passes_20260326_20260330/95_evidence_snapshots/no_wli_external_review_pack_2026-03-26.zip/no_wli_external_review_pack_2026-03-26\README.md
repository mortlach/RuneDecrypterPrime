# No-WLI External Review Pack

Date assembled: 2026-03-26
Scope: `tools/benchmarks/periodic_sub_trans/no_wli`

## Purpose

This pack is for outside review of the no-WLI periodic substitution +
transposition solve programme.

It is intentionally documentation-heavy and source-light.
The goal is to make it easy for a reviewer to answer:

- what is already proven
- what is still weak or broken
- what experiments were run recently
- what the current live experiment is trying to learn
- where effort should go next

Every important claim in the curated docs points to concrete repo-relative
evidence.

## Recommended reading order

1. `01_current_state.md`
2. `02_recent_experiments_and_observations.md`
3. `03_pipeline_reliability_and_methodology.md`
4. `04_hypotheses_and_next_decisions.md`
5. `05_questions_for_external_review.md`
6. `06_evidence_index.md`

If a reviewer wants the raw working material after the short path, use:

- `appendix_science_run_log_2026-03-26.md`
- `appendix_pipeline_hardening_review_2026-03-25.md`
- `appendix_solve_integrity_plan_2026-03-21.md`
- `appendix_deep_research_report.md`
- `deep_research_pack_snapshot/`

## Pack contents

- `01_current_state.md`
  - best known capability
  - current weak-seed reality
  - active live experiment status
- `02_recent_experiments_and_observations.md`
  - concise evidence-backed timeline of the recent run history
- `03_pipeline_reliability_and_methodology.md`
  - what was wrong in the pipeline
  - what has been hardened
  - what is now genuinely proven vs still only likely
- `04_hypotheses_and_next_decisions.md`
  - the live questions currently being tested
  - what different outcomes would mean
- `05_questions_for_external_review.md`
  - explicit asks for outside help
- `06_evidence_index.md`
  - compact index of the main artifacts and why each one matters
- `evidence_snapshots/`
  - copied small summary artifacts and active run control/state files for
    reviewers who want the main evidence close to the pack

## What this pack says in one paragraph

The project has credible capability on the hard `p9/c3/l1000` anchor when it
reaches the right basin: recovered Stage-3 reached `0.771` and a clean live
Stage-3.5 proof reached `0.794` on `seed511`. The main current problem is not
"the whole system never works"; it is that weak seeds such as `211` and `411`
still fail to reach comparable basins reliably. Recent reliability work fixed
the live handoff-emission path and made the main pipeline contracts stricter,
but recent weak-seed experiments remain negative: `seed211` stayed at `0.574`
across several live variants, and a fixed-handoff `seed411` ranking probe
showed that small lexical-gate relaxations did nothing. The active short
comparison run therefore focuses on `seed411` only and compares a preserved
control against one materially broader Phase-C rescue package.
