# Hypotheses And Next Decisions

## Current working diagnosis

The strongest current diagnosis remains:

- the main regression is inside Stage-3 basin generation
- late signals are useful once a good family is reached
- weak seeds are still not reaching comparable basins often enough

Primary evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`

## What recent negative results already rule out

### On seed211

Recent live evidence already weakens these ideas:

- preserve-only lift
- recovery preset as currently configured
- Stage-3.5 as a default short-cycle lane

Evidence:

- preserve lane:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`
- recovery lane:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`
- Stage-3.5 proof lane:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`

### On seed411

The fixed-handoff ranking probe already weakens:

- tiny lexical-gate or tie-window relaxations as the main answer

Evidence:

- `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- all variants ended at `Resume Match 0.032`

## Why the completed v36 run matters

The completed run was deliberately narrow:

- control:
  - `stage3_preserve_tieband_probe_p9`
- candidate:
  - `lexical_phasec_rescue_wide_finish`
- seed:
  - `411`

Evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`

The candidate was meaningfully broader than the failed small-gate probe because
it changes several downstream search dimensions at once:

- `force_stage3_initial_keys = 128`
- `force_stage3_phaseb_top_n = 32`
- Phase-C rescue enabled
- broader rescue candidate pool
- longer rescue polish budget

Evidence:

- preset definition in:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - preset:
    - `lexical_phasec_rescue_wide_finish`

Observed result:

- control:
  - `best_match_ratio = 0.041`
  - `best_stage = "stage2_search"`
- broader candidate:
  - `best_match_ratio = 0.046`
  - `best_stage = "stage3_full_refine"`
- rescue nuance:
  - the candidate had rescue enabled, but `phaseC_rescue_ran = 0`
  - the final winner source was `phaseB_topk`

Interpretation:

- broader Phase-B / Phase-C family width helped a little on live `seed411`
- explicit rescue logic did not help directly in this run, because it never
  engaged
- this nudges the diagnosis toward family-width / family-survival effects rather
  than "the rescue lane itself is the missing fix"

## Decision tree after the completed v36 run

### What became weaker

- "another tiny downstream lexical tweak is probably enough"
- "explicit Phase-C rescue activation is already the main lever"

Why:

- the broader package only lifted `0.041 -> 0.046`
- the lift came without rescue actually running

### What became slightly stronger

- family-width / family-survival ideas inside late Stage-3 / Phase-B / Phase-C
- the structural suspicion that weak-seed families are present but too weakly
  carried forward

## The stronger strategic question for reviewers

The central external-review question is not:

- "which small tuning preset should we try next?"

It is:

- "given the current evidence, are we still looking in the right part of the
  system?"

The evidence currently favors this answer:

- the project should spend more decision energy on upstream basin reach than on
  adding more downstream ranking layers

That is not a certainty.
It is the current best-supported working diagnosis.

## What should probably not happen next

Based on the recent evidence, these would be low-confidence next steps:

- another broad overnight matrix with many weak-seed presets
- making Stage-3.5 a default live comparison lane
- another tiny lexical-threshold tweak on fixed `seed411`
- declaring general pipeline reliability from one successful canary

## What seems highest leverage after the current v36 run

If the review agrees with the current diagnosis, the highest-value next work is
likely one of:

- upstream Stage-3 basin recovery / reach work
- stronger early-to-mid discriminative signals
- seed-diversity / candidate-diversity improvements in Stage 3
- better benchmark design for weak-seed learning loops

This is also broadly aligned with the earlier strategic review in:

- `appendix_deep_research_report.md`
- `deep_research_pack_snapshot/`

## Newly strengthened hypotheses from the 2026-03-27 code cross-check

### H-entry-dilution

When preservation increases, weak seeds may get less local mutation depth per
promoted family than intended.

Why this is now stronger:

- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_seeding.py`
- `init3_n` is fixed before `per_seed = ceil(init3_n / len(promoted_keys))`
- descendants are then deduped and truncated back to `init3_n`

What would support it further:

- evidence that preserved/wider runs carry more promoted families but do not
  preserve comparable local reach per family

### H-objective-mismatch

Stage-3 inner solve can be raw-score-led while Phase-B family selection remains
mostly judged-pct-led.

Why this is now stronger:

- profile defaults:
  - `tools/benchmarks/config/no_wli_pipeline_profiles.py`
  - `solver_stage3["use_raw_score"] = True`
- Phase-B ranking:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
  - `_phaseb_rank_key(...)` starts with `end_score_pct`
  - `end_score_raw` is only a later tiebreak dimension

Important nuance:

- active live presets can override some profile budgets
- so this is strongest as a design-contract concern, not yet as a pure
  one-variable runtime attribution for every live run

What would support it further:

- weak-seed runs or audits showing truth-better challengers present in Phase-A /
  Phase-B pools but losing before deeper refinement because the pct-led family
  ordering still prefers the anchor family

### H-family-collapse

Useful family diversity may exist upstream, but too few distinct families may
survive Phase-B narrowing into Phase-C and later downstream use.

Why this is now stronger:

- Phase-A is narrowed on search-side ranking before judged pct scoring
- Phase-B is then deduped and tie-banded around pct-led selection
- this creates two separate compression points before later refinement

What remains unresolved:

- exact survival of distinct families into Phase-C starts and Stage-3.5 seed
  construction

### What became weaker

The latest code cross-check weakens this specific suspicion:

- "some saved weak-run summaries show only one Phase-B top-k row, therefore the
  save path is probably broken"

Why:

- current Kaeding telemetry only records candidates that become new global
  raw-score bests
- that means `phaseB_topk_saved_count = 1` can coexist with a much broader
  actual selected Phase-B set
