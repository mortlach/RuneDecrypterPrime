# Current State

## Short version

The project has two very different truths at the same time:

- it **can** reach a strong hard-case family on `p9/c3/l1000`
- it is **not yet reliable across weak seeds**

That distinction matters because recent work improved pipeline reliability, but
it did not yet improve solve quality on weak seeds.

## Best known capability

These are the strongest currently cross-checked hard-case results:

- recovered Stage-3 hard-case basin on `seed511`:
  - artifact:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - fields:
    - `best_match_ratio = 0.771`
    - `best_score = 0.33803928316311727`
    - `best_stage = "stage3_full_refine"`

- clean live Stage-3.5 proof on the same hard case:
  - artifact:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - fields:
    - `best_match_ratio = 0.794`
    - `best_score = 0.3534210925874578`
    - `best_stage = "stage35_substitution_only"`
    - `stage35_requested_cfg = 1`
    - `stage35_enabled_cfg = 1`
    - `stage35_ran = 1`
    - `stage35_proof_valid = 1`
    - `stage35_selected = 1`
    - `stage35_seed_count = 6`
    - `stage35_archive_count = 16`

Interpretation:

- the system is capable of a strong hard-case basin
- Stage-3.5 can add value when the upstream basin is already strong

## Best current diagnosis of the regression

The strongest current diagnosis still points upstream:

- summary artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- key fields:
  - `primary_culprit = "inside_stage3_basin_generation"`
  - evidence row:
    - `stage2_topk_top5_mean_match: old 0.0958, new 0.0958, delta 0.0000`
  - evidence row:
    - `stage3_topk_top5_mean_match: old 0.7678, new 0.6378, delta -0.1300`
  - evidence row:
    - `final_best_match_ratio: old 0.773, new 0.668, delta -0.1050`

Interpretation:

- Stage-2 candidate quality did not materially move
- the large drop appears inside Stage-3 basin generation, not after it

## Current weak-seed reality

### Seed211

Historical weak-seed baseline from the audit summary:

- summary artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
- row:
  - `run_label = "seed211_old_best"`
  - `final_best_match = 0.637`

Current live canary after the handoff fix:

- run directory:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159`
- result artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
- fields:
  - `stage2_match_ratio = 0.209`
  - `stage3_match_ratio = 0.574`
  - `best_match_ratio = 0.574`
  - `best_stage = "stage3_full_refine"`

Overnight `seed211` live matrix, completed jobs 1-3:

- run state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
  - fields:
    - `completed_jobs = 3`
    - `stopped_early = 1`
- completed results:
  - preserve lane:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
    - `best_match_ratio = 0.574`
  - recovery lane:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
    - `best_match_ratio = 0.574`
  - Stage-3.5 proof lane:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 1`
    - `stage35_selected = false`
    - `stage35_archive_count = 16`
    - `stage35_rounds_completed = 3`
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
    - `stage35_accept_reason = "search_score_drop_guard_failed"`

Interpretation:

- weak `seed211` has not improved in recent live runs
- Stage-3.5 executed and was auditable, but it did not rescue the weak basin

### Seed411

Historical weak-seed baseline from the audit summary:

- summary artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
- row:
  - `run_label = "seed411_old_best"`
  - `final_best_match = 0.596`

Fixed-handoff downstream ranking probe:

- report:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- summary:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`
- key result:
  - all three variants ended with `resume_best_match_ratio = 0.032`
  - `checkpoint_summary.best_truth_match = 0.099`
  - `between_family_truth_gap = 0.067`
  - stop reason: `stalled_no_improve`

Interpretation:

- small lexical-gate / tie-window relaxations were not enough on `seed411`
- the next meaningful `seed411` test should be broader than a tiny gate tweak

## Pipeline reliability state

The strongest recent reliability win is live handoff emission:

- handoff manifest from the fixed live canary:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
- key field:
  - `stage2_to_stage3.source = "live_stage3_pipeline"`

Interpretation:

- the specific live commit / handoff-emission bug class is fixed on a real path
- that does **not** imply solve quality is fixed

## Active live comparison run

The current active comparison is intentionally narrow:

- control files:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`

As last checked:

- run state:
  - `completed_jobs = 0`
  - `remaining_jobs = 2`
  - `started_utc = 2026-03-27T04:40:57.230790+00:00`
- event log shows job 1 started:
  - `stage3_tuning_preset_id = "stage3_preserve_tieband_probe_p9"`
  - `run_seed = 411`
- plan shows both jobs:
  - control:
    - `stage3_preserve_tieband_probe_p9`
  - candidate:
    - `lexical_phasec_rescue_wide_finish`

Interpretation:

- the active run is a short `seed411` control-vs-candidate comparison
- it is designed to answer a narrow downstream question faster than the earlier
  10-job matrix
