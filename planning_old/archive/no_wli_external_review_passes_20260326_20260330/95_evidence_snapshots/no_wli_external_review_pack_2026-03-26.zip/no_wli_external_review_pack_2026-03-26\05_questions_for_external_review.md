# Questions For External Review

These are the concrete questions we want outside help on.
Each question points to the files that provide the evidence behind the current
internal view.

## 1. Is "inside Stage-3 basin generation" still the right main diagnosis?

Why we are asking:

- this is the main current internal diagnosis
- if it is wrong, recent effort may be aimed at the wrong part of the system

Primary evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
- `01_current_state.md`
- `02_recent_experiments_and_observations.md`

What we want from reviewers:

- agreement or disagreement with the diagnosis
- if disagreement, what alternative primary culprit the evidence supports

## 2. Are we over-investing in downstream rescue and under-investing upstream?

Why we are asking:

- weak-seed recent runs have been negative
- small `seed411` lexical-gate changes did nothing
- broad `seed211` downstream attempts also did not improve

Primary evidence:

- `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
- `04_hypotheses_and_next_decisions.md`

What we want from reviewers:

- whether the evidence really supports moving more attention upstream now
- if not, what downstream experiment would still be justified and why

## 3. Is the current 2-job seed411 comparison the right short next test?

Why we are asking:

- we deliberately reduced from a 10-job overnight matrix to a 2-job live
  comparison
- we want to know whether that reduction is scientifically well chosen

Primary evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
- `02_recent_experiments_and_observations.md`

What we want from reviewers:

- whether this is a meaningful control-vs-candidate pair
- if not, which 1-2 job comparison would be better

## 4. Are our acceptance metrics and learning loop good enough?

Why we are asking:

- broad matrices were too slow
- one-off wins are not enough
- we need a better way to learn quickly without fooling ourselves

Primary evidence:

- `appendix_deep_research_report.md`
- `deep_research_pack_snapshot/capability_ladder_no_wli_periodic_sub_trans_2026-03-21.md`
- `appendix_science_run_log_2026-03-26.md`
- `appendix_solve_integrity_plan_2026-03-21.md`

What we want from reviewers:

- better acceptance metrics if the current ones are weak
- better experimental ladder design if ours is missing a more informative
  control

## 5. Given the evidence, what 2-3 method families would you prioritize next?

Why we are asking:

- if the current short `seed411` candidate is also negative, we need a more
  decisive next branch
- we do not want to drift into another round of low-value tuning

Primary evidence:

- `appendix_deep_research_report.md`
- `deep_research_pack_snapshot/method_families_next_capability_jump_2026-03-21.md`
- `04_hypotheses_and_next_decisions.md`

What we want from reviewers:

- a short ranked list of next method families
- the reason each family is justified by the current evidence

## 6. Are there any signs in the current evidence that our own interpretation is misleading?

Why we are asking:

- we are explicitly worried about getting lost in complexity
- this pack is meant to make that concern auditable rather than rhetorical

Primary evidence:

- all files in this pack

What we want from reviewers:

- point out any claim that seems under-supported
- point out any claim that seems stronger than the evidence allows
- point out any missing evidence that should exist before another major
  conclusion is drawn
