# Pipeline Reliability And Methodology

## Why this section exists

There are two separate questions in this project:

- is the solver getting better?
- is the pipeline honestly telling us what happened?

Recent work mostly improved the second question.
That matters because the recent live failures were not just "bugs somewhere";
they were failures right on the boundary where results are saved and handed off.

## What was broken

The recent live reruns exposed repeated commit/handoff failures:

- `KeyError: 'base'`
- later `KeyError: 'write_json'`

Primary review source:

- `planning/working/no_wli_pipeline_hardening_review_2026-03-25.md`

Core diagnosis from that review:

- the commit path allowed a sparse per-iteration bridge payload to stand in for
  the full runner state
- this meant required services such as `base` and `write_json` could disappear
  late in the run
- helper-level tests could still look green while the real callback path was
  wrong

This was a methodology problem, not just a local typo.

## What was hardened

The pipeline hardening review documents the main fixes:

- explicit commit bridge helpers
- bridge payload narrowed to explicit live handoff data
- unexpected bridge override keys rejected
- required runner services validated before commit work begins
- runtime signature inspection removed from the finalize/commit path
- Stage1/Stage2 payload contracts tightened
- unknown status keys rejected instead of ignored
- summary/completion paths shifted from permissive `.get(...)` access to
  required fields
- more runner/config defaults treated as required contracts rather than silent
  fallbacks

Raw review artifact:

- `planning/working/no_wli_pipeline_hardening_review_2026-03-25.md`

## What is now genuinely proven

### 1. Live handoff emission works on a real path

Evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
- field:
  - `stage2_to_stage3.source = "live_stage3_pipeline"`

Why this matters:

- the exact class of commit/handoff crash that blocked the live path is fixed
  at least on one real end-to-end run

### 2. Stage-3.5 execution can be real and auditable

Evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- fields:
  - `stage35_requested_cfg = 1`
  - `stage35_enabled_cfg = 1`
  - `stage35_ran = 1`
  - `stage35_proof_valid = 1`
  - `stage35_selected = 1`

Why this matters:

- Stage-3.5 is not just a configuration fiction; it can run and win when the
  basin is good

### 3. Stage-3.5 non-win cases can now be inspected honestly

Evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
- fields:
  - `stage35_requested_cfg = 1`
  - `stage35_selected = false`
  - `stage35_archive_count = 16`
  - `stage35_rounds_completed = 3`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
- field:
  - `stage35_accept_reason = "search_score_drop_guard_failed"`

Why this matters:

- a recent weak-seed Stage-3.5 lane failed in an interpretable way
- that is a reliability gain even though the result was negative

## What is still not fully proven

### 1. General live reliability across seeds

Only one fresh live canary is clearly proven after the main hardening wave:

- `seed211` live canary:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159`

That proves the key live handoff path once.
It does not prove every live branch is now reliable.

### 2. General resumed/live parity

What is proven:

- fixed-handoff resumed `seed411` ranking probe runs to completion

What is not proven:

- that every future live handoff and later resumed replay will align cleanly in
  all downstream branches

### 3. Solve reliability

This is still the main unsolved problem.

Recent negative evidence:

- live `seed211` canary stayed at `0.574`
- live `seed211` preserve / recovery / Stage-3.5 proof lanes all stayed at
  `0.574`
- fixed-handoff `seed411` ranking probe stayed at `0.032`

So the project is methodologically healthier than before, but not yet broadly
stronger on weak seeds.

## Why the distinction matters

Without this methodology split, weak-seed failures would be easy to misread:

- a crash after solving could look like "the solve failed"
- a missing Stage-3.5 lane could look like "Stage-3.5 was tested and lost"
- a narrow helper test could look like "the live path is covered"

The recent reliability work reduced those ambiguities.

## Bottom line

The pipeline is more trustworthy than it was a few days ago.
The recent live evidence supports these narrower claims:

- live handoff emission is fixed on at least one real run
- Stage-3.5 execution and non-selection are both now auditable
- the main current failure is still weak-seed solve quality, not the same old
  handoff bug repeating silently

That is progress, but it is not yet a general proof that the whole pipeline is
reliable across all branches or that the current weak-seed strategy is correct.
