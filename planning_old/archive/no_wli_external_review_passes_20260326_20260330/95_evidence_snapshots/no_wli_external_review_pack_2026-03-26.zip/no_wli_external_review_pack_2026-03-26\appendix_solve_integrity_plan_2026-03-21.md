# no_wli Solve-Integrity Plan

Date: 2026-03-21
Status: Active working plan
Scope: `tools/benchmarks/periodic_sub_trans/no_wli`

## Purpose

This is the active plan for the no-WLI hard-solve programme.

It is deliberately **not** a broad repo tidy-up plan and **not** a new late-solver invention plan.
The immediate goal is to restore trustworthy learning by fixing proof integrity first and then identifying where the stronger old hard-case basin was lost.

This file should be treated as the working checklist for the branch and updated in place as phases complete.

## Companion Decision Pack

For the narrower deep-research decision layer that sits above this execution checklist, see:

- `planning/working/no_wli_deep_research_pack_2026-03-21/README.md`
- `planning/working/no_wli_deep_research_pack_2026-03-21/capability_ladder_no_wli_periodic_sub_trans_2026-03-21.md`
- `planning/working/no_wli_deep_research_pack_2026-03-21/method_families_next_capability_jump_2026-03-21.md`
- `planning/working/no_wli_deep_research_pack_2026-03-21/evidence_gaps_no_wli_periodic_sub_trans_2026-03-21.md`
- `planning/working/no_wli_deep_research_pack_2026-03-21/tactical_refactor_filter_solve_first_2026-03-21.md`

Use that pack for capability positioning, method ordering, evidence confidence, and solve-first refactor discipline.
Keep this file as the active gate and execution tracker.

## Current evidence snapshot

Canonical references:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/best_p9_c3_runs.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/solve_status_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`

Key artifacts:

- recovered Stage-3 baseline:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- clean Stage-3.5 win:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- failed cross-seed confirmation:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T192204224097Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`

Evidence summary:

- best `p9/c3/l1000` run is now the clean Stage-3.5 proof at `0.794`
- recovered Stage-3 baseline reached `0.771`
- cross-seed confirmation on `seed = 211` only reached `0.574`
- the strongest recovered Stage-3 family is back for `seed = 511`
- Stage-3.5 has been proven to add value on top of that strong basin
- cross-seed reliability is still weak because some hard seeds do not reach a comparable Stage-3 basin first
- the new partial-state signal audit shows:
  - Stage-2 partial-state signals are weak discriminators across selected hard runs
  - Stage-3 top-k and later signals become informative once the search reaches a useful family
  - the general failure now looks like weak early/mid basin signal plus seed-sensitive search reach

Current interpretation:

1. Proof integrity is no longer the main blocker.
2. The core reliability problem is now **cross-seed basin reach before late refinement**, not late-solver validity.
3. If stronger partial-state signals are absent before Stage 3, further Stage-3 promotion tuning alone is unlikely to scale.

## Scope and non-goals

### In scope

- proof-integrity hardening
- hard-case basin-regression analysis
- selector/scorer audit on a small real ladder
- one bounded recovery proof after the above gates

### Out of scope for now

- broad v1 repo tidy-up
- new solver invention before regression is understood
- broad run sweeps / wide matrices
- `p11` / `p13` as the main decision ladder

## Baseline ladder

This ladder is frozen for near-term evaluation.

### Easy controls

- `fixture_fixture_001_p5_c1_l1000`
- `fixture_fixture_001_p5_c3_l1000`
- `fixture_fixture_001_p7_c1_l1000`
- `fixture_fixture_001_p7_c5_l1000`

### Medium-ish control

- `fixture_fixture_001_p9_c1_l1000`

### Hard target

- `fixture_fixture_001_p9_c3_l1000`

Rule:
- no new major claim should be made without checking behaviour against this ladder

## Phase status board

- Phase 0: Freeze baseline ladder and active plan
  - Status: completed
- Phase 1: Proof-integrity hardening
  - Status: completed
- Phase 2: Basin-regression A/B analysis
  - Status: completed
- Phase 3: Selector/scorer audit on the real ladder
  - Status: completed
- Phase 4: One bounded recovery proof
  - Status: completed
- Phase 5: One clean bounded Stage-3.5 proof
  - Status: completed
- Phase 6: Offline cross-seed basin-family diversity and score-truth alignment audit
  - Status: completed
- Phase 7: Targeted resumed experiments split by failure mode
  - Status: in progress

## Phase 1: Proof-integrity hardening

### Goal

Prevent a requested Stage-3.5 proof from silently completing as a nominal result when Stage-3.5 did not actually run.

### Expected files

- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_iteration_flow.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage35_substitution_solver.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_post_stage3.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_outcome.py`
- if needed:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`

### Required behaviour

- Final outputs must distinguish:
  - Stage-3.5 requested
  - Stage-3.5 effectively enabled in the live path
  - Stage-3.5 ran
  - proof validity / invalid reason
- A proof with `stage35 requested = true` but `stage35_ran = 0` must be marked invalid and must not be treated as a normal proof result.

### Meaningful tests

- strengthen `tests/tools/test_no_wli_stage35_substitution_solver.py`
- strengthen `tests/tools/test_no_wli_fixture_matrix_runtime.py`
- add one integration-style proof-validity test if current coverage is not enough

Minimum assertions:

- requested Stage-3.5 cannot end with `ran = 0` and no invalid marker
- disabled Stage-3.5 stays cleanly disabled
- the specific `run_config enabled / final artifact ran=0` mismatch is reproducible as a regression test and then blocked

### Gate 1

No new proof run until:

- a requested Stage-3.5 proof cannot silently finish with `stage35_ran = 0`

### 2026-03-21 update

Gate 1 cleared.

Implemented:

- threaded `STAGE35_ENABLED` / `STAGE35_CFG` through the iteration-matrix and stage-engine bridge path
- added explicit proof markers:
  - `stage35_requested_cfg`
  - `stage35_proof_valid`
  - `stage35_proof_invalid_reason`
- exposed those markers in final Stage-3 diagnostics and top-level final outputs
- added a flow-level regression test for the old invalid shape:
  - requested Stage-3.5
  - `ran = 0`
  - explicit invalid-proof marker instead of silent nominal result

Validated with:

- `tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py`
- `tests/tools/test_no_wli_truth_diagnostics.py`
- `tests/tools/test_no_wli_stage35_substitution_solver.py`
- `tests/tools/test_no_wli_fixture_matrix_runtime.py`
- `tests/tools/test_no_wli_stage_engine_iteration_bridge.py`
- `tests/tools/test_no_wli_run_completion.py`
- `tests/tools/test_no_wli_iteration_finalize_word_ngram.py`

Next action:

- Phase 2 basin-regression A/B analysis

## Phase 2: Basin-regression A/B analysis

### Goal

Find where the old stronger `p9/c3` basin is lost.

### Comparison set

Primary:

- `20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e`
- `20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159`

Secondary:

- `20260315T001203236783Z__bench_solve_pipeline_no_wli__5961d3e`
- `20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e`

### Inputs to compare

- `run_config.json`
- `stages.json`
- `final_instances/*.json`
- `phasec_start_checkpoints.jsonl` when present

### Questions to answer

- Did the regression happen before Stage 3?
- Did it happen inside Stage-3 basin generation?
- Did it happen at late handoff into refinement?

### Required deliverable

This phase must end with exactly:

- one primary culprit:
  - `pre_stage3_regression`
  - `inside_stage3_basin_generation`
  - `late_handoff_regression`
- optional secondary contributors ranked below it
- one short evidence table backing the ranking

This phase is not complete without naming one primary culprit.

### Meaningful tests

- deterministic artifact-parser tests for the March and March 21 comparison set
- stable comparison-summary tests if a helper is added

### Gate 2

No new late-solver design or proof run until:

- Phase 2 names one primary culprit with explicit evidence

### 2026-03-21 update

Gate 2 cleared.

Canonical outputs:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`

Primary culprit:

- `inside_stage3_basin_generation`

Ranked conclusion:

1. `inside_stage3_basin_generation`
2. no strong secondary contributor named yet

Short evidence table:

- `stage2_topk` top-5 mean match:
  - old `0.0958`
  - current `0.0958`
  - delta `0.0000`
- `stage3_topk` top-5 mean match:
  - old `0.7678`
  - current `0.6378`
  - delta `-0.1300`
- final best match:
  - old `0.773`
  - current `0.668`
  - delta `-0.105`

Interpretation:

- the regression is not primarily pre-Stage-3, because the Stage-2 top-k family is effectively unchanged
- the regression is not primarily late handoff, because the weaker family is already visible in `stage3_topk`
- the strongest evidence points to Stage-3 basin generation itself

Next action:

- Phase 3 selector/scorer audit on the frozen ladder

## Phase 3: Selector/scorer audit on the real ladder

### Goal

Check whether current live-visible ranking signals separate better and worse basins across easy, medium, and hard tiers.

### Likely code surface

- `tools/benchmarks/periodic_sub_trans/no_wli/replay_phasec_rescue_sweep.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/replay_stage35_substitution_solver.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage35_ranking.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/phasec_rescue_selector.py`

### Questions

- On easy solved controls, do current selectors preserve good outcomes?
- On `p9/c1`, do selectors separate stronger basins from weaker ones?
- On `p9/c3`, what selector regret remains on close candidates?
- Do current score/search-led signals actually rank the better basin above the worse basin?

### Meaningful tests

- deterministic replay summary tests on a fixed artifact subset
- stable ladder-audit output on the same inputs
- no-oracle safety remains covered

### Gate 3

No selector/ranking change should proceed unless it:

- does not break easy controls
- helps at least the medium/hard side of the ladder
- improves candidate choice, not just diagnostics

### 2026-03-21 update

Phase 3 audit completed.

Canonical outputs:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`

Key findings:

- easy controls remain stable with zero observed top-k truth regret
- `p9/c1` shows non-zero within-run selector regret:
  - mean `0.0034`
  - top-is-best rate `0.444`
- `p9/c3` also shows selector imperfection, but it is smaller than the Stage-3 basin drop:
  - mean top-k regret `0.0007`
  - top-is-best rate `0.825`
  - final score/match correlation across runs `0.915`

Interpretation:

- current score-led ranking is imperfect and not fully robust
- but the audit does not support “totally broken scorer” as the primary explanation
- the Phase 2 conclusion still stands:
  - the dominant regression is inside Stage-3 basin generation

Next action:

- Phase 4 bounded recovery proof setup using the older narrow Stage-3 regime that already reached the strong `0.761` family

## Phase 4: One bounded recovery proof

### 2026-03-21 update

Phase 4 setup is in progress.

Chosen recovery target:

- the Phase-C-enabled March 15 `0.761` family, not the newer wide/deep proof preset

Recovery preset shape:

- `init_keys = 64`
- `span_basin_judge.k / tie_max_seeds = 64`
- `phase_a.steps = 800`
- `phase_b.steps = 2200`
- `phase_b_top_n = 8`
- `gate_delta_floor = 0.003`
- `gate_end_gain_floor = 0.001`
- `phase_c.enabled = true`
- `phase_c.start_keys = 6`
- `phase_c.cfg.steps = 96`
- `stage35.enabled = false`

Reason:

- this older narrow Stage-3 regime already produced a strong hard-family run (`0.761`) with Phase-C enabled
- it is a cleaner recovery target than the newer wide/deep proof preset
- it keeps the next run focused on basin recovery rather than mixing in a fresh Stage-3.5 claim

Local validation added:

- fixture-matrix preset forwarding test for `stage3_recovery_p9_8h`
- recovery finalize-path smoke test using the real payload builder bridge

What this now guarantees before the live run:

- the active recovery preset reaches the runtime apply path with the intended narrow Stage-3 overrides
- the bounded recovery artifact path preserves:
  - Phase-C checkpoint markers
  - Stage-3 diagnostics
  - explicit Stage-3.5-disabled validity markers

### Goal

Recover the stronger hard-case basin before asking Stage-3.5 to prove anything.

### Run shape

- one bounded `p9/c3/l1000` run
- one seed
- one preset
- no matrix sweep

### Success bar

At least one of:

- final result materially above `0.668`
- `stage3_topk` family materially closer to the old `0.77x` cluster
- clear evidence that the regression point named in Phase 2 was actually fixed

### Gate 4

If the recovery proof still lands in the `0.63x / 0.64x` family, stop and reassess upstream search rather than piling on more late logic.

### 2026-03-21 update

Gate 4 cleared.

Canonical recovery artifact:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`

Recovery result:

- final `best_match_ratio = 0.771`
- final `best_score = 0.33803928316311727`
- `best_stage = stage3_full_refine`
- `stage3_topk` top-5 cluster:
  - `0.757, 0.754, 0.754, 0.754, 0.754`

Checkpoint evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/phasec_start_checkpoints.jsonl`
- anchor Phase-C start reached `0.761`
- challenger `source_rank = 2` overtook the anchor and finished at `0.771`

Interpretation:

- the older narrow Stage-3 regime does recover the stronger hard-case basin family
- the project is no longer blocked on the specific `0.638 / 0.640` regressed family
- the next question is now the intended Phase 5 question:
  - can clean live Stage-3.5 beat this recovered Phase-C baseline?

Next action:

- switch the active bounded proof preset to a Stage-3.5 proof that keeps the recovered Stage-3 regime intact
- run one bounded `p9/c3/l1000` proof with Stage-3.5 enabled and proof-validity markers required

## Phase 5: One clean bounded Stage-3.5 proof

### 2026-03-21 update

Phase 5 setup is now in progress.

Active proof shape:

- keep the recovered Stage-3 regime from Phase 4:
  - `init_keys = 64`
  - `phase_b.steps = 2200`
  - `phase_b_top_n = 8`
  - `phase_c.enabled = true`
  - `phase_c.start_keys = 6`
  - `phase_c.cfg.steps = 96`
- re-enable Stage-3.5 with the bounded proof config used in the earlier proof-integrity work:
  - `seed_keep = 4`
  - `beam_width = 4`
  - `archive_keep = 16`
  - `rounds = 3`
  - `mini_search_keep_all_rows = 1`
  - `accept_score_min_gain = 0`
  - `accept_search_score_max_drop = 0`

Reason:

- the earlier Stage-3.5 proof attempt was invalid and also sat on a regressed basin
- Phase 4 recovered the strong basin cleanly
- the right next proof is therefore a narrow rerun of Stage-3.5 on top of the recovered basin, not a new solver branch or a wider matrix

### Goal

Answer the real question:

- can live Stage-3.5 beat the stable Phase-C baseline on a credible `p9` run?

### Proof requirements

A valid proof must show:

- `run_config` requested Stage-3.5
- final artifact records Stage-3.5 as effectively enabled
- `stage35_ran = 1`
- `stage35_archive_count > 0`
- proof validity passes
- result is auditable against the preserved baseline

### Success bar

Strong:

- Stage-3.5 runs
- archive is non-empty
- proof is valid
- final result beats the recovered baseline

Weak but still useful:

- Stage-3.5 runs cleanly and produces a coherent archive even if it does not yet beat the recovered baseline

### Gate 5

Only after a clean `p9` proof should `p11` be considered.
`p13` remains out of scope until then.

### 2026-03-22 update

Gate 5 cleared.

Canonical proof artifact:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`

Proof result:

- final `best_match_ratio = 0.794`
- final `best_score = 0.3534210925874578`
- `best_stage = stage35_substitution_only`

Stage-3.5 proof markers:

- `stage35_requested_cfg = 1`
- `stage35_enabled_cfg = 1`
- `stage35_ran = 1`
- `stage35_selected = 1`
- `stage35_proof_valid = 1`
- `stage35_archive_count = 16`
- `stage35_seed_count = 6`

Recovered-baseline comparison:

- Phase 4 recovered baseline:
  - `best_match_ratio = 0.771`
  - `best_score = 0.33803928316311727`
- Phase 5 proof result:
  - `best_match_ratio = 0.794`
  - `best_score = 0.3534210925874578`
- gain:
  - match `+0.023`
  - score `+0.01538180942434053`

Interpretation:

- this is the first clean live proof that Stage-3.5 can beat the recovered `p9/c3` Phase-C baseline
- the solve programme is no longer blocked on proof integrity, Stage-3 regression, or the question of whether Stage-3.5 has real value on top of a strong basin
- the immediate next step should be confirmation and generalisation, not a fresh solver redesign

Next action:

- freeze this proof result as the new `p9/c3` best evidence
- run one narrow confirmation step before broadening:
  - either one additional `p9/c3` seed with the same preset
  - or one adjacent control-tier proof using the same Stage-3.5 shape

### 2026-03-22 next-step note

Chosen confirmation step:

- one additional `p9/c3/l1000` bounded proof on `seed = 211`
- keep the same recovered Stage-3 plus Stage-3.5 preset shape from the successful `seed = 511` proof

Reason:

- `seed = 211` is the strongest non-`511` historical `p9/c3` seed in the current archive
- best archived `seed = 211` result is `0.637`, which makes it a meaningful confirmation target without broadening the problem ladder yet

Catalog note:

- after the `0.794` proof, the catalog builder was updated to read `stage35_selected` and `seed` from nested diagnostics / `key_seed` fallback when those fields are absent at the artifact top level
- this keeps `best_p9_c3_runs.csv` and `inventory_summary.json` honest for Stage-3.5 proof tracking

### 2026-03-23 confirmation note

First confirmation attempt:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T192204224097Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`

Result:

- final `best_match_ratio = 0.574`
- final `best_score = 0.23689607961472836`
- `best_stage = stage3_full_refine`

Stage-3.5 proof markers stayed valid:

- `stage35_requested_cfg = 1`
- `stage35_enabled_cfg = 1`
- `stage35_ran = 1`
- `stage35_proof_valid = 1`
- `stage35_archive_count = 16`
- `stage35_seed_count = 2`
- `stage35_selected = 0`
- `stage35_accept_reason = search_score_drop_guard_failed`

Interpretation:

- this is not a proof-integrity failure
- it is a seed-generalisation failure
- the recovered Stage-3 regime that worked for `seed = 511` did not recover a comparably strong basin for `seed = 211`
- Stage-3.5 therefore had too little useful basin quality to work with and was correctly rejected by the live acceptance guard

Immediate next question:

- how much of the remaining reliability problem is due to Stage-3 seed fragility across `p9/c3` seeds, versus the specific acceptance/ranking shape inside Stage-3.5 once the basin is weak?

### 2026-03-23 partial-state signal audit note

Audit outputs:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_report.md`

Comparison set:

- strong runs:
  - `seed511_old_best`
  - `seed511_recovery`
  - `seed511_stage35_win`
- weak runs:
  - `seed211_old_best`
  - `seed211_stage35_fail`
  - `seed411_old_best`

State kinds compared:

- `stage2_topk`
- `stage3_topk`
- `phasec_start`
- `stage35_seed`
- `stage35_archive`

Headline results:

- Stage-2 partial-state scores remain weak as basin discriminators across the selected hard runs:
  - `stage2_topk.score_stage2` run-max/final-match correlation `0.265`
  - strong-vs-weak separation gap `-0.004827`
  - top-by-signal truth-best rate `0.167`
- Stage-3 top-k scores carry much stronger basin signal once the search reaches a useful family:
  - `stage3_topk.score_judge` run-max/final-match correlation `0.880`
  - strong-vs-weak separation gap `0.050475`
  - top-by-signal truth-best rate `0.667`
- Late Stage-3.5 archive ranking is not the main problem on weak seeds:
  - archive `search_score` remains more truth-aligned than raw archive `score`
  - the `seed = 211` rejection therefore looks consistent with weak basin quality rather than a broken acceptance rule

Interpretation:

- current live-visible signals do not separate strong from dead states well enough before Stage 3
- they do become informative inside Stage-3 top-k and later
- the general failure mode therefore looks like weak early/mid basin signal plus seed-sensitive Stage-3 search reach, not a completely broken late-stage scorer

Decision implication:

- if no stronger pre-Stage-3 partial-state signals are available, further optimisation of current Stage-3 promotion logic alone is unlikely to scale reliably across seeds
- the next design work should therefore prioritise stronger early/mid partial-state signals or a search regime that can preserve more candidate diversity until the later informative signals appear

### 2026-03-23 Stage-3 preservation probe setup note

Implementation intent:

- take the most conservative next step first
- do not invent a new Stage-3 selector yet
- instead widen and expose the existing Phase-B tie-band preservation mechanism so it can be tested explicitly on a fixed hard-seed set

Code changes:

- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
  - fixture-matrix now supports forcing `STAGE3_SPAN_BASIN_JUDGE_TIE_EPS`
  - two-phase default syncing now also carries tie-band defaults
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - preset resolution and application now forward `force_stage3_span_basin_judge_tie_eps`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_defaults.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/profile_defaults.py`
  - tie-band defaults are now stored and restored explicitly rather than drifting across runs
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - active next-step preset is now `stage3_preserve_tieband_probe_p9`

Active preservation probe shape:

- fixture family:
  - `p9 / c3 / l1000`
- fixed seed set:
  - `511`
  - `211`
  - `411`
- recovered narrow Stage-3 regime kept:
  - `init_keys = 64`
  - `phaseB_top_n = 8`
  - `phaseB.steps = 2200`
  - `Phase-C enabled`
- Stage-3.5 disabled
- widened Phase-B tie-band:
  - `tie_eps = 0.005`
  - `tie_max_seeds = 16`
- wallclock cap removed for this probe:
  - `MAX_WALLCLOCK_SECONDS = None`

Reasoning:

- the partial-state audit says current live-visible signal is still weak before Stage 3
- the first bounded next step should therefore preserve more candidate families until the stronger Stage-3 signal appears
- using the existing tie-band route first is lower risk and easier to interpret than inventing a new promotion heuristic immediately

Tests added:

- `tests/tools/test_no_wli_stage3_phasec.py`
  - tie-band can expand Phase-B seed preservation beyond the nominal `top_n`
- `tests/tools/test_no_wli_fixture_matrix_runtime.py`
  - the new `stage3_preserve_tieband_probe_p9` preset really forwards the widened tie-band overrides

Validation:

- `22 passed` on focused Stage-3 / fixture-matrix / audit / diagnostics tests

Open question this probe is meant to answer:

- does a wider Phase-B preservation band lift weak hard seeds such as `211` and `411` without giving back the recovered strong `511` basin?

### 2026-03-23 preservation-probe correction and resume-handoff note

Important correction:

- the finished `v31` preservation probe was **not** the intended three-seed comparison
- the executed plan and state files were:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v31_p9c3_stage3_preserve_probe.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v31_p9c3_stage3_preserve_probe.json`
- those files materialized only **one job**, for `seed = 511`
- so the `v31` result should be interpreted only as:
  - widened tie-band preservation does not break the known strong `511` basin
- it does **not** answer the cross-seed question for `211` / `411`

What was found:

- `MAX_JOBS` in fixture-matrix config is a **total job truncation**, not merely a parallelism control
- that is why the previous intended multi-seed probe collapsed to one executed seed

Fix now in place:

- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - `RUN_SEEDS = (211, 411)`
  - fresh state/event/plan paths on `v32`
  - `MAX_JOBS = 2` so both weak-seed jobs materialize
- plan smoke cross-check now confirms:
  - `job_count = 2`
  - `job_seeds = [211, 411]`

Resume-handoff saving normalized:

- completed runs now also write:
  - `run_dir/resume_handoffs/<artifact_stem>/manifest.json`
  - `run_dir/resume_handoffs/<artifact_stem>/stage2_resume.json`
  - `run_dir/resume_handoffs/<artifact_stem>/stage3_prep.json`
  - `run_dir/resume_handoffs/<artifact_stem>/stage35_seed_archive.json`
- this is enabled by default through:
  - `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_defaults.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/runner_bridges.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/resume_handoff_artifacts.py`

Why this is worth making normal:

- it is cheap compared with the solve runtime
- it makes later-stage reruns explicit and easier to discover
- it preserves the gate-ready subsets we can already reconstruct reliably
- it does not attempt full in-flight solver checkpointing

Current limitation remains:

- `stage2_to_stage3` handoff is reconstructed from saved `stage2_topk`
- this is a pragmatic experiment-time resume bundle, not a bit-perfect full solver-state resume

Validation:

- focused test sweep after the fix and new handoff writer:
  - `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - `tests/tools/test_no_wli_fixture_matrix_runtime.py`
  - `tests/tools/test_no_wli_stage3_phasec.py`
  - `tests/tools/test_no_wli_artifact_resume.py`
  - `tests/tools/test_no_wli_truth_diagnostics.py`
  - result: `26 passed`

### 2026-03-23 artifact-based Stage-2 / Stage-3 resume tooling note

Implementation intent:

- reduce time-to-learn for downstream experiments
- avoid rerunning the full pipeline when the experiment only needs a saved Stage-2 or late Stage-3 handoff
- keep the scope narrow and local to `tools/benchmarks/periodic_sub_trans/no_wli`

New files:

- `tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/resume_from_artifact.py`
- `tests/tools/test_no_wli_artifact_resume.py`

Supported resume modes:

- `stage2_to_stage3`
  - reconstruct Stage-2 handoff from saved `stage2_topk`
  - rebuild scorer/cipher runtime from the saved artifact and its `run_config.json`
  - rerun Stage 3 onward without rerunning Stage 1 / Stage 2
- `stage3_to_stage35`
  - reuse saved late-stage artifact state
  - rerun Stage-3.5 from a saved artifact without rerunning Stage 1 / Stage 2 / Stage 3

Entry workflow:

- hardcoded entry script:
  - `tools/benchmarks/periodic_sub_trans/no_wli/resume_from_artifact.py`
- no CLI surface added
- outputs written under:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/...`

What is saved in a resume bundle:

- `summary.json`
- for `stage2_to_stage3`:
  - `stage2_resume.json`
  - `stage3_prep.json`
  - `stage3_flow.json`
  - `outcome.json`
- for `stage3_to_stage35`:
  - `stage35_summary.json`
  - `stage35_archive.json`
  - `stage35_seed_rows.json`

Validation:

- deterministic tests:
  - `tests/tools/test_no_wli_artifact_resume.py`
    - reconstruct Stage-2 resume inputs from saved `stage2_topk`
    - build Stage-3 prep from reconstructed handoff
    - rerun Stage-3.5 from saved late artifact state
    - call Stage 3 flow from reconstructed Stage-2 handoff
- focused regression sweep:
  - `tests/tools/test_no_wli_artifact_resume.py`
  - `tests/tools/test_no_wli_stage35_substitution_solver.py`
  - `tests/tools/test_no_wli_fixture_matrix_runtime.py`
  - `tests/tools/test_no_wli_truth_diagnostics.py`
  - result: `24 passed`

Real-artifact smoke:

- source artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- reconstructed quickly from saved state:
  - `stage2_topk_row_count = 12`
  - `stage2_promote_top_cfg = 160`
  - `stage2_promoted_from_topk_count = 12`
  - `best2_match = 0.209`
  - `stage3_init3_count = 64`

Important limitation:

- the `stage2_to_stage3` resume path reconstructs the Stage-2 promoted pool from saved `stage2_topk`
- it does **not** restore the exact original in-memory Stage-2 archive/promoted pool
- so this is a high-value handoff-resume harness for experimentation, not a bit-perfect full solver-state checkpoint/resume system

## Required meaningful test set

These are the branch-anchor tests this plan expects:

1. proof-integrity integration test
   - requested Stage-3.5 cannot silently end as a nominal result with `ran = 0`
2. config-propagation regression test
   - proof preset reaches final artifact state correctly
3. basin comparison parser test
   - March and March 21 artifacts compare deterministically
4. selector/scorer ladder audit test
   - fixed artifact subset produces stable audit output
5. no-oracle Stage-3.5 safety test
   - live seed/ranking path remains truth-free
6. recovery-proof smoke test
   - bounded proof path emits expected late artifacts and validity markers
7. artifact-resume handoff tests
   - saved `stage2_topk` can reconstruct a usable Stage-3 handoff
   - saved late artifact state can rerun Stage-3.5 without the earlier pipeline stages

## Update protocol

When work progresses, update this file in place:

- change the phase status line
- add a dated note under the phase if a gate is cleared
- if a gate fails, record the failure explicitly rather than rewriting history

Do not replace this file with a fresh summary. Keep it as the running record.

## Phase 6: Offline cross-seed basin-family diversity and score-truth alignment audit

### Goal

Use saved handoff bundles and existing hard-seed artifacts to determine which failure mode is dominant across weak and strong `p9/c3` runs:

- promising families absent early
- promising families present but collapsed during promotion/preservation
- promising families present and preserved but undervalued by live score
- promising families selected but not exploited by later refinement

This phase is measurement only.
It must not change live solver behaviour.

### Why this phase is now next

The finished weak-seed preservation probe did not support the simple “preserve more and weak seeds recover” story.

Observed outcomes:

- `seed211` preservation probe:
  - final `best_match_ratio = 0.574`
  - identical to the earlier failed Stage-3.5 confirmation on the same seed
  - widened tie-band preservation did not help
- `seed411` preservation probe:
  - final `best_match_ratio = 0.041`
  - final `best_stage = stage2_search`
  - yet `phasec_start_checkpoints.jsonl` contains challengers with truth matches around `0.402` to `0.418`
  - those challengers still lost under live score and were not adopted

Interpretation:

- `211` suggests “useful family absent or too weak before preservation matters”
- `411` suggests “truth-better challenger family can exist but still be undervalued or stranded”
- therefore more than one failure mode likely exists
- the next audit must distinguish those modes rather than forcing one single explanation

### Comparison set

Required hard-case runs:

- strong:
  - `seed511` recovery run (`0.771`)
  - `seed511` Stage-3.5 proof run (`0.794`)
- weak:
  - current `seed211` preservation run (`0.574`)
  - older stronger `seed211` run (`0.637`)
  - current `seed411` preservation run (`0.041`)
  - older stronger `seed411` run (`0.596`)

Optional controls:

- one easy solved case
- one `p9/c1` control

### Preferred inputs

Use saved artifacts and handoff bundles only where possible:

- `final_instances/*.json`
- `stage2_topk`
- `stage3_topk`
- `phasec_start_checkpoints.jsonl`
- `resume_handoffs/.../stage2_resume.json`
- `resume_handoffs/.../stage3_prep.json`
- `stage35_seed_rows`
- `stage35_archive`
- truth diagnostics already present in saved outputs

The audit must degrade gracefully when older artifacts do not contain richer checkpoint or truth-diagnostic fields.

### Family views for first pass

Predefine a small fixed set of family views and do not tune them per seed:

- exact key identity
- exact tail identity
- near-tail family under a fixed tail-Hamming rule
- broader full-key family under a fixed full-key Hamming rule

The first pass should keep these thresholds simple, hardcoded in one place, and shared across all analysed runs.

### Required measurements

For each relevant stage pool:

- raw structural uniqueness
- family/cluster count
- effective family count
- largest-family share
- top-band family count
- top-band family mass
- available diversity versus selected diversity

For score-truth alignment within and across families:

- live search score versus truth
- judge/full score versus truth where available
- selected family truth versus best-family truth
- family regret relative to best family in the run
- whether misranking is mainly within-family or between-family

### Required classification output

Each analysed run should end with one of:

- `good_family_absent`
- `good_family_collapsed`
- `good_family_undervalued`
- `good_family_not_exploited`

The phase-level report should then summarize which labels dominate across the comparison set.

### Deliverables

Code:

- one new offline audit script under `tools/benchmarks/periodic_sub_trans/no_wli`
- prefer a name that reflects both diversity and score-truth alignment, not diversity alone
- keep it separate from live solve code

Tests:

- family clustering under fixed thresholds
- available-versus-selected diversity summary
- family regret calculations
- deterministic handling of missing optional artifacts

Outputs:

- one machine-readable JSON summary
- one short markdown report

### Gate 6

Do not start another long live proof run until this audit answers, with evidence, whether the main weak-seed failures are:

- absence
- collapse
- undervaluation
- or non-exploitation

### Phase 6 staged implementation checklist

- Phase 6A: Define fixed inputs and family views
  - Status: completed
  - Requirements:
    - hardcode the first comparison set
    - define fixed family views and fixed thresholds in one place
    - define `best_family_truth` explicitly up front
- Phase 6B: Build stage-pool extraction and diversity bundle
  - Status: completed
  - Requirements:
    - implement stage-wise pool loading from saved artifacts and handoff bundles
    - emit selected-vs-available diversity as a first-class output block
    - degrade deterministically when optional artifacts are missing
- Phase 6C: Add family-level score/truth alignment and classification
  - Status: completed
  - Requirements:
    - compute family regret and selected-vs-best family comparison
    - classify each run with:
      - `primary_failure_mode`
      - optional `secondary_failure_mode`
      - `classification_confidence`
- Phase 6D: Tests and outputs
  - Status: completed
  - Requirements:
    - focused unit tests for clustering, diversity summaries, regret, and missing artifacts
    - output one JSON summary and one short markdown report under `no_wli_catalog`
    - keep first pass simple and fixed-threshold; no live policy changes

### 2026-03-24 update

Gate 6 cleared for the first-pass audit.

Implemented:

- offline audit script:
  - `tools/benchmarks/periodic_sub_trans/no_wli/audit_basin_family_diversity_alignment.py`
- focused tests:
  - `tests/tools/test_no_wli_basin_family_diversity_alignment_audit.py`

Generated outputs:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_family_diversity_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_family_diversity_audit_report.md`

What the audit established on the fixed hard-seed comparison set:

- `seed211_current_preserve`
  - primary failure mode: `good_family_absent`
  - classification confidence: `0.75`
  - interpretation:
    - the run never reaches a family close enough to the stronger historical `seed211` reference
- `seed411_current_preserve`
  - primary failure mode: `good_family_undervalued`
  - secondary contributor: `good_family_absent`
  - classification confidence: `0.99`
  - interpretation:
    - a truth-better challenger family appears in `phasec_start`
    - but live score still backs the wrong family and the final artifact falls back to `stage2_search`

Aggregate first-pass result:

- failure-mode counts on the comparison set:
  - `good_family_absent = 1`
  - `good_family_undervalued = 1`
- this supports the earlier concern that more than one weak-seed failure mode is active
- it also means another generic long live proof is still not the right next move

Validation:

- `C:\\Python\\Python311\\python.exe -m py_compile tools/benchmarks/periodic_sub_trans/no_wli/audit_basin_family_diversity_alignment.py tests/tools/test_no_wli_basin_family_diversity_alignment_audit.py`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_basin_family_diversity_alignment_audit.py -q`
  - `5 passed`
- `C:\\Python\\Python311\\python.exe tools/benchmarks/periodic_sub_trans/no_wli/audit_basin_family_diversity_alignment.py`

## Current next action

Immediate next action:

- do not start another long live proof run yet
- use the saved `resume_handoffs` bundles for targeted resumed experiments, split by failure mode:
  - `seed211`
    - test whether the saved Stage-2 handoff can be lifted by Stage-3 policy changes at all
    - if not, the next work shifts upstream or toward stronger early/mid signals
  - `seed411`
    - test family-level ranking / selection changes on the saved downstream handoff
    - the key question is whether the truth-better challenger family can be promoted when the handoff is held fixed
- only after those targeted resumed experiments decide whether the next full run should target:
  - upstream search/generation
  - family-level scoring/ranking
  - or later within-family refinement

## Phase 7: Targeted resumed experiments split by failure mode

### Goal

Use the saved artifact-handoff resume path to separate:

- `seed211` as a Stage-3 basin reach / policy question
- `seed411` as a downstream family-ranking / selection question

This phase is still intentionally narrower than a new live proof run.
The purpose is to use fixed saved handoffs to learn faster about which downstream changes are actually worth a new expensive run.

### Phase 7 staged implementation checklist

- Phase 7A: Resume override surface
  - Status: completed
  - Requirements:
    - allow hardcoded Stage-3 / Phase-C config overrides on saved handoffs
    - keep this local to artifact-resume tooling; do not add CLI args
- Phase 7B: `seed211` fixed-handoff Stage-3 policy probe
  - Status: in progress
  - Requirements:
    - use the saved `seed211` weak-handoff artifact
    - compare a small fixed Stage-3 policy grid
    - report whether the saved handoff can be lifted at all
- Phase 7C: `seed411` fixed-handoff Phase-C ranking probe
  - Status: pending
  - Requirements:
    - use the saved `seed411` weak-handoff artifact
    - compare a small fixed family-ranking / lexical-gate grid
    - report whether the truth-better challenger family can be promoted on the same handoff
- Phase 7D: Focused tests and reports
  - Status: pending
  - Requirements:
    - artifact-resume tests prove override propagation
    - probe outputs produce one machine-readable summary and one short markdown report per seed

### 2026-03-24 resume-fidelity update

Phase 7A is now complete.

Implemented:

- artifact-resume override surface accepts hardcoded `run_config_override` mapping merges for:
  - Stage-3 policy probes
  - Stage-3.5 / Phase-C ranking probes
- normal completed runs now prefer writing the **actual live Stage-2/Stage-3 handoff** into:
  - `resume_handoffs/.../stage2_resume.json`
  - `resume_handoffs/.../stage3_prep.json`
- artifact resume now prefers a saved handoff bundle when it exists and only falls back to reconstructing from `stage2_topk` when the bundle is missing

Why this pivot was necessary:

- the first resumed `seed211` baseline built from reconstructed `stage2_topk` only reached `0.268`
- the real live weak-seed baseline for the same seed is `0.574`
- that made the reconstructed handoff too weak to trust for downstream Stage-3 policy science

Important limitation:

- the existing weak-seed bundles from:
  - `20260324T004559684950Z__bench_solve_pipeline_no_wli__55b7159`
  - `20260324T040609368464Z__bench_solve_pipeline_no_wli__55b7159`
  were written **before** the live-handoff fidelity fix
- their manifests therefore do not yet carry a live-source marker and should be treated as reconstructed-bundle outputs

Validation:

- focused tests:
  - `tests/tools/test_no_wli_artifact_resume.py`
  - `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - `tests/tools/test_no_wli_truth_diagnostics.py`
  - result: `11 passed`

Next action:

- run one fresh single-seed `seed211` preservation pass with the new bundle writer enabled
- use that fresh live bundle as the baseline source for the resumed Stage-3 policy probe

### 2026-03-24 resumed-probe entrypoint hardening

Phase 7 setup tightened while the fresh `seed211` live-bundle refresh run is active.

Implemented:

- shared probe source-selection helper:
  - `tools/benchmarks/periodic_sub_trans/no_wli/resume_probe_utils.py`
- updated Phase 7 entrypoints:
  - `tools/benchmarks/periodic_sub_trans/no_wli/resume_seed211_stage3_policy_probe.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/resume_seed411_phasec_ranking_probe.py`

What changed:

- resumed probe scripts now prefer the latest artifact for the target seed whose resume manifest records:
  - `stage2_to_stage3.source = "live_stage3_pipeline"`
- if no live bundle exists yet, they fall back to the explicit historical artifact path already frozen in the script
- probe summaries now record:
  - source selection reason
  - selected bundle source
  - selected manifest relpath
  - live-bundle candidate count
  - per-variant resume source / bundle dir relpath
- shared checkpoint summarization now reports:
  - best-truth row
  - best-score row
  - anchor row
  - lexical request / threshold-skip / tiebreak totals

Focused tests added:

- `tests/tools/test_no_wli_resume_probe_scripts.py`

Validated with:

- `C:\\Python\\Python311\\python.exe -m py_compile tools/benchmarks/periodic_sub_trans/no_wli/resume_probe_utils.py tools/benchmarks/periodic_sub_trans/no_wli/resume_seed211_stage3_policy_probe.py tools/benchmarks/periodic_sub_trans/no_wli/resume_seed411_phasec_ranking_probe.py tests/tools/test_no_wli_resume_probe_scripts.py`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_truth_diagnostics.py -q`
  - `16 passed`

Current state:

- the fresh `v33` live `seed211` refresh run is still active
- therefore:
  - Phase 7B remains in progress pending the new live bundle
  - Phase 7C entrypoint is ready and tested, but no new probe output should be claimed yet

### 2026-03-24 live handoff commit-path fix

The fresh `v33` `seed211` refresh run finished at the same weak `0.574`, but its
resume manifest still reported:

- `stage2_to_stage3.source = "reconstructed_stage2_topk"`

That proved the earlier "live handoff" work had not actually survived the real
iteration commit path.

Root cause:

- `stage3_iteration_flow` was correctly producing:
  - `stage2_resume_live`
  - `stage3_prep_live`
- but the commit bridge was reading the original runner state instead of the
  per-iteration state produced by the matrix flow
- so `write_resume_handoff_artifacts(...)` never saw the live handoff payloads
  and always fell back to reconstruction

Implemented:

- threaded an optional `bridge_state` through the real commit callback chain:
  - `run_manifest_setup.py`
  - `run_progress.py`
  - `run_pipeline_execution.py`
  - `iteration_finalize.py`
  - `iteration_post_stage3.py`
- kept backward compatibility for simple finalize-time stub callbacks that do
  not accept `bridge_state`

Meaningful regression coverage:

- extended `tests/tools/test_no_wli_resume_handoff_artifacts.py` with a real
  callback-path test that exercises:
  - `build_commit_iteration_callback(...)`
  - `commit_iteration_with_checkpoint(...)`
  - `commit_iteration_outputs_bridge(...)`
- the test proves a live per-iteration handoff reaches the emitted bundle
  manifest and writes:
  - `stage2_to_stage3.source = "live_stage3_pipeline"`

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_truth_diagnostics.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_runner_bindings_commit_bridge.py -q`
  - `27 passed`

Current next action:

- rerun one fresh single-seed `seed211` preservation job to confirm a real
  emitted bundle now records:
  - `stage2_to_stage3.source = "live_stage3_pipeline"`
- only after that should the resumed `seed211` Stage-3 policy probe be treated
  as faithful to the live weak-seed handoff

### 2026-03-24 `v34` live refresh setup and resumed scorer path fix

Prepared the next fresh single-seed live confirmation session:

- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - `RUN_SEEDS = (211,)`
  - same `stage3_preserve_tieband_probe_p9` preset
  - fresh session files:
    - `fixture_matrix_run_state_tune_v34_p9c3_stage3_preserve_seed211_livebundle.json`
    - `fixture_matrix_run_events_tune_v34_p9c3_stage3_preserve_seed211_livebundle.jsonl`
    - `fixture_matrix_plan_tune_v34_p9c3_stage3_preserve_seed211_livebundle.json`

Also fixed the resumed `seed411` ranking probe failure:

- root cause:
  - replay/resume scorer construction was passing
    `span_hamming_assets_dir = "assets/scoring/..."`
    through without resolving it against the repo root
  - that made resumed probes look under
    `tools/benchmarks/periodic_sub_trans/no_wli/assets/...`
    instead of the actual repo assets directory
- fix:
  - `tools/benchmarks/periodic_sub_trans/no_wli/replay_phasec_rescue_sweep.py`
  - `_build_stage3_scorer_runtime(...)` now resolves
    `span_hamming_assets_dir` with the same repo-root semantics used elsewhere

Meaningful regression added:

- `tests/tools/test_no_wli_artifact_resume.py`
  - verifies `_build_stage3_scorer_runtime(...)` resolves repo-relative
    span-hamming assets before calling `build_scorer(...)`

Validation:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_resume_probe_scripts.py -q`
  - `23 passed`

Operational note:

- an interrupted `seed411` resumed ranking probe process was stopped cleanly
- it left no completed summary output and should be treated as not run

### 2026-03-24 resumed scorer path follow-up and proactive sweep

The first resumed `seed411` IDE-path fix only covered the primary Stage-3 scorer
runtime. A second immediate failure then exposed the same repo-relative-path
problem inside the word-ngram report scorer construction.

Implemented:

- `tools/benchmarks/periodic_sub_trans/no_wli/replay_phasec_rescue_sweep.py`
  - `_build_stage3_word_ngram_report_runtime(...)` now resolves:
    - `judge_scorer.span_hamming_assets_dir`
    - word-ngram sqlite paths via the existing repo-root resolver path
- `tools/benchmarks/periodic_sub_trans/no_wli/analyze_phasec_slice_signals.py`
  - `_build_scorer_runtime(...)` now resolves repo-relative
    `span_hamming_assets_dir` before constructing `ScoringConfig(...)`

Meaningful regression coverage:

- `tests/tools/test_no_wli_artifact_resume.py`
  - added a word-ngram runtime path-resolution regression
- `tests/tools/test_no_wli_phasec_slice_signal_analysis.py`
  - added a slice-signal scorer-runtime path-resolution regression

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `27 passed`

Operational confirmation:

- a short-start smoke of:
  - `tools/benchmarks/periodic_sub_trans/no_wli/resume_seed411_phasec_ranking_probe.py`
- no longer crashes immediately on startup from IDE-style launch context
- after 20 seconds it was still running and had to be stopped manually, which is
  the expected healthy shape for a real resumed probe rather than an immediate
  repo-relative asset-path failure

### 2026-03-25 resumed Stage-3 scorer leak and commit-bridge crash fixes

Two new real failures were exposed by the fresh resumed/live reruns:

1. `resume_seed411_phasec_ranking_probe.py` still crashed later in the resumed
   Stage-3 path after Phase A / Phase B started running
   - root cause:
     - `artifact_resume.run_stage3_resume_from_artifact(...)` was still handing
       raw repo-relative scorer configs back into the live Stage-3 flow state
     - those configs later reached `run(...)` inside `stage3_two_phase.py`, and
       the scorer builder then looked under
       `tools/benchmarks/periodic_sub_trans/no_wli/assets/...`
2. the fresh live `seed211` rerun crashed at finalize/commit time with:
   - `KeyError: 'base'`
   - root cause:
     - `runner_bridges.commit_iteration_outputs_bridge(...)` still required
       `state["base"]` only to format elapsed time
     - that assumption does not hold on the modern commit-bridge callback path

Implemented:

- `tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume.py`
  - added repo-root resolution for scorer-config path fields before pushing
    configs into the resumed Stage-3 flow state:
    - `span_hamming_assets_dir`
    - `word_ngram_judge_sqlite_path`
    - `word_ngram_report_sqlite_path`
    - `sqlite_path`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_bridges.py`
  - removed the hard dependency on `state["base"]` from
    `commit_iteration_outputs_bridge(...)`
  - added a local time-format fallback for commit/heartbeat logging

Meaningful regression coverage:

- `tests/tools/test_no_wli_artifact_resume.py`
  - resumed Stage-3 flow now proves repo-relative scorer cfg paths are resolved
    before `run_stage3_iteration_flow(...)` sees them
- `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - commit bridge now proves it can execute without `state["base"]`
    and still format elapsed time correctly

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `29 passed`

Operational confirmation:

- the old fresh `seed211` preservation rerun under
  `output/tools/benchmarks/periodic_sub_trans/no_wli/20260325T031806162834Z__bench_solve_pipeline_no_wli__55b7159`
  did complete the live solve path before failing
  - weak result remained unchanged:
    - `stage3_phaseB best_match = 0.581`
    - `stage3_phaseC best_match = 0.574`
  - the failure was at finalize/commit only:
    - `KeyError: 'base'`
- after the `commit_iteration_outputs_bridge(...)` fallback fix, that crash
  class is now covered directly by a regression test
- the currently running repaired `seed411` resumed ranking probe
  (`resume_seed411_phasec_ranking_probe.py`) is still active under load
  - process observed alive after startup with substantial CPU / memory use
  - no completed variant output has been emitted yet, so no new result should
    be claimed until it exits cleanly

### 2026-03-25 cwd-relative offline output-root hardening

While monitoring the live resumed `seed411` probe, a second IDE-only bug class
showed up:

- several offline / replay no-WLI scripts still defined `OUTPUT_ROOT` as a bare
  `Path("output/...")`
- when launched from an IDE with a script-local working directory, those runs
  wrote under:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/...`
  - instead of the intended repo-root output tree
- this is why the active repaired `seed411` probe first appeared to have no
  output under `output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume`

Implemented:

- repo-root anchored `OUTPUT_ROOT` for:
  - `tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/analyze_phasec_slice_signals.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/profile_word_ngram_tiebreak.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/replay_phasec_rescue_sweep.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/replay_stage35_substitution_solver.py`

Meaningful regression coverage:

- `tests/tools/test_no_wli_artifact_resume.py`
  - now proves `artifact_resume.OUTPUT_ROOT` is repo-anchored
- `tests/tools/test_no_wli_output_root_paths.py`
  - sweeps the offline no-WLI replay / profiling scripts and proves their
    `OUTPUT_ROOT` values are absolute repo-root paths

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_output_root_paths.py -q`
  - `15 passed`

Operational note:

- the currently running `seed411` resumed probe started before this hardening,
  so its live output root is still the mislocated tree:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe`
- future IDE launches should now land under the correct repo-root output tree

### 2026-03-25 holistic commit-state overlay fix

The next live `seed211` rerun exposed that the commit callback path was still
structurally wrong even after the earlier point fixes:

- first failure:
  - `KeyError: 'base'`
- second failure after that:
  - `KeyError: 'write_json'`

Root cause:

- the commit callback in
  `tools/benchmarks/periodic_sub_trans/no_wli/run_pipeline_execution.py`
  was replacing the full runner state with the sparse per-iteration
  `bridge_state`
- that sparse state is only meant to carry live iteration overlays like:
  - `stage2_resume_live`
  - `stage3_prep_live`
- it is not supposed to replace the runner-wide helpers and services such as:
  - `base`
  - `write_json`
  - summary / hashing / snapshot writers

Implemented:

- added `_resolve_commit_bridge_state(...)` in
  `tools/benchmarks/periodic_sub_trans/no_wli/run_pipeline_execution.py`
- commit-time state now merges:
  - full `runner_state`
  - plus sparse `bridge_state` overrides
- this fixes the bug class holistically instead of chasing missing keys one by
  one inside the bridge

Meaningful regression coverage:

- `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - the real commit-callback integration test now passes a truly sparse
    per-iteration `bridge_state` and still proves live handoff emission works
  - added a direct merged-state regression for the callback overlay contract

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `12 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py -q`
  - `32 passed`

### 2026-03-25 pipeline hardening review and explicit bridge contract

Hardening follow-up from the recurring live commit failures:

- the merge fix alone still left one structural problem:
  - `iteration_post_stage3.py` was passing the whole mutable iteration
    `state` as `bridge_state`
- that kept the bridge contract too loose and risked future shadowing of runner
  services even after the merge fix

Implemented:

- added explicit bridge helpers in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/commit_bridge_state.py`
- `run_pipeline_execution.py`
  - `_resolve_commit_bridge_state(...)` now delegates to the explicit helper
  - unexpected bridge override keys now fail fast instead of silently
    shadowing runner services
- `iteration_post_stage3.py`
  - now extracts and passes only the live handoff payloads:
    - `stage2_resume_live`
    - `stage3_prep_live`

Meaningful regression coverage:

- `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - added regression that unexpected bridge override keys are rejected
  - added regression that bridge extraction keeps only the live handoff payloads
  - existing real callback-path live-handoff test remains in place

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `14 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py -q`
  - `34 passed`

Review artifact:

- detailed findings and next-step hardening notes captured in:
  - `planning/working/no_wli_pipeline_hardening_review_2026-03-25.md`

### 2026-03-25 continued pipeline hardening: stage-engine contract, commit services, and batch-scoring contract

Manual pipeline trace continued after the explicit commit-bridge fix.

Additional structural issues found:

- the stage-engine route was still relying on broad state copying
  - `iteration_matrix_flow.py` had already been tightened earlier in the day
  - review continued through the stage-engine / finalize / commit route to
    look for the same bug class elsewhere
- the commit bridge still assumed required runner services existed and were
  callable
  - that meant the next bad state-shape regression would still surface late as
    an opaque `KeyError`
- `iteration_post_stage3.py` still had one last silent fallback:
  - `state.get("REQUIRE_BATCH_SCORING", True)`
  - that was no longer appropriate once the explicit finalize-state builder was
    guaranteed to provide the field

Implemented:

- `tools/benchmarks/periodic_sub_trans/no_wli/commit_bridge_state.py`
  - added required commit runner-service validation
  - bridge resolution now fails early if required services are missing or
    non-callable
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_post_stage3.py`
  - removed the silent default for `REQUIRE_BATCH_SCORING`
  - finalize now treats it as an explicit live-path contract value
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_finalize.py`
  - removed runtime signature inspection around `bridge_state` forwarding
  - callback forwarding is now explicit when a bridge payload is present
- `tools/benchmarks/periodic_sub_trans/no_wli/stage_engine_contract.py`
  - narrowed the profile overlay state to the exact stage-spec keys that
    builder needs
  - removed the lower-risk whole-state copy from that path

Meaningful regression coverage added:

- `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - missing commit runner-service rejection
  - non-callable commit runner-service rejection
- `tests/tools/test_no_wli_iteration_finalize_word_ngram.py`
  - still passes after explicit callback forwarding removed the old reflection
    path
- `tests/tools/test_no_wli_stage_engine_contract.py`
  - added regression that stage2/stage3 override values survive the narrowed
    profile overlay without carrying unrelated state
- existing stage-engine and iteration-matrix contract tests kept in the
  targeted slice

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `30 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py -q`
  - `50 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py -q`
  - `52 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_stage_engine_contract.py -q`
  - `57 passed`

Current state at this checkpoint:

- handoff/commit reliability is better defended than before
- the most important remaining live blocker is still fresh end-to-end
  confirmation that the single-seed `seed211` run clears commit and writes the
  live handoff manifest
- solve quality is unchanged; this work is pipeline-hardening, not solve
  improvement

### 2026-03-25 continued pipeline hardening: Stage1/Stage2 contract validation and late-path fail-open removal

Manual review continued through the remaining main live-route layers after the
commit/state fixes.

Additional structural issues found:

- `stage12_pipeline.py` still accepted Stage1/Stage2 return payloads through
  `.get(...)` defaults
  - that meant a missing key could silently degrade into a plausible-looking
    empty value and only fail much later
- `iteration_pre_stage3.py` mirrored the same permissive defaults after
  Stage1/Stage2 had already completed
- `run_progress.py` silently ignored unknown `status_key` values during manifest
  checkpointing
- `stage_iteration_commit.py` still tolerated missing late-path fields by using
  `.get(...)` fallbacks on required instance/artifact payload values

Implemented:

- `tools/benchmarks/periodic_sub_trans/no_wli/stage12_pipeline.py`
  - added explicit required-key validation for:
    - `run_stage1_substitution_fn`
    - `run_stage2_search_fn`
    - `finalize_stage2_archive_fn`
  - added basic shape validation for required list/mapping payload fields
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_pre_stage3.py`
  - removed mirrored Stage1/Stage2 `.get(...)` fallbacks
  - pre-stage3 now consumes the validated Stage12 payload by explicit keys
- `tools/benchmarks/periodic_sub_trans/no_wli/run_progress.py`
  - unknown status keys now raise early instead of being dropped silently
- `tools/benchmarks/periodic_sub_trans/no_wli/stage_iteration_commit.py`
  - required artifact and instance fields now use explicit key access

Meaningful regression coverage added:

- `tests/tools/test_no_wli_stage12_pipeline.py`
  - happy-path Stage12 contract
  - missing Stage1 key rejection
  - missing Stage2 search key rejection
  - wrong Stage2 search archive shape rejection
  - missing Stage2 finalize key rejection
- `tests/tools/test_no_wli_stage_iteration_commit.py`
  - missing `profile_id` rejection in the late commit path
- `tests/tools/test_no_wli_oracle_contract.py`
  - unknown status-key rejection in checkpoint manifest accounting

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_stage12_pipeline.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_stage_engine_contract.py -q`
  - `62 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_stage12_pipeline.py tests/tools/test_no_wli_stage_iteration_commit.py tests/tools/test_no_wli_oracle_contract.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_output_root_paths.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_stage_engine_contract.py tests/tools/test_no_wli_run_completion.py -q`
  - `70 passed`

Current state at this checkpoint:

- main live-route review now covers:
  - startup
  - pre-stage3
  - Stage1 / Stage2
  - Stage3
  - finalize
  - commit
  - handoff emission
- not every sidecar helper in the tree has been exhaustively reviewed yet
- the remaining decisive proof step is still a fresh live canary run started
  after the newest hardening edits are loaded

### 2026-03-25 continued pipeline hardening: preset validation and summary/completion contracts

Manual review continued beyond the main live stage route into orchestration and
reporting layers.

Additional structural issues found:

- `fixture_matrix_api.py` silently treated an unknown non-`base`
  `stage3_tuning_preset_id` as an empty preset
  - this could waste a whole matrix run while looking valid
- `run_summary.py` still summarized live instance rows through permissive
  `.get(...)` access even though instance rows are now strongly shaped
- `run_completion.py` still treated live best-row fields and status-count keys
  as optional even though they are part of the in-process contract

Implemented:

- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - unknown non-`base` Stage-3 tuning preset IDs now raise early in both:
    - `resolve_stage3_tuning_preset_ids()`
    - `_resolve_stage3_tuning_overrides_for_job(...)`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_summary.py`
  - live summary rows now use explicit required fields
- `tools/benchmarks/periodic_sub_trans/no_wli/run_completion.py`
  - completion path now treats live best-row fields and status-count keys as
    required

Meaningful regression coverage added:

- `tests/tools/test_no_wli_fixture_matrix_runtime.py`
  - unknown preset-id rejection
- `tests/tools/test_no_wli_run_summary.py`
  - internal live summary contract
- `tests/tools/test_no_wli_run_completion.py`
  - incomplete status-count rejection

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_run_summary.py tests/tools/test_no_wli_run_completion.py tests/tools/test_no_wli_stage12_pipeline.py tests/tools/test_no_wli_stage_iteration_commit.py tests/tools/test_no_wli_oracle_contract.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_resume_probe_scripts.py tests/tools/test_no_wli_phasec_slice_signal_analysis.py tests/tools/test_no_wli_output_root_paths.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_stage_engine_parity_smoke.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_stage_engine_contract.py -q`
  - `75 passed`

Current state at this checkpoint:

- the main live route is covered
- several major sidecar/orchestration fail-open paths are now covered too
- the currently running live canary is still useful operationally, but it still
  does not validate the newest hardening batch because it started earlier

### 2026-03-25 continued pipeline hardening: runner-service contract and defaulted Stage-3 config removal

Cross-checking continued through the runner/binding layer and the remaining
central config materialization paths.

Additional structural issues found:

- commit formatting still relied on a hidden fallback inside
  `runner_bridges.py` if `_format_seconds` was absent
- several central live-path config readers still used permissive `.get(...)`
  defaults even though those keys are installed by runner defaults and should be
  treated as part of the state contract:
  - Phase-C config
  - Stage35 config
  - word-ngram decision/report config
  - span-aux config
  - resume-handoff enablement at commit

Implemented:

- `tools/benchmarks/periodic_sub_trans/no_wli/runner_bindings.py`
  - `_format_seconds` is now installed explicitly as a runner service
- `tools/benchmarks/periodic_sub_trans/no_wli/commit_bridge_state.py`
  - commit validation now requires:
    - callable `_format_seconds`
    - explicit `SAVE_RESUME_HANDOFFS`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_bridges.py`
  - removed the last internal formatting fallback
  - Phase-C runtime call-context keys now use explicit runner-state access
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_matrix_builder.py`
  - span-aux / Stage35 config now uses explicit runner-state access
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`
  - run-config emission no longer silently fabricates Phase-C / Stage35 /
    word-ngram / span-aux values
- `tools/benchmarks/periodic_sub_trans/no_wli/setup_logging_payload.py`
  - setup logging payload now uses explicit Phase-C / Stage35 keys
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_iteration_flow.py`
  - Stage35 enablement/config now uses explicit state access on the live path

Meaningful regression coverage added:

- `tests/tools/test_no_wli_runner_bindings_commit_bridge.py`
  - `_format_seconds` binding is installed on the real runner module
- `tests/tools/test_no_wli_resume_handoff_artifacts.py`
  - commit bridge uses the runner formatting service
  - missing commit runner-value rejection
- `tests/tools/test_no_wli_run_config_span_aux.py`
  - run-config builder now fails fast when required span-aux / Phase-C keys are
    absent

Validated with:

- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_runner_bindings_commit_bridge.py tests/tools/test_no_wli_run_config_span_aux.py tests/tools/test_no_wli_setup_logging.py -q`
  - `15 passed`
- `C:\\Python\\Python311\\python.exe -m pytest tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_stage_engine_iteration_bridge.py tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_run_config_span_aux.py tests/tools/test_no_wli_setup_logging.py tests/tools/test_no_wli_resume_handoff_artifacts.py tests/tools/test_no_wli_runner_bindings_commit_bridge.py -q`
  - `49 passed`

Current state at this checkpoint:

- the runner/binding layer is stricter than before and less likely to hide a
  broken state shape behind fallback behavior
- the main remaining soft contract is inside `stage3_iteration_flow.py` helper
  return payloads (`stage3_prep`, `two_phase_followup`, `stage35_followup`)
- the already-running live canary is still active and still not a proof of this
  latest batch because it started earlier

### 2026-03-25 overnight live matrix setup: weak-seed downstream comparison

Prepared the next live overnight matrix in:

- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`

Bounded design:

- keep `p9/c3` only
- weak hard seeds only:
  - `211`
  - `411`
- targeted preset lanes:
  - `stage3_preserve_tieband_probe_p9`
  - `stage3_recovery_p9_8h`
  - `stage35_proof_p9_8h`
  - `lexical_phasec_proof_wide`
  - `lexical_phasec_rescue_wide_finish`
- `STOP_ON_ERROR = False`
- `MAX_JOBS = None`
- `MAX_WALLCLOCK_SECONDS = 36000.0`

Expected materialized scope:

- `1 fixture x 1 period x 1 columns x 2 seeds x 5 presets x 1 schedule = 10 jobs`

Fresh run-state artifacts configured:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v35_p9c3_weakseed_overnight_10h.json`

Cheap materialization validation passed:

- `job_count = 10`
- `seeds = [211, 411]`
- preset ids resolved as configured

### 2026-03-26 science log and short follow-up lane

Created canonical science log:

- `planning/working/no_wli_science_run_log_2026-03-26.md`

The science log backfills, with concrete artifact evidence:

- the successful live handoff-emission canary
- the negative fixed-handoff `seed411` lexical ranking probe
- the first three completed jobs from the broad weak-seed overnight matrix

Next live follow-up lane is intentionally reduced to two jobs:

- seed:
  - `411`
- presets:
  - `stage3_preserve_tieband_probe_p9`
  - `lexical_phasec_rescue_wide_finish`

Why this reduction was made:

- the broad overnight batch proved too slow for useful iteration
- the batch stopped after three `seed211` jobs and never reached `seed411`
- `seed211` already ruled out the practical value of:
  - preserve-only lift
  - wider recovery as configured
  - Stage-3.5 as a short-cycle default lane
