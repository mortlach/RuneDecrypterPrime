# Evidence Index

This file is a compact index of the main evidence artifacts referenced in the
review pack.

## Historical capability and diagnosis

### Strong hard-case recovery

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - recovered Stage-3 hard-case basin
  - `best_match_ratio = 0.771`

### Clean Stage-3.5 proof

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - strongest current hard-case result
  - `best_match_ratio = 0.794`
  - valid live Stage-3.5 execution

### Weak-seed Stage-3.5 non-generalization

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T192204224097Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
  - weak-seed result stayed at `0.574`

### Basin regression diagnosis

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
  - primary culprit:
    - `inside_stage3_basin_generation`
  - stage2 vs stage3 evidence deltas

### Selector audit

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
  - hard-tier score/match correlation and regret
  - supports "useful but imperfect", not "totally broken"

### Partial-state signal audit

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
  - historical weak-seed baselines
  - weak early signal vs stronger late signal evidence

## Pipeline reliability evidence

### Live handoff-emission canary

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - live result stayed weak at `0.574`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
  - `stage2_to_stage3.source = "live_stage3_pipeline"`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/ops_logs/run_fixture_matrix_seed211_v34_bridge_contract_20260325T182911.stdout.log`
  - live run completion log

### Pipeline hardening review

- `planning/working/no_wli_pipeline_hardening_review_2026-03-25.md`
  - root cause and code-contract analysis of the live commit/handoff failures

## Recent negative downstream experiments

### Seed411 fixed-handoff ranking probe

- `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`
  - all tested variants ended at `resume_best_match_ratio = 0.032`

### 10-job weak-seed overnight matrix, jobs 1-3 only

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
  - broad matrix stopped after 3 jobs
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`
  - job runtimes
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - preserve lane, `best_match_ratio = 0.574`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - recovery lane, `best_match_ratio = 0.574`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - Stage-3.5 lane, `best_match_ratio = 0.574`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
  - `stage35_accept_reason = "search_score_drop_guard_failed"`

## Active short comparison run

### v36 run control files

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - defines the current 2-job short comparison
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - active progress state
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - current started-job record

### Active run directory

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159`
  - current active live run directory for job 1

## Raw planning and review snapshots included in this pack

- `appendix_science_run_log_2026-03-26.md`
- `appendix_pipeline_hardening_review_2026-03-25.md`
- `appendix_solve_integrity_plan_2026-03-21.md`
- `appendix_deep_research_report.md`
- `deep_research_pack_snapshot/`
- `evidence_snapshots/`
