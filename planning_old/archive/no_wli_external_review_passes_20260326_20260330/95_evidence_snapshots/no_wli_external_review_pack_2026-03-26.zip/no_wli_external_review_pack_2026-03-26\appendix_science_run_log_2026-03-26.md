# No-WLI Science Run Log

Purpose:

- record hypotheses, run setups, outcomes, and next actions in one verifiable place
- keep each claim tied to concrete evidence in repo-relative run artifacts
- separate "pipeline plumbing worked" from "solve quality improved"

Verification rule:

- every result claim below names at least one concrete artifact path and the field or log line that supports it
- if a claim is only an inference, it is labelled as an inference

## 2026-03-26 backfilled evidence

### Entry A: live handoff emission canary on seed211

Question:

- did the live commit / handoff path finish cleanly and emit a real live Stage-2 to Stage-3 handoff bundle?

Run:

- live canary run directory:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159`

Outcome:

- yes, the live handoff path completed and emitted a handoff bundle
- no, solve quality did not improve

Cross-checked evidence:

- handoff emitted from live pipeline:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
  - field: `stage2_to_stage3.source = "live_stage3_pipeline"`
- live result stayed weak:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage2_match_ratio = 0.209`
    - `stage3_match_ratio = 0.574`
    - `best_stage = "stage3_full_refine"`
- run finished normally:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/ops_logs/run_fixture_matrix_seed211_v34_bridge_contract_20260325T182911.stdout.log`
  - tail contains:
    - `completed in 5h56m`
    - `[no_wli_fixture_matrix] completed session_completed_jobs=1 total_completed_jobs=1`

Conclusion:

- the live handoff-emission bug class is fixed on the real path
- this was a reliability win, not a solve-quality win

### Entry B: seed411 fixed-handoff ranking probe

Question:

- can small lexical-gate / tie-window changes promote the truth-better challenger family on the saved weak seed411 handoff?

Run:

- resume probe report:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- machine summary:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`

Outcome:

- no
- all three variants ended at the same resumed best match

Cross-checked evidence:

- report table in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
  - rows show:
    - `baseline_phasec_ranking -> Resume Match 0.032`
    - `lexical_gate_035_tie_025 -> Resume Match 0.032`
    - `lexical_gate_030_tie_050 -> Resume Match 0.032`
    - `Best Truth Start 0.099`
    - `Truth Gap 0.067`
    - `Stop Reason stalled_no_improve`
- summary details in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`
  - per-variant fields show:
    - `resume_best_match_ratio = 0.032`
    - `checkpoint_summary.best_truth_match = 0.099`
    - `between_family_truth_gap = 0.067`

Conclusion:

- small lexical-gate widening was not enough on fixed seed411 downstream state
- next seed411 candidate should be meaningfully broader than a small gate tweak

### Entry C: 10-job weak-seed overnight live matrix, jobs 1-3 only

Question:

- can weak-seed live performance be lifted by preservation changes or by Stage-3.5, and can this be learned from a broad overnight matrix?

Run control files:

- run state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
- run events:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`

Outcome:

- only the first three jobs completed before the between-jobs wallclock stop
- all three completed jobs were `seed211`
- none improved beyond `0.574`
- Stage-3.5 executed for the proof lane but did not win

Cross-checked evidence:

- run stopped early after job 3:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
  - fields:
    - `completed_jobs = 3`
    - `remaining_jobs = 7`
    - `stopped_early = 1`
- event log confirms completed jobs and runtimes:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`
  - rows show:
    - job 1 `stage3_preserve_tieband_probe_p9` elapsed `13193.243979...`
    - job 2 `stage3_recovery_p9_8h` elapsed `11181.895447...`
    - job 3 `stage35_proof_p9_8h` elapsed `51995.484903...`
- job 1 result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 0`
- job 2 result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 0`
- job 3 result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 1`
    - `stage35_selected = false`
    - `stage35_archive_count = 16`
    - `stage35_rounds_completed = 3`
- job 3 Stage-3.5 rejection reason:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
  - field:
    - `stage35_accept_reason = "search_score_drop_guard_failed"`
- all three completed runs emitted live handoff bundles:
  - each run dir contains:
    - `resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
  - field:
    - `stage2_to_stage3.source = "live_stage3_pipeline"`

Conclusion:

- broad live matrices were too slow for fast iteration
- on seed211:
  - preservation baseline did not improve
  - wider recovery did not improve
  - Stage-3.5 was real and auditable, but too expensive and still lost to Stage-3

Inference:

- Stage-3.5 should not be in the default short comparison lane unless a run is explicitly about Stage-3.5 acceptance behavior

## Next run: v36 short seed411 comparison

Reason for the next run:

- the broad overnight batch never reached any `seed411` jobs
- seed411 remains the unresolved downstream-ranking case
- fixed-handoff seed411 already ruled out small lexical-gate changes
- seed211 already ruled out:
  - preserve-only lift
  - recovery-only lift
  - Stage-3.5 as a practical short-cycle fix

Hypothesis H1:

- `stage3_preserve_tieband_probe_p9` on live `seed411` gives the real current live control for that seed and emits a fresh live handoff bundle

Evidence motivating H1:

- seed411 has only fixed-handoff downstream evidence so far:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`

Hypothesis H2:

- `lexical_phasec_rescue_wide_finish` may outperform the preserved live baseline on `seed411` because it is a materially broader downstream package, not just a tiny lexical-gate tweak

Evidence motivating H2:

- small lexical-gate changes on fixed seed411 did nothing:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- the chosen candidate preset is broader by design in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - preset `lexical_phasec_rescue_wide_finish`
  - notable knobs:
    - `force_stage3_phaseb_top_n = 32`
    - `force_stage3_initial_keys = 128`
    - Phase-C rescue enabled
    - broader rescue candidate pool and polish budget

Proposed short live matrix:

- seed:
  - `411`
- presets:
  - `stage3_preserve_tieband_probe_p9`
  - `lexical_phasec_rescue_wide_finish`
- job count:
  - `2`
- config / run control files:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`

Pre-run validation:

- materialization check confirms:
  - `job_count = 2`
  - `seeds = [411]`
  - preset order:
    - `stage3_preserve_tieband_probe_p9`
    - `lexical_phasec_rescue_wide_finish`

Success criteria:

- primary:
  - candidate live `best_match_ratio` exceeds control live `best_match_ratio`
- secondary:
  - both runs emit live handoff bundles
- falsification:
  - if the broader downstream candidate does not beat the control, deprioritize downstream ranking/rescue and move attention upstream
