# RDP planning bundle v0.1

This is the second cut of the new canonical planning layout.

Compared with v0, this bundle now also:
- promotes real source planning documents into the new `rdp_v1` home
- promotes real source planning documents into the new `benchmark_campaign_v1_1` home
- adds the first cross-project timeline snapshots
- records a simple migration ledger

This is still a **controlled migration starter**, not the final canonical set.

## What changed in v0.1

### New project snapshots
- `planning/project_timeline/10_project_snapshots/no_wli_snapshot.md`
- `planning/project_timeline/10_project_snapshots/rdp_v1_snapshot.md`
- `planning/project_timeline/10_project_snapshots/benchmark_campaign_v1_1_snapshot.md`
- `planning/project_timeline/10_project_snapshots/p13_real_ciphertext_campaign_snapshot.md`

### Promoted source documents
Real source docs have now been copied into:
- `planning/projects/rdp_v1/10_governance/`
- `planning/projects/rdp_v1/20_active_plans/`
- `planning/projects/benchmark_campaign_v1_1/10_contracts/`
- `planning/projects/benchmark_campaign_v1_1/20_active_plans/`
- `planning/projects/benchmark_campaign_v1_1/30_validation_and_setup/`

## Remaining limits

This bundle still does not:
- move legacy/completed/archive material yet
- rewrite all promoted docs into the new canonical header format
- create the first real `5455` problem brief
- migrate all campaign support notes
- replace the original `planning/no_wli/` tree
