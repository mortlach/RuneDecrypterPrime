# Planning portal

This is the top entry point for the new RDP planning layout.

The goal is to keep planning readable, portable, and usable by multiple agents
without losing the evidence trail.

## Read order

For repo-wide orientation:
1. `01_PROJECT_INDEX.md`
2. `05_CANONICAL_UPDATE_FORMAT.md`
3. `project_timeline/00_MASTER_TIMELINE.md`
4. `project_timeline/01_ACTIVE_COORDINATION_BOARD.md`
5. `project_timeline/02_DEPENDENCY_MAP.md`
6. `project_timeline/20_PROBLEM_THREADS_INDEX.md`

Then move into the relevant project home under `projects/`, or into
`completed/`, `legacy/`, or `archive/` if you are following historical links.

## Current active project homes in this bundle

- `projects/rdp_v1/`
- `projects/benchmark_campaign_v1_1/`
- `projects/p13_real_ciphertext_campaign/`

## Template project

The template project is the existing `planning/no_wli/` tree in the source
planning set.

This bundle does not replace that tree yet.
It uses that tree as the pattern to generalise.

## Control-layer principles

- one global control layer
- one cross-project timeline layer
- one project home per real active project
- one small fixed status vocabulary
- reusable templates for future agent work
- support streams live under projects, not beside them
- old material should be preserved, but not allowed to compete with live truth
