# Draft cut-over decision note

This is a draft practical decision note for how to use the migrated planning
bundle right now.

## Draft decision

Use the migrated bundle as the **default working planning surface** now.

In practice this means:
- start from the bundle control layer first
- use the active project homes as the first stop for day-to-day planning work
- treat the old planning tree as fallback/reference material unless a live file
  explicitly points back to it

## Why this draft decision is reasonable now

The bundle now has:

- a strong control layer
- active homes for `rdp_v1`, `benchmark_campaign_v1_1`, and
  `p13_real_ciphertext_campaign`
- explicit support/reference layering
- explicit remaining-work and cross-check files
- cut-over criteria
- cut-over status assessment

The remaining blockers are now narrow enough that they do not prevent ordinary
use of the bundle as the main working surface.

## What this draft decision does not yet say

It does **not** yet say:
- retire every old entry habit immediately
- delete or ignore the older planning tree
- pretend every active home is fully finished

## Safer wording for near-term use

A good near-term stance is:

> Use the migrated bundle as the main working planning surface.
> Keep old paths available as fallback/reference only.
> Finish one or two remaining narrow cleanup slices before making the final
> full-retirement call on older entry habits.

## Conditions for turning this draft into a final cut-over decision

Before turning this into a final cut-over decision, it would still help to:
- finish the last narrow `rdp_v1` support-layer trim
- accept the benchmark reference-bundle pass as sufficient
- add the first empirical p13 comparison/control result note
