# Document map

## Archived source locations preserved in this bundle

### Core phased/refactor review material
- earlier phased/review pack files already preserved in this archive home

### External handoff note
- `planning/old/external_reviewer_handoff_20260307.txt`
  - preserved here as:
    `external_reviewer_handoff_20260307.txt`

## Why preserved

This archive captures a real older refactor/review period and now also includes
the external handoff note that summarised completion and focused validation for
that stream.
