# Archive index

This area is for preserved planning packs that are worth keeping together, but
should not compete with the live homes, completed homes, or legacy homes.

## Current archive homes

- `phased_refactor_and_review/`
- `no_wli_planning_refactor_20260404/`
- `no_wli_stage35_transition_20260402/`
- `forensic_audit_2026/`

## Rule

Archive homes preserve structure and history.
They are not the place to start current work unless a live document explicitly
sends the reader there.
