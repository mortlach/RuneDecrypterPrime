# Document map

## Archived source location

- `planning/archive/no_wli_planning_refactor_20260404/`

## Why preserved

This pack matters because it captures the shape that became the migration
template:
- short top control layer
- numbered deeper evidence folders
- clear split between live truth and legacy index

## Main archived categories

- `00_CURRENT_STATE.md`
- `01_EXPERIMENT_INDEX.md`
- `02_OPEN_QUESTIONS.md`
- `03_DOCUMENT_MAP.md`
- `04_ACTIVE_RUNBOOK.md`
- `10_full_logs/`
- `20_active_plans/`
- `30_analysis_specs/`
- `40_review_summaries/`
- `50_console_and_watch_logs/`
- `60_launch_scripts/`
- `90_legacy_index/`
