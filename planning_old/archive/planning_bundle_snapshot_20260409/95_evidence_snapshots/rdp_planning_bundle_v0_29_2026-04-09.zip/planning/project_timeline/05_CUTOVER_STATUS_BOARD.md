# Cut-over status board

This is the short board for how close each active home is to acting as default
planning truth.

| Home | Current cut-over status | Main blocker |
|---|---|---|
| `rdp_v1` | very close | final support-layer trim |
| `benchmark_campaign_v1_1` | close and now likely sufficient for default use | no full final trim on older reference material |
| `p13_real_ciphertext_campaign` | coherent but still earlier-stage | first empirical comparison/control result note |
| bundle-wide control layer | strong enough for everyday use | no explicit canonical cut-over decision yet |

## Practical reading

Today’s bundle is strong enough to use as the **main working planning surface**.

The safer near-term stance is:
- use this bundle by default now
- keep old paths as fallback/reference only
- make the final stronger cut-over call after one or two more narrow slices
