# Project index

This is the top-level map of the planning system.

## Active project homes

- `projects/project_workflow/`
  - the project about projects
  - defines the standard project shape and agent update/logging rules
- `projects/rdp_v1/`
  - repo-level convergence and release-shaping home
  - active home with schema-normalisation pass completed
- `projects/benchmark_campaign_v1_1/`
  - general benchmark and p13-learning campaign home
  - active home with schema-normalisation pass completed
- `projects/p13_real_ciphertext_campaign/`
  - downstream real-ciphertext p13 thread home
  - active home with schema-normalisation pass completed

## Upstream reference home kept outside this migration focus

- `planning/no_wli/`
  - upstream method-development and solver-learning home
  - referenced, not re-homed here

## Other homes

- `completed/*`
- `archive/*`
- `legacy/*`

## Reading rule

Start from:
1. this project index
2. the project_workflow home if you need structure/rules
3. the relevant active project home
