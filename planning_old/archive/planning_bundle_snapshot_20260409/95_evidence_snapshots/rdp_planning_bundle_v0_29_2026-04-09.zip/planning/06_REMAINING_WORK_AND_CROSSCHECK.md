# Remaining work and crosscheck

This file lists the main work still left to do in the migration, including the
cross-check work still needed.

## A. Global framework work still left

### A1. Decide when the new bundle becomes the canonical truth
Still not done:
- the bundle is now strong enough for default working use
- but the final stronger cut-over call has not yet been made

Need:
- use `07_CANONICAL_CUTOVER_CRITERIA.md`
- use `08_CANONICAL_CUTOVER_STATUS_2026-04-09.md`
- use `09_DRAFT_CUTOVER_DECISION_NOTE.md`
- decide when to convert the draft decision into a final one

### A2. Decide what to do with the remaining old clusters
Still not done:
- several old folders remain only partially triaged
- not every old note should be moved

Need:
- selective triage, not full evacuation

Likely remaining clusters worth reviewing:
- `planning/old/v1OLD/add_cribs_2/`
- `planning/old/v1OLD/seed_gen_plans`
- `planning/old/v1OLD/tests/`
- `planning/old/v1OLD/tools/`
- `planning/old/workgin/`
- `planning/old/external_reviewer_handoff_20260307.txt`
- `planning/old/nowli_imrpovements_refactor_for_benchcamp.txt`
- `planning/old/nowli_imrpovements_refactor_for_benchcamp_review.txt`

### A3. Decide whether to copy any live no-WLI planning into this bundle
Still not done:
- we deliberately avoided a large-scale live no-WLI copy

Need:
- decide whether the final canonical planning system should:
  - reference the source `planning/no_wli/` tree only
  - or absorb a controlled copy later

## B. Cross-checking still left

### B1. Re-check the active homes against the code/tests again
Still worth doing:
- `rdp_v1`
- `benchmark_campaign_v1_1`
- `p13_real_ciphertext_campaign`

Need:
- another pass after any further support-note triage
- especially if support layers move into archive

### B2. Re-check the benchmark scoring/Torch support notes against current tests
We now have a detailed freshness judgement.
Still needed:
- later archive decision if the historical-but-useful notes become clearly superseded

### B3. Re-check `rdp_v1` support notes against current code surfaces
We now have a detailed freshness judgement.
Still needed:
- decide which support notes stay live support
- decide which move to archive later
- keep owner-review scaffolding from silently becoming live truth

### B4. Re-check the p13 real-ciphertext pack against actual code/results
Still needed:
- the first empirical method/run comparison
- the next result note beyond payload parity and contract definition
- confirmation of which solve-proof and no-WLI results are the right first upstream anchors

## C. Project-home work still left

### `rdp_v1`
Still left:
- tighten current-state wording further
- decide if some support layers should be moved to archive later
- decide what the cut-over file set is
- cross-check support notes against live code again

### `benchmark_campaign_v1_1`
Still left:
- classify remaining support notes into:
  - active support
  - archive
  - maybe redundant duplicates
- decide whether some old benchmark duplicates should remain out of the live home

### `p13_real_ciphertext_campaign`
Still left:
- write the next real result note
- choose the first empirical method/run comparison
- decide whether any broader p13 notes should become archived project reference
- continue checking for genuinely relevant old notes without inventing them

## D. What not to do

Do not:
- bulk-move everything left in `planning/old/`
- pretend all support notes are current truth
- collapse archive/reference/support layers back into the live entry files
