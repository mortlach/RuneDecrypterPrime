# Canonical cut-over status — 2026-04-09

This note applies the canonical cut-over criteria to the current migrated
planning bundle.

## Overall judgement

**Not fully canonical yet, but close enough that the control layer and most of
the active homes are already usable as the default working surface.**

The main remaining blockers are no longer structural chaos.
They are now specific and narrow:

- `rdp_v1` still needs one final judgement on which historical support notes stay
  in the active home versus move to archive later
- `benchmark_campaign_v1_1` still needs one more pass on the older benchmark
  reference bundle
- `p13_real_ciphertext_campaign` still lacks the first empirical
  comparison/control attempt note
- the repo-wide cut-over decision itself has not yet been explicitly made

## Criteria assessment

### A1. Each active home has a stable live pack
Assessment:
- **mostly yes**

`rdp_v1`:
- yes, with current state / workstream / document map / runbook / remaining work
  and crosscheck notes present

`benchmark_campaign_v1_1`:
- yes, with the same basic live pack plus crosscheck notes

`p13_real_ciphertext_campaign`:
- nearly yes; the structure is there, but the home is still intentionally thin
  because it lacks the first empirical attempt/result note

### A2. Support/reference layers are clearly secondary
Assessment:
- **yes**

Both `rdp_v1` and `benchmark_campaign_v1_1` now have:
- freshness notes
- recommended keep sets
- clearer split between active support and historical-but-useful support

`p13_real_ciphertext_campaign` also now clearly separates:
- direct `5455` thread files
- broader p13 readiness context

### A3. Cross-project control layer is readable
Assessment:
- **yes**

The bundle now has:
- project index
- master timeline
- co-ordination board
- dependency map
- problem-thread index
- remaining-work file
- crosscheck status file
- cut-over criteria file

### A4. Legacy/archive no longer compete with live entry points
Assessment:
- **mostly yes**

The archive/legacy layers are now much better separated.
The main remaining issue is not competition from archive, but whether the new
homes are strong enough that people will actually stop starting from the old
paths.

## Current blocker summary

### Blocker 1 — no explicit cut-over decision yet
The bundle now has criteria, but not yet the explicit decision:
- "from here on, use this as the default planning surface"

### Blocker 2 — `rdp_v1` support-layer final trim
The home is strong, but some secondary notes are still only triaged as
historical-but-useful rather than fully resolved.

### Blocker 3 — `benchmark_campaign_v1_1` older reference bundle pass
The scoring/Torch support layer is now clearer, but the older benchmark
reference bundle still needs one more targeted pass.

### Blocker 4 — `p13_real_ciphertext_campaign` still lacks the first empirical note
The home is now well-formed, but it is not yet through the first genuinely
empirical comparison/control step.

## Practical conclusion

The bundle is now good enough to act as the **main working draft planning
surface**.

It is not quite ready to declare that:
- all older entry habits should be retired immediately.

A sensible near-term stance is:

- treat this bundle as the default working surface now
- keep old paths as fallback/reference only
- do one or two more narrow slices
- then make the explicit canonical cut-over decision
