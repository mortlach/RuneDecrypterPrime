# Archive links

Status: active
Work status: done
Project: rdp_v1

This folder contains short links and notes pointing to larger archive packs that
matter to `rdp_v1`, without pulling those packs into the front-door reading path.
