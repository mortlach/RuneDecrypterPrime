# RDP v1 cut-over status — 2026-04-09

Status: active
Work status: in_progress
Project: rdp_v1

## Current judgement

`rdp_v1` is **very close** to being good enough as the default live project home.

## What already passes

- current state exists and is meaningful
- workstream index matches the real project shape
- document map is substantial
- active runbook exists
- remaining-work file exists
- code-crosscheck notes exist
- support/reference layers are clearly more secondary than before

## What still blocks full confidence

### 1. Final support-layer trim
The home still contains some notes that are now only:
- historical but useful
- possible archive-later candidates

That is fine for now, but it weakens a fully clean cut-over claim.

### 2. Present-truth wording could still be slightly tighter
The current-state and live-pack wording are already good, but could still be
made a bit more explicitly canonical.

## Practical judgement

Safe to treat as the default working home in most chats.

Still worth one more narrow cleanup pass before declaring the old v1 reading
habit fully retired.
