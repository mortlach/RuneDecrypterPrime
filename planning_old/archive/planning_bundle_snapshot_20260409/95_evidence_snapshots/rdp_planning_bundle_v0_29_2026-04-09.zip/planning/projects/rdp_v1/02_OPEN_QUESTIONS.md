# Open questions

## V1. How much of the v1 plan is already truly landed in code?
This needs a stricter split into:
- already landed
- partly landed
- still target-state only

## V2. What is the minimum canonical `rdp_v1` pack?
Likely:
- current state
- workstream index
- open questions
- document map
- active runbook

Do not start with every historical v1 note.

## V3. Which support docs belong under `rdp_v1` and which belong under the campaign project?
The campaign spec is relevant to v1, but the community benchmark campaign should
have its own home.

## V4. When should the old active index be retired?
Only after the new `rdp_v1` current-state and document-map files are good enough
to replace it.
