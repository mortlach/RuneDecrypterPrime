# Active runbook

Status: active
Work status: in_progress
Project: rdp_v1

## Immediate goal

Use the new normalised `rdp_v1` shape as the model active project home.

## Reading order

1. front-door files
2. `10_governance/`
3. `20_active_plans/`
4. `30_architecture_specs/`
5. `40_supporting_reference/` only as needed
6. `90_archive_links/` only if historical depth is needed

## Safe next steps

1. keep the front-door pack small and stable
2. keep `RunSpec` / `SolverReport` wording honest
3. decide whether any secondary notes should later move further back into archive
4. avoid letting support/reference notes become competing entry points

## What not to do yet

- do not reopen bulk legacy migration
- do not let the supporting-reference layer become the new front door
- do not try to solve every architecture question in one pass
