# Maintainer reference

Status: active
Work status: done
Project: rdp_v1

This folder preserves maintainer-facing reference notes that still matter to
`rdp_v1`, but are not the main live project pack.

## Included in this slice

- `maintainer_handbook_v2.txt`
- `rdp_private_maintainer_handbook_skeleton_2026-03-09.md`

## Working rule

Use these as support/reference for maintainer-facing workflow and expectations.

Do not let them replace the live:
- current state
- workstream index
- active runbook
