# Active-home mapping matrix — 2026-04-09

Status: active
Work status: done
Project: project_workflow

## `rdp_v1`

Current shape highlights:
- governance
- active plans
- architecture specs
- support matrices
- maintainer reference
- integration history
- scoring/assets history
- forensic reference
- evidence snapshots

Target grouping:
- `10_active_plans/`
- `20_specs_and_analysis/`
- `30_status_and_results/`
- `40_supporting_reference/`
  - support matrices
  - maintainer notes
  - integration history
  - scoring/assets history
  - forensic reference
- `95_evidence_snapshots/`

## `benchmark_campaign_v1_1`

Current shape highlights:
- contracts
- active plans
- validation/setup
- scoring/Torch support
- reference packs
- future-method ideas
- legacy seed/solve reference
- evidence snapshots

Target grouping:
- `10_active_plans/`
- `20_specs_and_analysis/`
- `30_status_and_results/`
- `40_supporting_reference/`
  - scoring/Torch support
  - benchmark reference packs
  - future-method and future-architecture notes
  - legacy seed/solve reference
- `95_evidence_snapshots/`

## `p13_real_ciphertext_campaign`

Current shape highlights:
- problem briefs
- active plans
- analysis specs
- reference context
- run logs
- evidence snapshots

Target grouping:
- `10_active_plans/`
- `20_specs_and_analysis/`
- `30_status_and_results/`
- `40_supporting_reference/`
  - broader p13 reference context only
- `95_evidence_snapshots/`

## Main point

The active homes do not need identical contents.
They do need a similar reading model.
