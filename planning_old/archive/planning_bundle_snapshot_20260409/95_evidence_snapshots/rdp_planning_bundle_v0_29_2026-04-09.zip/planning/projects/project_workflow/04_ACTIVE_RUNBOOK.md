# Active runbook

Status: active
Work status: in_progress
Project: project_workflow

## Current job

Move the planning system from:
- rescued and triaged

to:
- normalised and consistent

## Immediate next steps

1. note that all three active homes now have real schema-normalisation passes
2. keep `no_wli` untouched as upstream reference
3. decide whether completed/archive homes need a lighter simplification pass
4. avoid reopening broad rescue work unless something clearly important appears

## Update rule

Do not try to rewrite all files.
Instead:
- define the front-door shape
- push secondary material behind that shape
- keep the number of front-door files small
- preserve history without letting it compete with live truth
