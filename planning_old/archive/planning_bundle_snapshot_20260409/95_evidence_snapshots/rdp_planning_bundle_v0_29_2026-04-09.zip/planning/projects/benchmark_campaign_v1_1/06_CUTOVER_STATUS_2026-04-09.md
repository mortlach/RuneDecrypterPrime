# Benchmark campaign cut-over status — 2026-04-09

Status: active
Work status: in_progress
Project: benchmark_campaign_v1_1

## Current judgement

`benchmark_campaign_v1_1` is **close but not fully settled** as the default live
project home.

## What already passes

- live current-state/workstream/document-map/runbook pack exists
- code-crosscheck notes exist
- scoring/Torch support layer now has a clear freshness judgement
- older reference bundles are clearly secondary, not pretending to be the live home

## What still blocks full confidence

### 1. Older benchmark reference bundle still needs one more pass
This is the clearest remaining uncertainty inside the benchmark home.

### 2. Some support notes are still only triaged, not finally settled
This is no longer a big structural problem, but it is still enough to stop a
fully clean cut-over claim.

## Practical judgement

Safe to use as the default working benchmark/campaign home in most chats.

Still worth one more narrow pass before calling it fully canonical.
