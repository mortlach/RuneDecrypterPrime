# Document map

Status: active
Work status: done
Project: benchmark_campaign_v1_1

## Front-door live pack

Read first:
- `00_CURRENT_STATE.md`
- `01_WORKSTREAM_INDEX.md`
- `02_OPEN_QUESTIONS.md`
- `03_DOCUMENT_MAP.md`
- `04_ACTIVE_RUNBOOK.md`
- `05_REMAINING_WORK.md`

## Main active/spec layers

### Contracts
- `10_contracts/`
  - campaign spec

### Active plans
- `20_active_plans/`
  - unified benchmark plan
  - active todo
  - scoring-path compliance plan

### Validation and setup
- `30_validation_and_setup/`
  - setup/preflight spec
  - current code-crosscheck note
  - round-2 crosscheck note

## Secondary layer

### Supporting reference
- `40_supporting_reference/`
  - scoring and Torch support
  - reference packs
  - future method and future architecture
  - legacy seed and solve reference

### Archive links
- `90_archive_links/`
  - short pointers to larger archive homes

## Evidence layer
- `95_evidence_snapshots/`

## Reading rule

Do not start with the supporting-reference layer unless the front-door and
contract/plan/validation layers already point you there.
