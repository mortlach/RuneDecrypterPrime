# Open questions

## B1. Which docs in `planning/drafts/` are genuinely canonical for this project?
At minimum:
- execution plan
- campaign spec
- setup/preflight spec
- scoring-path plan

## B2. Which support docs should stay inside this project home?
Likely yes:
- cleanup plan
- refactor plan
- scoring/Torch gates
- setup/preflight

## B3. Should this home own a short result-read layer?
Probably yes, once the migration begins properly.

## B4. What should be the boundary with `rdp_v1`?
Keep release-level architecture and repo-level truth under `rdp_v1`.
Keep benchmark execution, campaign rules, and operational benchmark flow here.
