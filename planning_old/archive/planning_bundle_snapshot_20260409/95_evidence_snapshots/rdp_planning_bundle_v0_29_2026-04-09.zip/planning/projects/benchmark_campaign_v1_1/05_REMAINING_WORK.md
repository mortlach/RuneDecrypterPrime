# Remaining work

Status: active
Work status: in_progress
Project: benchmark_campaign_v1_1

## Main remaining work

### 1. Tighten the front-door wording slightly more
Need:
- a slightly cleaner current-state summary
- keep the reading order explicit

### 2. Re-check the grouped supporting-reference layer
Need:
- review `40_supporting_reference/`
- decide whether any files should later move further back into archive
- keep only genuinely useful material close to the project home

### 3. Keep benchmark truth separate from reference ideas
Need:
- future-method and legacy-method notes must stay secondary
- reference packs must not compete with the live contract/plan layer

### 4. Hold the line on structure
Need:
- use this home as the second model for active-home normalisation
- do not reintroduce many equally prominent side folders
