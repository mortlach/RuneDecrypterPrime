# Remaining work

Status: active
Work status: in_progress
Project: p13_real_ciphertext_campaign

## Main remaining work

### 1. Tighten the front-door wording slightly more
Need:
- keep the downstream-thread role explicit
- keep the reading order explicit

### 2. Re-check the grouped supporting-reference layer
Need:
- review `40_supporting_reference/`
- keep broader context small and clearly secondary

### 3. Keep thread history honest
Need:
- only add result notes for real thread movement
- keep payload/control/contract notes distinct from actual method/run results

### 4. Hold the line on structure
Need:
- use this home as the thin downstream model
- do not reintroduce many side folders or broad p13 sprawl
