# P13 real-ciphertext campaign cut-over status — 2026-04-09

Status: active
Work status: in_progress
Project: p13_real_ciphertext_campaign

## Current judgement

`p13_real_ciphertext_campaign` is now a real and coherent active home, but it is
**not yet fully mature enough** to claim a fully settled cut-over.

## What already passes

- current state/workstream/document-map/runbook pack exists
- problem brief exists
- verified code-anchor notes exist
- readiness-context pack exists
- first exact control question exists
- first control-package result note exists
- first actual comparison/control attempt definition exists
- first frozen-contract result note exists

## What still blocks full confidence

### 1. No empirical comparison/control result yet
This is the clearest remaining gap.

### 2. Thread history is still intentionally thin
That is honest and acceptable, but it means the home is still earlier-stage than
`rdp_v1` and `benchmark_campaign_v1_1`.

## Practical judgement

Safe to use as the default working home for this thread now.

But it is not yet strong enough to say the project is fully mature, because the
first empirical attempt/result note is still missing.
