# Active runbook

Status: active
Work status: in_progress
Project: p13_real_ciphertext_campaign

## Immediate goal

Use the new normalised `p13_real_ciphertext_campaign` shape as the thin,
downstream thread model.

## Reading order

1. front-door files
2. `10_active_plans/`
3. `20_specs_and_analysis/`
4. `30_status_and_results/`
5. `40_supporting_reference/` only as needed
6. `90_archive_links/` only if upstream context is needed

## Safe next steps

1. keep the thread-specific files dominant
2. keep broader p13/no-WLI context secondary
3. keep `no_wli` as upstream reference, not re-homed truth
4. only add new result notes when the thread actually advances

## What not to do yet

- do not overbuild this home
- do not let context packs become fake thread history
- do not treat this as the main p13 method-development home
