# no_wli upstream link

Status: active
Work status: done
Project: p13_real_ciphertext_campaign

Relevant upstream home:
- `planning/no_wli/`

Use this when:
- you need the live upstream method-development truth
- you need current no-WLI experiment/runbook context

Do not try to replace that home from inside this project.
Start from the live thread files here first, then go upstream only when needed.
