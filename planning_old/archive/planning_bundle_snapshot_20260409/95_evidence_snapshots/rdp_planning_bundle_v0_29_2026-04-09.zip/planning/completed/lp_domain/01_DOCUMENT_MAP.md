# Document map

## Promoted completed source docs

### Main LP-domain planning docs
- `planning/old/lp_domain_spec_v1.txt`
- `planning/old/lp_domain_implementation_plan_v1.txt`
- `planning/old/lp_registry_integration_review_20260307.txt`

### Registry review bundle
- `planning/drafts/lp_registry_review_bundle/README.md`
- `planning/drafts/lp_registry_review_bundle/docs/lp_interface_design_v1.md`
- `planning/drafts/lp_registry_review_bundle/docs/lp_registry_spec_v1.md`
- `planning/drafts/lp_registry_review_bundle/src/rune_decrypter_prime/data/liber_primus/lp_registry_v1.py`
- `planning/drafts/lp_registry_review_bundle/src/rune_decrypter_prime/data/liber_primus/lp_route_v1.py`
- `planning/drafts/lp_registry_review_bundle/src/rune_decrypter_prime/data/liber_primus/lp_ui_parse_v1.py`
- `planning/drafts/lp_registry_review_bundle/tests/data/liber_primus/test_lp_registry_v1.py`
- `planning/drafts/lp_registry_review_bundle/tests/data/liber_primus/test_lp_route_v1.py`
- `planning/drafts/lp_registry_review_bundle/tests/data/liber_primus/test_lp_ui_parse_v1.py`

## Code/test anchors already cross-checked

- `src/rune_decrypter_prime/data/liber_primus/`
- `src/rune_decrypter_prime/api/data_helpers.py`
- `tests/data/test_lp_master_transcript.py`

## Working rule

This home is for completed capability reference.
Do not treat it as an active frontier home unless a live project explicitly says
it is reopened.
