# Migration ledger

This file records what has already been moved into the new planning layout.

## Slice 1 — framework starter
Added:
- `planning/00_PORTAL.md`
- `planning/01_PROJECT_INDEX.md`
- `planning/02_GLOBAL_OPEN_QUESTIONS.md`
- `planning/03_AGENT_WORKFLOW.md`
- `planning/04_TAGS_AND_STATUSES.md`
- `planning/project_timeline/00_MASTER_TIMELINE.md`
- `planning/project_timeline/01_ACTIVE_COORDINATION_BOARD.md`
- starter homes for:
  - `rdp_v1`
  - `benchmark_campaign_v1_1`
  - `p13_real_ciphertext_campaign`

## Slice 2 — promoted source docs
### Promoted into `projects/rdp_v1/`
- governance charter
- campaign spec
- refactor plan
- current phase
- current risks
- task register
- ADR starter pack
- implementation plan

### Promoted into `projects/benchmark_campaign_v1_1/`
- unified execution plan
- campaign spec
- setup/preflight spec
- scoring-path/Torch compliance plan

## Slice 3 — first problem/status and completed/legacy homes
Added:
- first `5455` problem/status files
- `completed/lp_domain/`
- `legacy/v1_old_active_index/`

Promoted:
- LP domain completed docs
- old active-index residue

## Slice 4 — tighter benchmark pack and first archive home
Added:
- tighter benchmark current-state / todo / code-crosscheck files
- `archive/phased_refactor_and_review/`

Promoted:
- older phased/review pack files into archive home

## Slice 5 — control-layer tightening and templates
Added:
- `planning/05_CANONICAL_UPDATE_FORMAT.md`
- `planning/project_timeline/02_DEPENDENCY_MAP.md`
- `planning/project_timeline/20_PROBLEM_THREADS_INDEX.md`
- `planning/templates/`

## Slice 6 — LP registry review bundle and v1 support notes
Added:
- missing `no_wli` timeline snapshot
- `completed/lp_domain/02_REGISTRY_REVIEW_BUNDLE_MAP.md`
- `projects/rdp_v1/31_support_matrices/`

Promoted into `completed/lp_domain/`
- LP registry review bundle docs
- LP registry/router/parser source files
- matching tests

Promoted into `projects/rdp_v1/31_support_matrices/`
- feature support matrix draft
- current-code mapping template
- old current-code mapping note

## Slice 7 — benchmark reference bundle and honest p13 note search
Added:
- `projects/benchmark_campaign_v1_1/32_REFERENCE_BUNDLE_MAP.md`
- `projects/p13_real_ciphertext_campaign/30_analysis_specs/5455_old_note_search_note.md`

Promoted into `projects/benchmark_campaign_v1_1/35_reference_packs/community_benchmark_v1_1_spec_bundle/`
- old benchmark spec bundle docs
- setup/preflight docs
- phase progress notes
- phase-local tools and tests
- campaign README/config/schema/fixture files

## Slice 8 — no-WLI archive pack and p13 readiness context
Added:
- `archive/no_wli_planning_refactor_20260404/`
- `projects/p13_real_ciphertext_campaign/35_reference_context/p13_readiness_context/`
- `projects/p13_real_ciphertext_campaign/35_reference_context/P13_READINESS_CONTEXT_MAP.md`

Promoted into `archive/no_wli_planning_refactor_20260404/`
- older no-WLI planning-refactor pack top files
- selected logs / plans / specs / review notes / legacy index files

Promoted into `projects/p13_real_ciphertext_campaign/35_reference_context/p13_readiness_context/`
- no-WLI solve-integrity plan
- deep research capability ladder note
- deep research evidence-gaps note
- deep research method-families note

## Slice 9 — no-WLI stage35 transition pack and benchmark readiness review
Added:
- `archive/no_wli_stage35_transition_20260402/`
- benchmark readiness review folder under:
  `projects/benchmark_campaign_v1_1/35_reference_packs/community_readiness_reviews/`

Promoted into `archive/no_wli_stage35_transition_20260402/`
- transition notes and deep-research reports
- locked experiment specs and pipeline hardening notes
- study checklists
- logs and launch script
- external review pack zip files

Promoted into `projects/benchmark_campaign_v1_1/35_reference_packs/community_readiness_reviews/`
- `COMMUNITY_CAMPAIGN_READINESS_REVIEW_2026-02-22.md`

## Slice 10 — forensic audit archive and rdp_v1 reference note
Added:
- `archive/forensic_audit_2026/`
- `projects/rdp_v1/36_forensic_reference/`

Promoted into `archive/forensic_audit_2026/`
- audit control/docs
- source/reference maps
- bug-hunt and proposed-test files
- forensic PDF and PDF line-number note

## Slice 11 — active-home support-note tightening
Added:
- `projects/rdp_v1/37_maintainer_reference/`
- expanded `projects/rdp_v1/31_support_matrices/`
- `projects/benchmark_campaign_v1_1/33_scoring_and_torch_support/`

Promoted into `projects/rdp_v1/31_support_matrices/`
- support-to-test map
- support-matrix cell meanings
- findings register
- change workflow note
- effort-bands note
- older implementation-plan text notes

Promoted into `projects/rdp_v1/37_maintainer_reference/`
- maintainer handbook
- private maintainer handbook skeleton

Promoted into `projects/benchmark_campaign_v1_1/33_scoring_and_torch_support/`
- score hardening notes
- scoring speed investigation
- Torch scoring pipeline upgrade plan
- fully-Torch-compliant notes

## Slice 12 — remaining-work map and small support promotions
Added:
- `planning/06_REMAINING_WORK_AND_CROSSCHECK.md`
- `planning/project_timeline/03_CROSSCHECK_STATUS.md`
- `projects/rdp_v1/05_REMAINING_WORK.md`
- `projects/benchmark_campaign_v1_1/05_REMAINING_WORK.md`
- `projects/p13_real_ciphertext_campaign/05_REMAINING_WORK.md`

Promoted into `projects/benchmark_campaign_v1_1/33_scoring_and_torch_support/`
- `scoring_contract_ecdf_abi.md`
- `README_TESTS_SCORING_2.md`

Promoted into `archive/forensic_audit_2026/`
- `audit_solver_blockers_2026-01-27.md`

## Slice 13 — round-2 active-home code crosscheck
Added:
- `projects/rdp_v1/30_architecture_specs/rdp_v1_crosscheck_round2_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/30_validation_and_setup/benchmark_campaign_crosscheck_round2_2026-04-09.md`
- `projects/p13_real_ciphertext_campaign/30_analysis_specs/p13_real_ciphertext_crosscheck_round2_2026-04-09.md`
- `planning/project_timeline/04_ACTIVE_HOME_CROSSCHECK_ACTIONS.md`

Promoted repo evidence snapshots:
- api `__init__`
- scorer report builder
- backend/parity scoring test
- solve-proof pipeline README
- solve-proof status json

## Slice 14 — support freshness triage and old bughunt archive
Added:
- `projects/rdp_v1/31_support_matrices/SUPPORT_FRESHNESS_TRIAGE_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/33_scoring_and_torch_support/SUPPORT_FRESHNESS_TRIAGE_2026-04-09.md`
- `archive/forensic_audit_2026/02_BUGHUNT_V1OLD_MAP.md`

Promoted into `archive/forensic_audit_2026/source_pack/v1OLD_bughunt/`
- old `v1OLD/bughunt/` cluster files

## Slice 15 — benchmark scoring/Torch freshness detail
Added:
- `projects/benchmark_campaign_v1_1/33_scoring_and_torch_support/SCORING_TORCH_FRESHNESS_CROSSCHECK_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/33_scoring_and_torch_support/RECOMMENDED_KEEP_SET_2026-04-09.md`

Promoted repo evidence snapshots:
- `test_score_parity_numpy.py`
- `test_score_parity_torch.py`
- `test_unified_scorer_contract_torch.py`
- `test_torch_objective_contracts.py`
- `test_scoring_integrity.py`

## Slice 16 — rdp_v1 freshness detail and cut-over criteria
Added:
- `projects/rdp_v1/31_support_matrices/RDP_V1_SUPPORT_FRESHNESS_CROSSCHECK_2026-04-09.md`
- `projects/rdp_v1/31_support_matrices/RDP_V1_RECOMMENDED_KEEP_SET_2026-04-09.md`
- `projects/rdp_v1/06_CUTOVER_CHECKLIST.md`
- `planning/07_CANONICAL_CUTOVER_CRITERIA.md`

## Slice 17 — p13 first control question and control-package result note
Added:
- `projects/p13_real_ciphertext_campaign/20_active_plans/5455_first_control_question.md`
- `projects/p13_real_ciphertext_campaign/30_analysis_specs/5455_pinned_upstream_anchors_v1.md`
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_result_note_001_control_package.md`

Updated:
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_status_ledger.md`
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_status_ledger.csv`
- `projects/p13_real_ciphertext_campaign/05_REMAINING_WORK.md`

## Slice 18 — p13 first actual comparison/control attempt definition
Added:
- `projects/p13_real_ciphertext_campaign/20_active_plans/5455_comparison_attempt_001.md`
- `projects/p13_real_ciphertext_campaign/30_analysis_specs/5455_attempt_001_input_contract_v1.md`
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_result_note_002_attempt_001_contract_freeze.md`

Updated:
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_status_ledger.md`
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_status_ledger.csv`
- `projects/p13_real_ciphertext_campaign/05_REMAINING_WORK.md`

## Slice 19 — bundle-wide cutover status assessment
Added:
- `planning/08_CANONICAL_CUTOVER_STATUS_2026-04-09.md`
- `planning/project_timeline/05_CUTOVER_STATUS_BOARD.md`
- `projects/rdp_v1/07_CUTOVER_STATUS_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/06_CUTOVER_STATUS_2026-04-09.md`
- `projects/p13_real_ciphertext_campaign/06_CUTOVER_STATUS_2026-04-09.md`

## Slice 20 — draft cutover decision and benchmark reference-bundle pass
Added:
- `planning/09_DRAFT_CUTOVER_DECISION_NOTE.md`
- `projects/benchmark_campaign_v1_1/35_reference_packs/COMMUNITY_BENCHMARK_REFERENCE_BUNDLE_PASS_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/35_reference_packs/COMMUNITY_BENCHMARK_REFERENCE_BUNDLE_KEEP_SET_2026-04-09.md`

## Slice 21 — first empirical 5455 control result and upstream-reference rule
Added:
- `projects/p13_real_ciphertext_campaign/30_analysis_specs/no_wli_upstream_reference_policy.md`
- `projects/p13_real_ciphertext_campaign/20_active_plans/5455_empirical_attempt_001_payload_parity.md`
- `projects/p13_real_ciphertext_campaign/30_analysis_specs/5455_empirical_attempt_001_measurement_contract.md`
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_result_note_003_payload_parity_control.md`

Updated:
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_status_ledger.md`
- `projects/p13_real_ciphertext_campaign/50_run_logs/5455_status_ledger.csv`
- `projects/p13_real_ciphertext_campaign/05_REMAINING_WORK.md`

## Slice 22 — legacy integration lessons and future-method reference
Added:
- `projects/rdp_v1/38_integration_history/`
- `projects/benchmark_campaign_v1_1/36_future_method_ideas/`

Promoted:
- old `workgin/` merge plan and merge issue log into `rdp_v1` integration history
- old hard-crib integration note into benchmark future-method reference

## Slice 23 — additional legacy review lessons
Added:
- `archive/phased_refactor_and_review/02_EXTERNAL_HANDOFF_MAP_2026-04-09.md`
- `archive/phased_refactor_and_review/external_reviewer_handoff_20260307.txt`
- `projects/benchmark_campaign_v1_1/36_future_method_ideas/UNIFORM_RUNNER_STAGE_ENGINE_REFERENCE_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/36_future_method_ideas/nowli_improvements_refactor_for_benchcamp_legacy_reference.txt`
- `projects/benchmark_campaign_v1_1/36_future_method_ideas/nowli_improvements_refactor_for_benchcamp_review_legacy_reference.txt`

## Slice 24 — repo-level scoring/assets history and phased roadmap reference
Added:
- `projects/rdp_v1/39_scoring_and_assets_history/`
- `projects/benchmark_campaign_v1_1/36_future_method_ideas/PHASED_RUNNER_STAGE_ENGINE_ROADMAP_REFERENCE_2026-04-09.md`
- `projects/benchmark_campaign_v1_1/36_future_method_ideas/phased_runner_stage_engine_roadmap_legacy_reference.txt`

Promoted:
- `planning/old/scorign_refactor_plan.txt`
- `planning/old/data_refactor_plan_assets_migration_draft.txt`

## Slice 25 — legacy col-then-sub seed/solve reference
Added:
- `projects/benchmark_campaign_v1_1/37_legacy_seed_and_solve_reference/`

Promoted:
- old benchmark-only col-then-sub seed utility
- old col-then-sub solve script
- matching focused benchmark test snapshot
