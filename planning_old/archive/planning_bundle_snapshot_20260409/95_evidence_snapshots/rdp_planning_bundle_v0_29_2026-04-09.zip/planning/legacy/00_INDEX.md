# Legacy index

This area is for older planning material that still has value, but should no
longer behave like the live entry point.

## Current legacy homes

- `v1_old_active_index/`

## Rule

Legacy material can still be useful context.
But if a new live project home exists, the legacy version should be treated as
reference only.
