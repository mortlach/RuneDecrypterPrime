# Document map

## Promoted legacy source docs

- `planning/old/ACTIVE_INDEX.txt`
- `planning/old/REMAINING_ITEMS_STATUS.txt`

## Why preserved

These files capture:
- earlier working structure
- what used to be treated as the active execution view
- the fact that the old remaining-items summary says total remaining is zero

That makes them useful for migration and historical interpretation, but not as a
live top entry point.
