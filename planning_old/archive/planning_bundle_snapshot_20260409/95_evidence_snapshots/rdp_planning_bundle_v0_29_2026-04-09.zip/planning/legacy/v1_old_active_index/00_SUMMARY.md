# Old active-index summary

Status: legacy
Work status: done
Project: legacy/v1_old_active_index

## What this is

This home preserves the old active-index residue:
- `planning/old/ACTIVE_INDEX.txt`
- `planning/old/REMAINING_ITEMS_STATUS.txt`

## Why it moved here

These files are still useful historical context, but they are no longer a safe
main entry point because:
- newer planning homes now exist
- `REMAINING_ITEMS_STATUS.txt` reports zero remaining
- the old index mixes context from phases that have already moved on

## Working rule

Use this home to understand earlier execution context.
Do not treat it as current truth once the new project homes are stable.
