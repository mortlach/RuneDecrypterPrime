# Summary For Reviewers

## What we did

Since the previous review pack, the work split into two linked tracks:

1. targeted live studies on the locked weak-seed hypotheses
2. pipeline hardening aimed at making long-run results scientifically
   trustworthy

The live work focused on a small number of isolated studies rather than broad
retuning:

- a `seed211` Study 1 run for constant local-depth Stage-3 entry
- a `seed411` Study 3 run for Phase-C start balancing
- a `seed411` Study 2 run for Phase-B family preservation
- a `seed411` width probe that widened the late Phase-B carry-forward band

The hardening work focused on the experiment loop rather than the entire repo:

- runtime preflight before long fixture-matrix runs
- matrix-entry config spine hardening
- single-id control-file derivation
- typed Stage-3 tuning presets
- stale rerun rejection
- finalize-path persistence unification for reviewer-facing artifacts

## Why we did it

The review lock pointed to a Stage-3 family-handling problem rather than a
general software-quality collapse. The most important remaining uncertainty was
where the active bottleneck sits:

- upstream reach into the right family
- downstream preservation of distinct families
- or downstream exploitation of already-carried variety

At the same time, recent work had exposed enough config, rerun, and persistence
bugs that valid negatives needed stronger proof than before.

So the work was:

- narrow on science
- narrow on hardening
- evidence-first rather than intuition-first

## What we observed

There are now five important live evidence points in this pack.

### 1. `seed411` precursor compare

The earlier broader late-family-width candidate was a small real improvement:

- `best_match_ratio: 0.041 -> 0.046`
- `phaseB_selected_unique_end_hash: 8 -> 32`
- `phaseC_candidate_pool_unique_end_hash: 8 -> 32`
- `phaseC_start_keys_used: 6 -> 8`

Evidence:
- `evidence/matrix_controls/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
- `evidence/run_dirs/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159`
- `evidence/run_dirs/20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159`

This is still one of the strongest signals in the whole pack because it showed
that the pipeline can respond when a real lever is touched, even if the gain is
small.

### 2. Study 1 on `seed211`: valid negative

Stage-3 entry really widened:

- control:
  - `stage3_entry_allocation_policy = "legacy_fixed_budget"`
  - `stage3_entry_target_before_cap = 64`
  - `stage3_init3_count = 64`
- candidate:
  - `stage3_entry_allocation_policy = "constant_local_depth"`
  - `stage3_entry_target_before_cap = 288`
  - `stage3_init3_count = 144`

But the solve result did not move:

- `best_match_ratio: 0.574 -> 0.574`
- `stage3_match_ratio: 0.574 -> 0.574`
- downstream late-stage counters were unchanged

Evidence:
- `evidence/matrix_controls/fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`
- `evidence/run_dirs/20260328T013131043374Z__bench_solve_pipeline_no_wli__55b7159`
- `evidence/run_dirs/20260328T050751414997Z__bench_solve_pipeline_no_wli__55b7159`

### 3. Study 3 on `seed411`: valid negative

Only Phase-C start policy changed:

- control:
  - `stage3.two_phase.phase_c.start_policy = "source_order"`
- candidate:
  - `stage3.two_phase.phase_c.start_policy = "balanced_sources_v1"`

But the actual starts did not change:

- same six `candidate_hash` values
- same order in `phasec_start_checkpoints.jsonl`
- `phaseC_start_keys_used = 6`
- `phaseC_start_unique_end_hash = 6`
- `best_match_ratio: 0.041 -> 0.041`

Evidence:
- `evidence/matrix_controls/fixture_matrix_run_state_tune_v38_p9c3_seed411_phasec_start_compare_2job.json`
- `evidence/run_dirs/20260328T174120032623Z__bench_solve_pipeline_no_wli__55b7159`
- `evidence/run_dirs/20260328T211041031812Z__bench_solve_pipeline_no_wli__55b7159`

### 4. Study 2 on `seed411`: valid negative after telemetry fix and rerun

The family-preservation policy really executed:

- control:
  - `phaseB_family_preservation_policy = "off"`
- candidate:
  - `phaseB_family_preservation_policy = "reserve_by_family_v1"`
  - `phaseB_family_reserved_slots = 2`
  - `phaseB_family_reservation_applied = 1`

But the carried and exploited set did not move:

- `phaseB_selected_unique_end_hash = 8`
- `phaseC_candidate_pool_unique_end_hash = 8`
- `phaseC_start_keys_used = 6`
- `best_match_ratio: 0.041 -> 0.041`

Evidence:
- `evidence/matrix_controls/fixture_matrix_run_state_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.json`
- `evidence/run_dirs/20260329T155853670179Z__bench_solve_pipeline_no_wli__55b7159`
- `evidence/run_dirs/20260329T204310438057Z__bench_solve_pipeline_no_wli__55b7159`

### 5. Phase-B width probe on `seed411`: valid negative with a strong signal

This run widened the late Phase-B carry-forward band:

- control:
  - `phase_b_top_n = 8`
- candidate:
  - `phase_b_top_n = 32`

Top-level solve still did not move:

- `best_match_ratio: 0.041 -> 0.041`
- `stage3_match_ratio: 0.039 -> 0.039`

But carried variety moved a lot:

- `phaseB_selected_unique_end_hash: 8 -> 32`
- `phaseB_downstream_selected_unique_end_hash: 8 -> 32`
- `phaseC_candidate_pool_count: 10 -> 34`
- `phaseC_candidate_pool_unique_end_hash: 8 -> 32`

And exploited variety still did not move:

- `phaseC_start_keys_used = 6`
- `phaseC_start_unique_end_hash = 6`
- same `phasec_start_checkpoints.jsonl` hashes in the same order

Evidence:
- `evidence/matrix_controls/fixture_matrix_run_state_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.json`
- `evidence/run_dirs/20260330T150529396668Z__bench_solve_pipeline_no_wli__55b7159`
- `evidence/run_dirs/20260330T175546232525Z__bench_solve_pipeline_no_wli__55b7159`

## Interpretation

The locked working version still stands:

- the main problem is Stage-3 family handling
- `211`-like failures look mainly upstream
- `411`-like failures look mainly downstream

The current live evidence now sharpens that split:

- `211`:
  - widening Stage-3 entry was real but did not help
  - this weakens simple entry-budget-starvation as the main explanation
  - it strengthens the `good_family_absent` reading
- `411`:
  - wider late carry-forward is real
  - family reservation inside the current narrow band did not matter
  - Phase-C start balancing alone did not matter
  - widening the carried set from `8` to `32` still did not change exploited
    starts

The most useful current phrase is:

- nominal variety is not becoming exploited variety

That is the strongest bridge between the code review and the live evidence.

One sharper `411` conclusion is now worth stating explicitly:

- the bottleneck no longer looks like generic Phase-C ordering by itself
- and it no longer looks like generic late width by itself
- it looks more like failure to convert a widened late pool into at least one
  genuinely novel, startable challenger that is actually explored

## What we think is missing

There is still a key missing insight, and it is probably not a tiny late-stage
knob.

The current evidence suggests:

- for `211`, the missing issue is more likely upstream basin reach
- for `411`, the missing issue is more likely how the widened late pool is
  valued, pruned, or converted into an actual novel start

So the science side is increasingly a search-strategy puzzle rather than a
simple missing-feature puzzle.

## Why the hardening still matters

Even with the science now sharper, meaningful progress still depends on the
pipeline being trustworthy enough that a long run can be classified as one of:

- a valid negative
- a valid positive
- or an explicitly invalid infrastructure failure

The hardening work in this pack is therefore not background cleanup. It is part
of making future science interpretable.
