# no_wli Solve Status Report

Date: 2026-03-21

This note is for sharing the current state of the no-WLI `p9/c3/l1000` solve effort, based on the canonical local output tree and the new catalog.

## Canonical references

Catalog / index files:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/best_p9_c3_runs.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/notable_artifacts.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/run_manifest.csv`

Main artifacts discussed below:

- old best `p9/c3` run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- newer strong March 15 runs:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260315T001203236783Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- latest bounded Stage-3.5 proof attempt:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/run_config.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/phasec_start_checkpoints.jsonl`

## What the branch is doing now

The current branch is no longer just "tuning Phase-C".

It is trying to do three things:

1. Keep a healthier late-stage challenger pool.
2. Use a stronger rescue/polish path on late substitution candidates.
3. Add a new Stage-3.5 frozen-columns substitution-only solver after the stable Phase-C baseline.

The branch now also has better experimental infrastructure:

- replay and live share more rescue logic
- Phase-C per-start checkpoints exist
- a catalog/index exists for the canonical output tree
- old incomplete no-final run dirs have been pruned

Current catalog summary:

- canonical completed run dirs: `173`
- final-instance files: `324`
- runs with Phase-C checkpoints: `2`
- runs where Stage-3.5 was selected: `0`

Those counts come from:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`

## Best `p9/c3` results so far

From `best_p9_c3_runs.csv`, the strongest `p9/c3/l1000` runs are still older runs:

1. `0.773`
   - `20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e`
2. `0.765`
   - `20260315T001203236783Z__bench_solve_pipeline_no_wli__5961d3e`
3. `0.761`
   - `20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e`

The latest bounded proof attempt finished at:

- `0.668`
  - `20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159`

So the branch is still well below its own earlier best basin.

## What is going wrong

### 1. The current branch is not reaching the old good basin

This is the biggest problem.

Old best run `stage3_topk` cluster:

- `0.773, 0.770, 0.769, 0.767, 0.760`

Latest bounded proof run `stage3_topk` cluster:

- `0.638, 0.638, 0.640, 0.640, 0.633`

That means the newer branch is doing much more late work on a much weaker late-stage family.

This is not just "late polish is too weak".
It means the pipeline is already in a worse substitution basin before the latest rescue / Stage-3.5 logic gets a chance to help.

### 2. The latest "Stage-3.5 proof" was not actually a valid Stage-3.5 run

In the finished proof artifact:

- `stage35_ran = 0`
- `stage35_enabled_cfg = 0`
- `stage35_archive_count = 0`
- `stage35_archive = []`
- `stage35_seed_rows = []`

That is visible in:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`

So although the run was intended to prove Stage-3.5 live, the finished artifact shows that Stage-3.5 did not actually run in that proof result.

That means the `0.668` result is really a Phase-C result, not a real live Stage-3.5 proof result.

### 3. Columns are already right; substitution is still the failure

Using the current artifact's `target_key_idx` as the shared target for comparison:

Old best `0.773` key:

- column hamming: `0`
- substitution hamming: `115`

Current `0.668` key:

- column hamming: `0`
- substitution hamming: `136`

So both old and current runs already have the columns right.
The difference is entirely on the substitution side.

### 4. The current branch can improve challengers, but not enough

From the latest proof's Phase-C checkpoint file:

- Phase-C used `5` starts
- all `4` challenger rescues ran
- `phaseC_challenger_overtook_anchor_count = 3`
- final Phase-C winner lane was `challenger`

So the newer late-stage machinery is not useless.
It is doing something real.
But even after that, the final result is still only `0.668`.

That tells us:

- challenger preservation improved
- late rescue improved local outcomes
- but the branch is still climbing inside a worse overall substitution basin

## What I think is wrong

My current view is:

### Problem A: regression before the final late solver

The older `0.773` run used the older single Stage-3 late path.
The newer proof path uses the newer forced two-phase + rescue baseline, and then attempts Stage-3.5.

The evidence suggests the newer path is not reproducing the old strong late family anymore.

That means we likely have a regression in:

- upstream seed quality
- Stage-3 basin generation
- or the effective handoff into late refinement

before Stage-3.5 even matters.

### Problem B: the branch still has not had a clean live Stage-3.5 proof

The offline Stage-3.5 replay remains promising.
But the finished bounded live proof artifact did not actually run Stage-3.5.

So we still do not have a clean answer to:

- whether live Stage-3.5 can beat the stable current Phase-C baseline on `p9`

### Problem C: even the older best basin was not close to solve quality

The old best `0.773` run is clearly better than the current branch, but it is still not near the `~0.9` range needed for convincing readability.

So there are really two separate tasks:

1. recover the old `0.77x` family reliably
2. then build a stronger substitution-only late solver on top of that

## Concrete evidence from key slices

Compared against the current target key:

Old best slice substitution mismatches by slice:

- slice 0: `9`
- slice 1: `6`
- slice 2: `12`
- slice 3: `25`
- slice 4: `26`
- slice 5: `15`
- slice 6: `9`
- slice 7: `7`
- slice 8: `6`

Current `0.668` slice substitution mismatches by slice:

- slice 0: `8`
- slice 1: `7`
- slice 2: `16`
- slice 3: `27`
- slice 4: `26`
- slice 5: `26`
- slice 6: `12`
- slice 7: `6`
- slice 8: `8`

The biggest gap is not spread evenly.
The current basin is much worse in a few substitution slices, especially:

- slice `5`
- slice `2`
- slice `6`
- slice `3`

That supports the idea that the branch is landing in the wrong substitution family, not merely polishing weakly across the whole key.

## What I think should happen next

### 1. Do not treat the latest `0.668` proof as a Stage-3.5 verdict

It is not.
The artifact shows Stage-3.5 did not actually run.

### 2. First recover the old `0.77x` basin family

Before spending more time on Stage-3.5 proofing, compare:

- old March 12 `0.773` run config and late path
- current forced two-phase path

The key question is:

- what changed that caused the late candidate family to fall from `0.77x` to `0.63x/0.64x` before late rescue finishes?

### 3. Only then do one clean bounded live Stage-3.5 proof

Once the branch can at least reproduce a stronger late basin again, rerun one bounded `p9` proof where Stage-3.5 really executes and archives results.

### 4. Keep the current replay/checkpoint/catalog infrastructure

That work was worth doing.
The problem now is not the catalog or checkpointing.
The problem is basin quality and the lack of a real live Stage-3.5 proof artifact.

## Bottom line

The current branch is healthier and better instrumented than it was a month ago, but it is still not solving.

The main failure is not "columns are wrong".
The main failure is:

- the newer pipeline is not reaching the older strong substitution basin
- and the latest long proof did not actually run Stage-3.5 live

So the next discussion should focus on:

- recovering the old `0.77x` basin family first
- then proving real live Stage-3.5 on top of that

not on more generic late-stage tuning in the dark.
