# No-WLI Next-Phase Implementation Plan

Date: 2026-03-27

Purpose:
- convert the locked review position into a concrete next-stage implementation plan
- keep the next work solve-first and evidence-driven
- define the smallest code surfaces, canaries, short-run readouts, and stop/go gates

Scope:
- no runtime code changes in this document
- this is a plan for the next stage after the current Study 1 boundary fix and canary

Sources used for this plan:
- `planning/working/March27_2026_review v2.txt`
- `planning/working/no_wli_science_run_log_2026-03-26.md`
- `planning/working/no_wli_solve_integrity_plan_2026-03-21.md`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_seeding.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_topk.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/audit_basin_family_diversity_alignment.py`

## 1. Locked Working Position

The current working version stays:

1. Study 1: constant local-depth Stage-3 entry
2. Study 3: Phase-C start balancing
3. Study 2: family-aware Phase-B preservation

Why this order remains correct:
- Study 1 has the strongest direct evidence for `211`-like upstream reach failure.
- Study 3 has the cleanest explicit downstream bias in current code and the best live support from `411`-like runs.
- Study 2 still matters, but it is more policy-heavy because it needs a family definition.

Important nuance:
- the live `seed411` compare supports a broader exploited-variety bottleneck
- it does not isolate Phase-C start ordering alone as the sole marginal cause
- the next phase should therefore isolate Phase-C start selection itself before widening further

## 2. Current Code-State Summary

### Study 1 status

Study 1 entry policy now exists as a clean explicit surface:
- runtime state:
  - `STAGE3_ENTRY_ALLOCATION_POLICY`
  - `STAGE3_ENTRY_MUTATIONS_PER_PROMOTED`
- config outputs:
  - `stage3.entry`
  - `stage3_search.entry`
- Stage-3 prep output:
  - `stage3_entry_allocation_policy`
  - `stage3_entry_target_before_cap`
  - `stage3_entry_mutation_calls_per_promoted`

This is now backed by the short canary:
- `tests/tools/test_no_wli_stage3_entry_canary.py`

Short proof status:
- focused slice:
  - `83 passed`
- evidence:
  - `planning/working/no_wli_science_run_log_2026-03-26.md`

Operational meaning:
- the next user-run long compare is scientifically worth reading again
- the failed v37 runs should remain classified as invalid boundary failures

### Phase-C start-selection status

The current Phase-C candidate pool and start selection are still source-ordered in:
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`

Current behavior, from code:
- candidate pool assembly order:
  - `stage3_best`
  - `phaseB_topk`
  - `phaseA_selected`
- actual starts are consumed in that same source order until `stage3_phasec_start_keys` fills

Relevant current telemetry already exists:
- `phaseC_candidate_pool_count`
- `phaseC_candidate_pool_unique_keys`
- `phaseC_candidate_pool_unique_end_hash`
- `phaseC_candidate_pool_source_counts`
- `phaseC_start_keys_used`
- `phaseC_start_source_counts`
- `phaseC_start_unique_end_hash`

This is the smallest practical rewrite surface for Study 3.

### Phase-B preservation status

Current Phase-B narrowing still happens mainly in:
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`

Current behavior, from code:
- rows ranked pct-first through `_phaseb_rank_key(...)`
- exact dedupe by `(start_hash, end_hash)`
- top-n / tie-band widening still around the same `end_score_pct` surface

This remains important, but it is a broader policy intervention than Study 3.

## 3. Next-Phase Goals

The next phase should produce three things:

1. a clean scientific readout of Study 1 on `211`
2. a narrowly isolated Study 3 implementation for `411`-like downstream exploitation failure
3. short-run evidence that distinguishes:
   - carried variety
   - explored variety
   - final solve improvement

Non-goals for the next phase:
- no Stage-3.5-led push
- no broad scorer unification
- no family-preservation rewrite yet
- no broad refactor of Stage-3 internals beyond the exact surfaces needed for Study 3

## 4. Implementation Sequence

### Phase A. Close Study 1 Readout

Objective:
- decide whether constant local-depth entry improved upstream reach on `211`

Required evidence:
- run config / lock payload show:
  - `entry_allocation_policy = constant_local_depth`
  - intended cap applied
- output artifacts show:
  - `stage3_entry_target_before_cap`
  - `init3_n`
  - `stage2_to_stage3.stage3_init3_count`
- final result comparison:
  - `stage3_match_ratio`
  - `best_match_ratio`
  - `best_stage`

Decision rule:
- if Study 1 does not widen actual Stage-3 entry, treat the run as execution failure
- if it widens entry but solve does not move, treat it as a valid negative result
- if it widens entry and improves `211`, keep it as a retained candidate branch for future higher-period work

Outputs to update:
- `planning/working/no_wli_science_run_log_2026-03-26.md`
- `planning/working/no_wli_solve_integrity_plan_2026-03-21.md`
- `planning/working/no_wli_study1_readout_checklist_2026-03-27.md`

### Phase B. Implement Study 3

Objective:
- isolate whether Phase-C start allocation is bottlenecking downstream exploitation on `411`

Implementation target:
- change only how `start_records` are chosen from an already-built candidate pool
- do not change:
  - Phase-A generation
  - Phase-B ranking
  - candidate-pool construction
  - rescue logic

Primary code surface:
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`

Supporting config surfaces:
- `tools/benchmarks/periodic_sub_trans/no_wli/runtime_defaults.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_defaults.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_lock_payload.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`

Recommended minimal policy shape:
- keep legacy default:
  - `source_order`
- add one explicit candidate policy:
  - `balanced_sources_v1`

Recommended `balanced_sources_v1` behavior:
1. reserve anchor best row first if present
2. build source buckets exactly as now
3. consume challenger starts by round-robin across:
   - `phaseB_topk`
   - `phaseA_selected`
4. preserve uniqueness by exact key as today
5. stop at the same `stage3_phasec_start_keys`

Reason for this choice:
- smallest isolating change
- directly tests exploited-variety squeeze
- avoids premature commitment to a family definition
- preserves current candidate pool and rescue surfaces for comparability

Explicitly avoid in Study 3 v1:
- family clustering
- additional score mixing
- source-specific quota tuning beyond anchor-first plus round-robin
- changing `phaseC_start_keys`
- changing rescue thresholds

### Phase C. Evaluate Study 3 with Short Live Compare

Target seed:
- `411`

Recommended two-job compare:
1. control:
   - current preserved control
2. candidate:
   - same preserved control plus `phasec_start_policy = balanced_sources_v1`

Interpretation rule:
- do not mix this with wider rescue or broader Phase-B carry-forward at first
- first Study 3 run must isolate start selection

Primary readouts:
- `phaseC_candidate_pool_source_counts`
- `phaseC_start_source_counts`
- `phaseC_start_keys_used`
- `phaseC_start_unique_end_hash`
- `best_match_ratio`
- `stage3_match_ratio`
- `phaseC_final_winner_source`

Success patterns:
- more balanced `phaseC_start_source_counts`
- equal or higher `phaseC_start_unique_end_hash`
- improved `best_match_ratio` or `stage3_match_ratio`

Valid negative pattern:
- starts rebalance as intended, but solve does not improve
- this still falsifies Phase-C start order as the main lever

### Phase D. Reassess Study 2

Only begin after:
- Study 1 readout is closed
- Study 3 isolated run is complete

Why delay:
- Study 2 needs a family definition
- current audit tooling offers options, but the implementation surface is larger
- Phase-C balancing is cheaper to isolate first

Likely design direction when reached:
- reserve some Phase-B / downstream slots by family view
- family definition should be chosen from already reviewed audit views, not invented ad hoc

Preferred starting family view candidates:
- `prefix_hamming_le_24`
- `near_tail_h1`

Reference file:
- `tools/benchmarks/periodic_sub_trans/no_wli/audit_basin_family_diversity_alignment.py`

## 5. Required Canaries and Test Discipline

The next phase must keep the current rule:
- no long handoff until a short proof exists for the changed boundary

### Study 3 canary requirements

Add one dedicated canary that proves:
- preset resolution carries the new Phase-C start policy cleanly
- run config writes the policy explicitly
- non-scoring lock writes the policy explicitly
- the Phase-C candidate pool stays unchanged under the new policy
- only `start_records` differ

Also add one deterministic unit test on synthetic candidate buckets:
- same pool
- same start budget
- legacy `source_order` produces current order
- `balanced_sources_v1` produces anchor-first then source-balanced order

Meaningful short slice before live test:
- config / preset / lock payload tests
- Phase-C deterministic start-selection tests
- one smoke test through the two-phase function if possible without expensive runtime

### Guardrails

Do not accept a Study 3 implementation if:
- it silently changes candidate-pool composition
- it silently changes rescue eligibility
- it silently changes score ranking or tie-band logic
- the new policy is not visible in config and lock outputs

## 6. Logging Requirements

Each implementation step should append evidence-backed notes to:
- `planning/working/no_wli_science_run_log_2026-03-26.md`
- `planning/working/no_wli_solve_integrity_plan_2026-03-21.md`

Minimum evidence per claim:
- code path
- test command
- test result
- artifact path for live evidence

Claims to avoid:
- “probably better”
- “seems wider”
- “looks fixed”

Claims to prefer:
- config surface changed at these files
- canary proves this exact boundary
- live output shows these counters changed
- solve improved or did not improve

## 7. Immediate Working Plan

Immediate next steps from this document:

1. wait for or read the corrected Study 1 long rerun
2. close the Study 1 checklist
3. if boundary is clean, implement Study 3 as `phasec_start_policy = balanced_sources_v1`
4. add Study 3 canary and deterministic tests
5. run only short confirmation tests locally
6. hand off the next isolated `411` long compare to the user

## 8. Bottom Line

The next phase should stay narrow.

Best next implementation order:
1. close Study 1 readout on `211`
2. implement isolated Phase-C start balancing on `411`
3. only then consider family-aware Phase-B preservation

That keeps the work aligned with the locked review, minimizes silent drift, and
ensures each long run answers a specific question rather than bundling multiple
late-stage changes together.

## 9. Status Update: Study 3 Implemented

Study 3 is now implemented.

What is complete:

- explicit Phase-C start policy surface:
  - `source_order`
  - `balanced_sources_v1`
- isolated runtime change in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
- config / lock / resume / runtime-call plumbing
- dedicated Study 3 canary
- deterministic Phase-C ordering test
- prepared `seed411` 2-job live compare

What remains:

- user long-run readout only

Active live compare prepared:

- control:
  - `stage3_preserve_tieband_probe_p9`
- candidate:
  - `stage3_phasec_start_balanced_p9`
- seed:
  - `411`

Decision after implementation:

- Study 2 should remain deferred until the Study 3 live readout is complete
- if Study 3 is negative despite confirmed start rebalancing, that will further
  strengthen the case for moving next toward Phase-B preservation or more
  upstream basin-generation work rather than more Phase-C policy tuning

## 10. Status Update: Study 3 Readout Complete

Study 3 is now closed as a valid negative on `seed411`.

What the run showed:

- the new `balanced_sources_v1` policy executed correctly
- the Phase-C candidate pool stayed unchanged, as intended
- the actual Phase-C starts also stayed unchanged
- the solve result stayed unchanged

Most important evidence:

- control run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T174120032623Z__bench_solve_pipeline_no_wli__55b7159`
- candidate run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T211041031812Z__bench_solve_pipeline_no_wli__55b7159`
- identical effective Phase-C start usage:
  - `phaseC_start_source_counts = { "stage3_best_phaseB": 1, "phaseA_selected": 5 }`
  - same six `candidate_hash` values in `phasec_start_checkpoints.jsonl`

Interpretation:

- the implemented Phase-C start rebalancing policy was too late to help on
  this seed / current pool shape
- by Phase-C start time, there is no additional distinct `phaseB_topk` start
  to exploit

Next implementation target:

- Study 2:
  - family-aware Phase-B preservation / downstream slot retention
- concrete brief:
  - `planning/working/no_wli_study2_phaseb_preservation_plan_2026-03-28.md`

Practical consequence:

- do not schedule another Phase-C-only long compare
- the next meaningful long run should happen only after a Study 2
  implementation exists

## 11. Status Update: Study 2 Implemented

Study 2 is now implemented and locally proven.

Locked implementation shape:

- downstream carry-forward preservation only
- no Phase-B ranking rewrite
- no new rescue behavior
- no new Phase-C balancing changes bundled into the same compare

Chosen v1 policy:

- `phaseb_family_preservation_policy = reserve_by_family_v1`
- `phaseb_family_view_id = prefix_hamming_le_24`
- `phaseb_family_reserved_slots = 2`

Proof state:

- deterministic Study 2 policy test exists and passes
- dedicated preset/config/lock/runtime/resume canary exists and passes
- fixture runtime materialization for the active compare exists and passes

Evidence:

- focused proof:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `30 passed`
- broader confirmation:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_periodic_sub_trans_runner_scorer_impl.py -q`
  - `95 passed`

Active handoff compare:

- seed:
  - `411`
- control:
  - `stage3_preserve_tieband_probe_p9`
- candidate:
  - `stage3_phaseb_family_preserve_p9`

Decision:

- the next meaningful long run is now the Study 2 `seed411` compare
- no additional implementation is required before handing that run to the user

## 12. Status Update: Study 2 First Live Readout Was Not Fully Auditable

The first v39 Study 2 compare completed, but it did not close the science
question yet.

What is already known from the live run:

- the intended config delta was present
- visible solve outcome did not improve
- visible Phase-C pool and start counters did not move

What prevented a locked conclusion:

- the new Study 2 family-preservation telemetry was not persisted into the
  saved artifact path used for review

So the next implementation step is narrower than a new science phase:

1. persist Study 2 family telemetry into saved artifacts
2. rerun the same v39 `seed411` compare
3. only then decide whether Study 2 is a valid negative or whether the saved
   telemetry reveals a more subtle downstream collapse
