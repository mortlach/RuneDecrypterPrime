# Basin-Family Diversity and Alignment Audit

This is an offline first-pass audit of basin-family diversity and score-truth alignment across strong and weak hard-seed `p9/c3` runs.

Definition:
- `best_family_truth`: For a given pool and family view, best_family_truth is the maximum truth-match value attained by any row inside the strongest family in that pool.

Family views:
- `exact_key`
- `exact_tail`
- `near_tail_h1`
- `prefix_hamming_le_24`

Failure-mode counts:
- `good_family_absent`: 1
- `good_family_undervalued`: 1

## seed511_recovery

- artifact: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- final best: match `0.771`, score `0.338039`, stage `stage3_full_refine`
- seed reference best: `0.794`
- classification: `no_failure_mode_crossed_threshold`
- classification_confidence: `0.00`
- reason: `no_failure_mode_crossed_threshold`

Stage pools:
- `stage2_topk`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.216`, selected family truth `0.209`, between-family regret `0.007`
  selected-vs-available `prefix_hamming_le_24`: available families `6`, selected families `1`, top-band family mass `0.583`
- `stage3_topk`: rows `5`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.757`, selected family truth `0.757`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`
- `phasec_start`: rows `6`, selected-top-band `4`, classification view `exact_key`
  best family truth `0.771`, selected family truth `0.771`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `0`, selected families `0`, top-band family mass `0.000`

## seed511_stage35_win

- artifact: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- final best: match `0.794`, score `0.353421`, stage `stage35_substitution_only`
- seed reference best: `0.794`
- classification: `reference_success`
- classification_confidence: `1.00`
- reason: `reference_success`

Stage pools:
- `stage2_topk`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.216`, selected family truth `0.209`, between-family regret `0.007`
  selected-vs-available `prefix_hamming_le_24`: available families `6`, selected families `1`, top-band family mass `0.583`
- `stage3_topk`: rows `5`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.757`, selected family truth `0.757`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`
- `phasec_start`: rows `6`, selected-top-band `4`, classification view `exact_key`
  best family truth `0.771`, selected family truth `0.771`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `0`, selected families `0`, top-band family mass `0.000`
- `stage35_archive`: rows `16`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.806`, selected family truth `0.806`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`

## seed211_current_preserve

- artifact: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260324T004559684950Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
- final best: match `0.574`, score `0.236896`, stage `stage3_full_refine`
- seed reference best: `0.637`
- classification: `good_family_absent`
- classification_confidence: `0.75`
- reason: `best_seen_family_truth_below_reference_seed_target`

Stage pools:
- `stage2_topk`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.209`, selected family truth `0.209`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `7`, selected families `1`, top-band family mass `0.500`
- `stage2_promoted`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.209`, selected family truth `0.209`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `7`, selected families `1`, top-band family mass `0.500`
- `stage3_init3`: rows `64`, selected-top-band `0`, classification view `prefix_hamming_le_24`
  best family truth `nan`, selected family truth `nan`, between-family regret `nan`
  selected-vs-available `prefix_hamming_le_24`: available families `6`, selected families `0`, top-band family mass `0.000`
- `stage3_topk`: rows `1`, selected-top-band `1`, classification view `prefix_hamming_le_24`
  best family truth `0.581`, selected family truth `0.581`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`
- `phasec_start`: rows `6`, selected-top-band `4`, classification view `exact_key`
  best family truth `0.574`, selected family truth `0.574`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `0`, selected families `0`, top-band family mass `0.000`
- `stage35_seed_archive`: rows `2`, selected-top-band `0`, classification view `prefix_hamming_le_24`
  best family truth `nan`, selected family truth `nan`, between-family regret `nan`
  selected-vs-available `prefix_hamming_le_24`: available families `2`, selected families `0`, top-band family mass `0.000`

## seed211_old_best

- artifact: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260309T092929767920Z__bench_solve_pipeline_no_wli__97536a2/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
- final best: match `0.637`, score `0.218927`, stage `stage3_full_refine`
- seed reference best: `0.637`
- classification: `reference_success`
- classification_confidence: `1.00`
- reason: `reference_success`

Stage pools:
- `stage2_topk`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.101`, selected family truth `0.101`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `2`, selected families `2`, top-band family mass `1.000`
- `stage3_topk`: rows `5`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.645`, selected family truth `0.645`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`

## seed411_current_preserve

- artifact: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260324T040609368464Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed411.json`
- final best: match `0.041`, score `-4.897537`, stage `stage2_search`
- seed reference best: `0.596`
- classification: `good_family_undervalued`
- secondary: `good_family_absent`
- classification_confidence: `0.99`
- reason: `latest_pool_between_family_regret`

Stage pools:
- `stage2_topk`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.207`, selected family truth `0.207`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `3`, selected families `1`, top-band family mass `0.500`
- `stage2_promoted`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.207`, selected family truth `0.207`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `3`, selected families `1`, top-band family mass `0.500`
- `stage3_init3`: rows `64`, selected-top-band `0`, classification view `prefix_hamming_le_24`
  best family truth `nan`, selected family truth `nan`, between-family regret `nan`
  selected-vs-available `prefix_hamming_le_24`: available families `3`, selected families `0`, top-band family mass `0.000`
- `stage3_topk`: rows `1`, selected-top-band `1`, classification view `prefix_hamming_le_24`
  best family truth `0.040`, selected family truth `0.040`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`
- `phasec_start`: rows `6`, selected-top-band `4`, classification view `exact_key`
  best family truth `0.418`, selected family truth `0.039`, between-family regret `0.379`
  selected-vs-available `prefix_hamming_le_24`: available families `0`, selected families `0`, top-band family mass `0.000`
- `stage35_seed_archive`: rows `2`, selected-top-band `0`, classification view `prefix_hamming_le_24`
  best family truth `nan`, selected family truth `nan`, between-family regret `nan`
  selected-vs-available `prefix_hamming_le_24`: available families `2`, selected families `0`, top-band family mass `0.000`

## seed411_old_best

- artifact: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T020424363346Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed411.json`
- final best: match `0.596`, score `0.275102`, stage `stage3_full_refine`
- seed reference best: `0.596`
- classification: `reference_success`
- classification_confidence: `1.00`
- reason: `reference_success`

Stage pools:
- `stage2_topk`: rows `12`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.207`, selected family truth `0.207`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `3`, selected families `1`, top-band family mass `0.500`
- `stage3_topk`: rows `5`, selected-top-band `4`, classification view `prefix_hamming_le_24`
  best family truth `0.607`, selected family truth `0.607`, between-family regret `0.000`
  selected-vs-available `prefix_hamming_le_24`: available families `1`, selected families `1`, top-band family mass `1.000`
