# Evidence Index

This pack is designed to be self-contained. The main copied materials are below.

## Root summary documents

- `README.md`
- `01_summary_for_reviewers.md`
- `02_four_live_tests_and_results.md`
- `03_pipeline_hardening_status.md`
- `04_open_questions_and_blockers.md`
- `05_evidence_index.md`

## Planning logs copied into this pack

Directory:
- `planning_logs/`

Files:
- `planning_logs/no_wli_science_run_log_2026-03-26.md`
- `planning_logs/no_wli_solve_integrity_plan_2026-03-21.md`
- `planning_logs/no_wli_pipeline_hardening_backlog_2026-03-30.md`
- `planning_logs/no_wli_locked_experiment_specs_2026-03-28.md`
- `planning_logs/no_wli_next_phase_implementation_plan_2026-03-27.md`
- `planning_logs/no_wli_study1_readout_checklist_2026-03-27.md`
- `planning_logs/no_wli_study2_phaseb_preservation_plan_2026-03-28.md`
- `planning_logs/no_wli_study2_readout_checklist_2026-03-28.md`
- `planning_logs/no_wli_pipeline_hardening_review_2026-03-25.md`
- `planning_logs/March27_2026_review v2.txt`

## Matrix control files

Directory:
- `evidence/matrix_controls/`

Copied study control sets:

- `v36` precursor compare
  - `fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - `fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - `fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`

- `v37` Study 1
  - `fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`
  - `fixture_matrix_run_events_tune_v37_p9c3_seed211_stage3_entry_compare_2job.jsonl`
  - `fixture_matrix_plan_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`

- `v38` Study 3
  - `fixture_matrix_run_state_tune_v38_p9c3_seed411_phasec_start_compare_2job.json`
  - `fixture_matrix_run_events_tune_v38_p9c3_seed411_phasec_start_compare_2job.jsonl`
  - `fixture_matrix_plan_tune_v38_p9c3_seed411_phasec_start_compare_2job.json`

- `v40` Study 2 rerun
  - `fixture_matrix_run_state_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.json`
  - `fixture_matrix_run_events_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.jsonl`
  - `fixture_matrix_plan_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.json`

- `v42` width probe rerun
  - `fixture_matrix_run_state_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.json`
  - `fixture_matrix_run_events_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.jsonl`
  - `fixture_matrix_plan_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.json`

## Copied run directories

Directory:
- `evidence/run_dirs/`

Copied runs:

- precursor `v36`
  - `20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159`
  - `20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159`

- Study 1 `v37`
  - `20260328T013131043374Z__bench_solve_pipeline_no_wli__55b7159`
  - `20260328T050751414997Z__bench_solve_pipeline_no_wli__55b7159`

- Study 3 `v38`
  - `20260328T174120032623Z__bench_solve_pipeline_no_wli__55b7159`
  - `20260328T211041031812Z__bench_solve_pipeline_no_wli__55b7159`

- Study 2 `v40`
  - `20260329T155853670179Z__bench_solve_pipeline_no_wli__55b7159`
  - `20260329T204310438057Z__bench_solve_pipeline_no_wli__55b7159`

- width probe `v42`
  - `20260330T150529396668Z__bench_solve_pipeline_no_wli__55b7159`
  - `20260330T175546232525Z__bench_solve_pipeline_no_wli__55b7159`

Each copied run directory includes the usual reviewable artifacts:
- `instances.json`
- `stages.json`
- `summary.json`
- `run_config.json`
- `run_manifest.json`
- `phasec_start_checkpoints.jsonl`
- `best/best_instance.json`
- `final_instances/...json`
- `resume_handoffs/.../manifest.json`
- `resume_handoffs/.../stage3_prep.json`

## Ancillary evidence

Directory:
- `evidence/ancillary/`

Included:

- earlier `seed411` ranking probe folder
  - `20260325T145319Z_seed411_phasec_ranking_probe`
- current no-WLI catalog snapshot
  - `no_wli_catalog`

Useful files inside `no_wli_catalog/`:
- `basin_regression_summary.json`
- `selector_ladder_audit_summary.json`
- `partial_state_signal_audit_summary.json`
- `basin_family_diversity_audit_summary.json`
- companion `.md` reports for each

## Invalid or incomplete runs kept for operational context

Directory:
- `evidence/invalid_or_incomplete_runs/`

Included:
- `v39` first Study 2 control files
  - incomplete science interpretation before telemetry-persistence fix
- `v41` first width-probe control files
  - invalid compare due to runtime failure
- partial candidate run dir:
  - `20260330T085228874213Z__bench_solve_pipeline_no_wli__55b7159`

These are not the main science story, but they are included because they
matter for understanding why hardening work remained necessary.

## Previous pack appendix

Directory:
- `appendices/`

Included:
- `appendices/no_wli_external_review_pack_2026-03-26.zip`

This preserves the previous review snapshot without forcing reviewers to go
back out to the live repo tree.
