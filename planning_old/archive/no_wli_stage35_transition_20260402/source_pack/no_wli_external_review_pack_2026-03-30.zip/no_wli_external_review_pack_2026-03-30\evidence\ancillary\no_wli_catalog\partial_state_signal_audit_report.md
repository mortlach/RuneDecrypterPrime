# no_wli Partial-State Signal Audit

Generated: 2026-03-23T15:04:02.044261+00:00

## Scope

Selected hard-case runs:
- `seed511_old_best`: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- `seed511_recovery`: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- `seed511_stage35_win`: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- `seed211_old_best`: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260309T092929767920Z__bench_solve_pipeline_no_wli__97536a2/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
- `seed211_stage35_fail`: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T192204224097Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
- `seed411_old_best`: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T020424363346Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed411.json`

This audit checks whether existing live-visible partial-state signals separate stronger and weaker hard-case basins before late refinement.

## Main findings

- Stage-2 partial-state scores remain weak as basin discriminators across the selected hard runs: `score_stage2` run-max/final-match correlation is 0.265.
- Stage-3 top-k scores carry much stronger basin signal once the search reaches a useful family: `score_judge` run-max/final-match correlation is 0.880, with strong-vs-weak separation gap 0.050475.
- Late Stage-3.5 full-score improvements are not sufficient on weak seeds when search support is absent: the archive `search_score` signal still shows stronger truth alignment than raw archive score (row/truth corr 0.995).

## Conclusion

- Current live-visible signals do not separate strong from dead states well enough before Stage 3, but they do become informative inside Stage-3 top-k and later. The general failure therefore looks like weak early/mid basin signal plus seed-sensitive search reach, not a completely broken late-stage scorer.

## Run summary

| Run | Seed | Final Match | Bucket | Stage2 Rows | Stage3 Rows | PhaseC Rows | Stage35 Seed Rows | Stage35 Archive Rows |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| seed511_stage35_win | 511 | 0.794 | strong | 12 | 5 | 6 | 6 | 16 |
| seed511_old_best | 511 | 0.773 | strong | 12 | 5 | 0 | 0 | 0 |
| seed511_recovery | 511 | 0.771 | strong | 12 | 5 | 6 | 0 | 0 |
| seed211_old_best | 211 | 0.637 | weak | 12 | 5 | 0 | 0 | 0 |
| seed411_old_best | 411 | 0.596 | weak | 12 | 5 | 0 | 0 | 0 |
| seed211_stage35_fail | 211 | 0.574 | weak | 12 | 1 | 6 | 2 | 16 |

## Signal summary

| State | Signal | Runs | Strong Runs | Weak Runs | Row Score/Truth Corr | Run Max/Final Corr | Top-Is-Best Rate | Mean Truth Regret | Strong-Weak Gap |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| stage2_topk | score_stage2 | 6 | 3 | 3 | 0.338 | 0.265 | 0.167 | 0.038 | -0.004827 |
| stage2_topk | score_judge | 6 | 3 | 3 | 0.338 | 0.265 | 0.167 | 0.038 | -0.004827 |
| stage3_topk | score_raw | 6 | 3 | 3 | 0.824 | 0.870 | 0.667 | 0.003 | 0.253457 |
| stage3_topk | score_pct | 6 | 3 | 3 | 0.824 | 0.870 | 0.667 | 0.003 | 0.253457 |
| stage3_topk | score_judge | 6 | 3 | 3 | 0.846 | 0.880 | 0.667 | 0.003 | 0.050475 |
| phasec_start | final_score | 3 | 2 | 1 | 0.967 | 0.995 | 1.000 | 0.000 | 0.101143 |
| phasec_start | init_search_score | 3 | 2 | 1 | 0.972 | 0.995 | 0.333 | 0.007 | 0.624639 |
| phasec_start | score_gain | 3 | 2 | 1 | -0.491 | -0.995 | 0.000 | 0.090 | -0.010962 |
| stage35_seed | score | 2 | 1 | 1 | 0.993 | 1.000 | 0.500 | 0.004 | 0.101143 |
| stage35_seed | search_score | 2 | 1 | 1 | 0.972 | 1.000 | 0.500 | 0.007 | 0.624639 |
| stage35_seed | checkpoint_final_score | 1 | 1 | 0 | nan | nan | 1.000 | 0.000 | nan |
| stage35_archive | score | 2 | 1 | 1 | 0.998 | 1.000 | 0.000 | 0.009 | 0.110673 |
| stage35_archive | search_score | 2 | 1 | 1 | 0.995 | 1.000 | 0.500 | 0.005 | 0.883497 |
