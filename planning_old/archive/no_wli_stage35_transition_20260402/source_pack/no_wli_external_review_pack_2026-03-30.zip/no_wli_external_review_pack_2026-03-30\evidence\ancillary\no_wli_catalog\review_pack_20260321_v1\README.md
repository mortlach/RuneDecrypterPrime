# no_wli Review Pack

Date: 2026-03-21
Scope: `tools/benchmarks/periodic_sub_trans/no_wli`

This pack was assembled to answer the reviewer request for:

- the missing live no-WLI profile-definition source
- the latest current basin / selector / recovery summaries
- one factual inventory note explaining which files are current, which are historical/supporting, and what the current best evidence actually is

## What the reviewer asked for

### 1. Current profile-definition source

Included here:

- `tools/benchmarks/config/no_wli_pipeline_profiles.py`

This is the benchmark-facing no-WLI profile-definition source that was missing from the earlier snapshot.

### 2. Latest current evidence files

Included here:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/solve_status_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/best_p9_c3_runs.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/notable_artifacts.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_report.md`
- `planning/working/no_wli_solve_integrity_plan_2026-03-21.md`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`

Also included for catalog-level cross-checking:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/run_manifest.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/special_analysis_manifest.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/fixture_matrix_files.csv`

### 3. Factual inventory summary

This file is that summary.

## Current vs historical

### Current and authoritative for the present branch state

These are the files that should be treated as the current source of truth:

- `planning/working/no_wli_solve_integrity_plan_2026-03-21.md`
  - active working plan with phase/gate status
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/solve_status_report.md`
  - current branch-level status note
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
  - current Phase 2 outputs
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
  - current Phase 3 outputs
- `tools/benchmarks/config/no_wli_pipeline_profiles.py`
  - live benchmark profile definitions
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - active bounded run setup, currently on the `stage3_recovery_p9_8h` preset

### Current catalog summaries and raw indexes

These are current and useful, but they are indexes rather than decision memos:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/best_p9_c3_runs.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/notable_artifacts.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/run_manifest.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/special_analysis_manifest.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/fixture_matrix_files.csv`

### Historical / supporting, not the current decision record

The pack includes a few artifact files directly so the reviewer can inspect the canonical old/current examples without chasing paths. These are supporting evidence, not the current "decision memo" layer:

- old best `p9/c3` artifact and config
- March 15 narrow Phase-C `p9/c3` artifact and config
- latest invalid Stage-3.5 proof attempt artifact and config
- best `p11` artifact found locally
- best `p13` artifact found locally

The broader replay experiment directories under:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/phasec_rescue_replay/*`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/phasec_slice_signal_analysis/*`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/stage35_substitution_replay/*`

are useful historical context, but they are not the current authoritative summary layer. They are indexed in `special_analysis_manifest.csv` rather than copied in full into this pack.

## Current control ladder

This is the ladder currently used in the working plan and selector audit:

- easy controls:
  - `fixture_fixture_001_p5_c1_l1000`
  - `fixture_fixture_001_p5_c3_l1000`
  - `fixture_fixture_001_p7_c1_l1000`
  - `fixture_fixture_001_p7_c5_l1000`
- medium-ish control:
  - `fixture_fixture_001_p9_c1_l1000`
- hard target:
  - `fixture_fixture_001_p9_c3_l1000`

This ladder is grounded in the current catalog, not in aspirational `p11` / `p13` targets.

## Latest claimed best evidence

### `p9/c3/l1000`

Canonical best hard-case artifacts are still the older March runs:

- best:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - `best_match_ratio = 0.773`
- next:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260315T001203236783Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - `best_match_ratio = 0.765`
- next:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
  - `best_match_ratio = 0.761`

Latest bounded proof attempt:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- `best_match_ratio = 0.668`

Important branch-validity note:

- the matching run config requested Stage-3.5:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/run_config.json`
- but the final artifact reported:
  - `stage35_enabled_cfg = 0`
  - `stage35_ran = 0`
  - `stage35_archive_count = 0`

So that `0.668` artifact is not a valid Stage-3.5 proof result. It is a Phase-C result from an invalid proof path.

### `p11+` attempts

Summary file included:

- `p11_plus_best_runs.csv`

Best `p11` artifact found locally:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260310T160816286178Z__bench_solve_pipeline_no_wli__97536a2/final_instances/fixture_fixture_001_p11_c1_l1000__text0__seed211.json`
- `best_match_ratio = 0.297`
- `best_stage = stage3_full_refine`

Best `p13` artifact found locally:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260305T111028Z__bench_solve_pipeline_no_wli__41e5351/final_instances/fixture_fixture_001_p13_c1_l1000__text0__seed111.json`
- `best_match_ratio = 0.364`
- `best_stage = stage3_full_refine`

These higher-period results are still sparse and weak compared with the `p9/c3` history, which is why the current decision ladder stays on `p9` rather than promoting `p11` or `p13` yet.

## What the current analyses say

### Phase 2 basin regression

The current Phase 2 output concludes:

- primary culprit: `inside_stage3_basin_generation`

Because on the main hard-case comparison:

- `stage2_topk` top-5 mean match is effectively unchanged
  - `0.0958 -> 0.0958`
- `stage3_topk` top-5 mean match collapses
  - `0.7678 -> 0.6378`
- final best also drops
  - `0.773 -> 0.668`

### Phase 3 selector/scorer audit

The current Phase 3 output concludes:

- ranking is imperfect
- but it is not the main reason the hard family collapsed

Key numbers from the audit:

- easy controls:
  - zero observed top-k truth regret
- `p9/c1`:
  - mean top-k truth regret `0.0034`
  - top-is-best rate `0.444`
- `p9/c3`:
  - mean top-k truth regret `0.0007`
  - top-is-best rate `0.825`
  - final score/match correlation across runs `0.915`

Interpretation:

- do not start with a scorer rewrite
- recover the stronger Stage-3 basin first

## What the active recovery run is trying to do

The active bounded preset in `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py` is:

- `stage3_recovery_p9_8h`

It deliberately:

- restores the older narrow March 15-style Stage-3 regime
- keeps Phase-C enabled
- keeps Stage-3.5 disabled
- limits the experiment to one bounded `p9/c3` proof run

This is intended to answer one question:

- can the older narrow Stage-3 regime recover the stronger `p9/c3` basin family before any fresh Stage-3.5 proof is attempted?

## Pack contents

### Code / planning

- `tools/benchmarks/config/no_wli_pipeline_profiles.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
- `planning/working/no_wli_solve_integrity_plan_2026-03-21.md`

### Current catalog/report layer

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/README.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/solve_status_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/best_p9_c3_runs.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/notable_artifacts.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/run_manifest.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/special_analysis_manifest.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/fixture_matrix_files.csv`

### Curated direct artifacts

- old best `p9/c3` run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/run_config.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- March 15 narrow Phase-C `p9/c3` recovery target:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e/run_config.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- latest invalid Stage-3.5 proof attempt:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/run_config.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- best `p11` artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260310T160816286178Z__bench_solve_pipeline_no_wli__97536a2/final_instances/fixture_fixture_001_p11_c1_l1000__text0__seed211.json`
- best `p13` artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260305T111028Z__bench_solve_pipeline_no_wli__41e5351/final_instances/fixture_fixture_001_p13_c1_l1000__text0__seed111.json`
- `p11_plus_best_runs.csv`

