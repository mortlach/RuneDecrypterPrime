# Four Live Tests And Results

This note records the four locked live studies that followed the review lock.
The earlier `v36` `seed411` compare is included at the end because it remains a
key precursor signal, but it is not counted as one of the four locked studies.

## Study 1: Constant Local-Depth Stage-3 Entry

Question:
- is `seed211` mainly failing because wider Stage-2 preservation is being
  squeezed back down into too little local Stage-3 depth per promoted family?

Control:
- `stage3_preserve_tieband_probe_p9`

Candidate:
- `stage3_entry_const_local_depth_p9`

Control evidence:
- `evidence/run_dirs/20260328T013131043374Z__bench_solve_pipeline_no_wli__55b7159`

Candidate evidence:
- `evidence/run_dirs/20260328T050751414997Z__bench_solve_pipeline_no_wli__55b7159`

Execution proof:
- control `resume_handoffs/.../stage3_prep.json`
  - `stage3_entry_allocation_policy = "legacy_fixed_budget"`
  - `stage3_entry_target_before_cap = 64`
- candidate `resume_handoffs/.../stage3_prep.json`
  - `stage3_entry_allocation_policy = "constant_local_depth"`
  - `stage3_entry_target_before_cap = 288`
- control `resume_handoffs/.../manifest.json`
  - `stage3_init3_count = 64`
- candidate `resume_handoffs/.../manifest.json`
  - `stage3_init3_count = 144`

Observed result:
- `best_match_ratio: 0.574 -> 0.574`
- `stage3_match_ratio: 0.574 -> 0.574`
- `phaseB_selected_unique_end_hash: 8 -> 8`
- `phaseC_candidate_pool_unique_end_hash: 8 -> 8`
- `phaseC_start_keys_used: 6 -> 6`

Conclusion:
- valid negative
- simple Stage-3 entry-budget starvation is not the main limiter for this
  `seed211` case

## Study 3: Phase-C Start Balancing

Question:
- on `seed411`, is already-carried late-stage variety failing mainly because
  actual Phase-C starts are chosen in a biased source order?

Control:
- `stage3_preserve_tieband_probe_p9`

Candidate:
- `stage3_phasec_start_balanced_p9`

Control evidence:
- `evidence/run_dirs/20260328T174120032623Z__bench_solve_pipeline_no_wli__55b7159`

Candidate evidence:
- `evidence/run_dirs/20260328T211041031812Z__bench_solve_pipeline_no_wli__55b7159`

Execution proof:
- control `run_config.json`
  - `stage3.two_phase.phase_c.start_policy = "source_order"`
- candidate `run_config.json`
  - `stage3.two_phase.phase_c.start_policy = "balanced_sources_v1"`

Observed result:
- `best_match_ratio: 0.041 -> 0.041`
- `stage3_match_ratio: 0.039 -> 0.039`
- candidate pool unchanged:
  - `phaseC_candidate_pool_count: 10 -> 10`
  - `phaseC_candidate_pool_unique_end_hash: 8 -> 8`
- starts unchanged:
  - `phaseC_start_keys_used: 6 -> 6`
  - `phaseC_start_unique_end_hash: 6 -> 6`
  - same six `candidate_hash` values in `phasec_start_checkpoints.jsonl`

Conclusion:
- valid negative
- Phase-C start ordering alone is too late to matter under the current
  downstream carried set

## Study 2: Family-Aware Phase-B Preservation

Question:
- on `seed411`, are useful families being lost before Phase-C because the late
  carried set is not family-protective enough?

Control:
- `stage3_preserve_tieband_probe_p9`

Candidate:
- `stage3_phaseb_family_preserve_p9`

Control evidence:
- `evidence/run_dirs/20260329T155853670179Z__bench_solve_pipeline_no_wli__55b7159`

Candidate evidence:
- `evidence/run_dirs/20260329T204310438057Z__bench_solve_pipeline_no_wli__55b7159`

Execution proof:
- control `best/best_instance.json`
  - `phaseB_family_preservation_policy = "off"`
- candidate `best/best_instance.json`
  - `phaseB_family_preservation_policy = "reserve_by_family_v1"`
  - `phaseB_family_reserved_slots = 2`
  - `phaseB_family_reservation_applied = 1`

Observed result:
- `best_match_ratio: 0.041 -> 0.041`
- `stage3_match_ratio: 0.039 -> 0.039`
- `phaseB_selected_unique_end_hash: 8 -> 8`
- `phaseB_downstream_selected_unique_end_hash: 8 -> 8`
- `phaseC_candidate_pool_unique_end_hash: 8 -> 8`
- `phaseC_start_keys_used: 6 -> 6`

Conclusion:
- valid negative
- preserving families inside the current top-8 Phase-B band is not the active
  bottleneck on `seed411`

## Width Probe: Phase-B Carry-Forward Width

Question:
- on `seed411`, does simply widening the late Phase-B carry-forward band create
  enough additional exploitable variety to improve the solve?

Control:
- `stage3_preserve_tieband_probe_p9`

Candidate:
- `stage3_phaseb_width_probe_p9`

Control evidence:
- `evidence/run_dirs/20260330T150529396668Z__bench_solve_pipeline_no_wli__55b7159`

Candidate evidence:
- `evidence/run_dirs/20260330T175546232525Z__bench_solve_pipeline_no_wli__55b7159`

Execution proof:
- control `run_config.json`
  - `phase_b_top_n = 8`
- candidate `run_config.json`
  - `phase_b_top_n = 32`

Observed result:
- `best_match_ratio: 0.041 -> 0.041`
- `stage3_match_ratio: 0.039 -> 0.039`
- carried variety widened sharply:
  - `phaseB_selected_unique_end_hash: 8 -> 32`
  - `phaseB_downstream_selected_unique_end_hash: 8 -> 32`
  - `phaseC_candidate_pool_count: 10 -> 34`
  - `phaseC_candidate_pool_unique_end_hash: 8 -> 32`
- exploited variety did not change:
  - `phaseC_start_keys_used: 6 -> 6`
  - `phaseC_start_unique_end_hash: 6 -> 6`
  - same checkpoint hashes and same source counts

Conclusion:
- valid negative on solve outcome
- strong positive signal on carried late-stage width
- strongest current evidence that carried variety and exploited variety are
  still different things

## Important Precursor: Earlier `seed411` Broader Candidate

This compare is not one of the four locked studies, but it remains important
because it showed the pipeline can respond to a real lever.

Control evidence:
- `evidence/run_dirs/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159`

Candidate evidence:
- `evidence/run_dirs/20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159`

Observed result:
- `best_match_ratio: 0.041 -> 0.046`
- `stage3_match_ratio: 0.039 -> 0.046`
- `phaseB_selected_unique_end_hash: 8 -> 32`
- `phaseC_candidate_pool_unique_end_hash: 8 -> 32`
- `phaseC_start_keys_used: 6 -> 8`
- winner source shifted to `phaseB_topk`

Why it still matters:
- it supports the late-family-width / exploitation-bottleneck story
- it shows the system is not frozen against all changes
- but it is not a clean one-variable proof of Phase-C ordering alone
