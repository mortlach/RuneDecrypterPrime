# No-WLI Science Run Log

Purpose:

- record hypotheses, run setups, outcomes, and next actions in one verifiable place
- keep each claim tied to concrete evidence in repo-relative run artifacts
- separate "pipeline plumbing worked" from "solve quality improved"

Verification rule:

- every result claim below names at least one concrete artifact path and the field or log line that supports it
- if a claim is only an inference, it is labelled as an inference

## 2026-03-26 backfilled evidence

### Entry A: live handoff emission canary on seed211

Question:

- did the live commit / handoff path finish cleanly and emit a real live Stage-2 to Stage-3 handoff bundle?

Run:

- live canary run directory:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159`

Outcome:

- yes, the live handoff path completed and emitted a handoff bundle
- no, solve quality did not improve

Cross-checked evidence:

- handoff emitted from live pipeline:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
  - field: `stage2_to_stage3.source = "live_stage3_pipeline"`
- live result stayed weak:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage2_match_ratio = 0.209`
    - `stage3_match_ratio = 0.574`
    - `best_stage = "stage3_full_refine"`
- run finished normally:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/ops_logs/run_fixture_matrix_seed211_v34_bridge_contract_20260325T182911.stdout.log`
  - tail contains:
    - `completed in 5h56m`
    - `[no_wli_fixture_matrix] completed session_completed_jobs=1 total_completed_jobs=1`

Conclusion:

- the live handoff-emission bug class is fixed on the real path
- this was a reliability win, not a solve-quality win

### Entry B: seed411 fixed-handoff ranking probe

Question:

- can small lexical-gate / tie-window changes promote the truth-better challenger family on the saved weak seed411 handoff?

Run:

- resume probe report:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- machine summary:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`

Outcome:

- no
- all three variants ended at the same resumed best match

Cross-checked evidence:

- report table in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
  - rows show:
    - `baseline_phasec_ranking -> Resume Match 0.032`
    - `lexical_gate_035_tie_025 -> Resume Match 0.032`
    - `lexical_gate_030_tie_050 -> Resume Match 0.032`
    - `Best Truth Start 0.099`
    - `Truth Gap 0.067`
    - `Stop Reason stalled_no_improve`
- summary details in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`
  - per-variant fields show:
    - `resume_best_match_ratio = 0.032`
    - `checkpoint_summary.best_truth_match = 0.099`
    - `between_family_truth_gap = 0.067`

Conclusion:

- small lexical-gate widening was not enough on fixed seed411 downstream state
- next seed411 candidate should be meaningfully broader than a small gate tweak

### Entry C: 10-job weak-seed overnight live matrix, jobs 1-3 only

Question:

- can weak-seed live performance be lifted by preservation changes or by Stage-3.5, and can this be learned from a broad overnight matrix?

Run control files:

- run state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
- run events:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`

Outcome:

- only the first three jobs completed before the between-jobs wallclock stop
- all three completed jobs were `seed211`
- none improved beyond `0.574`
- Stage-3.5 executed for the proof lane but did not win

Cross-checked evidence:

- run stopped early after job 3:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
  - fields:
    - `completed_jobs = 3`
    - `remaining_jobs = 7`
    - `stopped_early = 1`
- event log confirms completed jobs and runtimes:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`
  - rows show:
    - job 1 `stage3_preserve_tieband_probe_p9` elapsed `13193.243979...`
    - job 2 `stage3_recovery_p9_8h` elapsed `11181.895447...`
    - job 3 `stage35_proof_p9_8h` elapsed `51995.484903...`
- job 1 result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 0`
- job 2 result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 0`
- job 3 result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_match_ratio = 0.574`
    - `stage35_requested_cfg = 1`
    - `stage35_selected = false`
    - `stage35_archive_count = 16`
    - `stage35_rounds_completed = 3`
- job 3 Stage-3.5 rejection reason:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
  - field:
    - `stage35_accept_reason = "search_score_drop_guard_failed"`
- all three completed runs emitted live handoff bundles:
  - each run dir contains:
    - `resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
  - field:
    - `stage2_to_stage3.source = "live_stage3_pipeline"`

Conclusion:

- broad live matrices were too slow for fast iteration
- on seed211:
  - preservation baseline did not improve
  - wider recovery did not improve
  - Stage-3.5 was real and auditable, but too expensive and still lost to Stage-3

Inference:

- Stage-3.5 should not be in the default short comparison lane unless a run is explicitly about Stage-3.5 acceptance behavior

## v36 short seed411 comparison

Question:

- on live `seed411`, does the broader downstream package
  `lexical_phasec_rescue_wide_finish` materially beat the preserved control
  `stage3_preserve_tieband_probe_p9`?

Setup:

- seed:
  - `411`
- presets:
  - `stage3_preserve_tieband_probe_p9`
  - `lexical_phasec_rescue_wide_finish`
- control files:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`

Outcome:

- the broader candidate beat the control, but only weakly:
  - control:
    - `best_match_ratio = 0.041`
    - `best_stage = "stage2_search"`
  - broader candidate:
    - `best_match_ratio = 0.046`
    - `best_stage = "stage3_full_refine"`
- both runs finished cleanly and emitted live handoff bundles
- the explicit Phase-C rescue lane in the broader candidate was enabled but did
  not actually run

Cross-checked evidence:

- matrix completed cleanly:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - fields:
    - `completed_jobs = 2`
    - `remaining_jobs = 0`
    - `stopped_early = 0`
- job order and runtimes:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - job 1 preserve completed in `16628.888...` seconds
  - job 2 broader candidate completed in `25767.437...` seconds
- control run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_stage = "stage2_search"`
    - `best_match_ratio = 0.041`
    - `stage2_match_ratio = 0.041`
    - `stage3_match_ratio = 0.039`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed411/manifest.json`
  - field:
    - `stage2_to_stage3.source = "live_stage3_pipeline"`
- broader candidate run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - fields:
    - `best_stage = "stage3_full_refine"`
    - `best_match_ratio = 0.046`
    - `stage2_match_ratio = 0.041`
    - `stage3_match_ratio = 0.046`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed411/manifest.json`
  - field:
    - `stage2_to_stage3.source = "live_stage3_pipeline"`
- broader internal width really changed:
  - control best artifact:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
    - fields:
      - `phaseB_top_n_used = 8`
      - `phaseB_selected_unique_end_hash = 8`
      - `phaseC_start_keys_used = 6`
      - `phaseC_candidate_pool_unique_end_hash = 8`
  - broader candidate best artifact:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
    - fields:
      - `phaseB_top_n_used = 32`
      - `phaseB_selected_unique_end_hash = 32`
      - `phaseC_start_keys_used = 8`
      - `phaseC_candidate_pool_unique_end_hash = 32`
- rescue did not actually activate in the broader candidate:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T091806220616Z__bench_solve_pipeline_no_wli__55b7159/stages.json`
  - fields:
    - `phaseC_rescue_enabled = 1`
    - `phaseC_rescue_ran = 0`
    - `phaseC_rescue_eligible_starts = 0`
    - `phaseC_final_winner_source = "phaseB_topk"`
- control Phase-C slightly worsened the Phase-B winner:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260327T044057282813Z__bench_solve_pipeline_no_wli__55b7159/stages.json`
  - fields:
    - `phaseB_top_n_used = 8`
    - `phaseB_selected_unique_end_hash = 8`
    - `phaseC_rescue_enabled = 0`
    - `phaseC_final_winner_source = "stage3_best_phaseB"`
    - Phase-B `match_ratio = 0.04`
    - Phase-C `match_ratio = 0.039`

Conclusion:

- the broader downstream package produced a real but very small gain on live
  `seed411`: `0.041 -> 0.046`
- that is enough to say the wider Phase-B / Phase-C package was not a complete
  dead end
- it is not enough to say downstream rescue is "working" in any meaningful
  solve sense
- the observed improvement came from broader Phase-B / Phase-C family breadth,
  not from the explicit rescue lane, because rescue never became eligible

Inference:

- this result fits the current structural suspicion better than the earlier
  "one more rescue tweak" story:
  - more family width helped a little
  - explicit rescue logic did not actually engage
- the next best questions should now be more about family survival and objective
  alignment than about yet another small rescue tweak

## External review pack assembled

Purpose:

- package the current state, recent evidence, active hypotheses, and review
  questions into one review-first folder for outside help

Pack location:

- `planning/working/no_wli_external_review_pack_2026-03-26/`

Key reviewer-facing files:

- `planning/working/no_wli_external_review_pack_2026-03-26/README.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/01_current_state.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/02_recent_experiments_and_observations.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/03_pipeline_reliability_and_methodology.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/04_hypotheses_and_next_decisions.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/05_questions_for_external_review.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/06_evidence_index.md`

## 2026-03-27 reviewer-driven code cross-check on Stage-3 family selection

Question:

- do the reviewer concerns about Stage-3 entry dilution, objective mismatch, and
  early family collapse hold up against the actual code and saved artifacts?

Confirmed from code:

- Stage-3 entry dilution mechanism is real:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_seeding.py`
  - lines `50-95`
  - `init3_n` is fixed first, `promoted_keys` is built, `per_seed = ceil(init3_n / len(promoted_keys))`,
    then each promoted seed is mutated `per_seed` times and truncated back to `init3_n`
- Phase-A basin-judge pool is search-first before judged pct scoring:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
  - lines `330-355`
  - `judge_ranked` is ordered by:
    - `end_score_search`
    - `end_match`
    - `end_score_raw`
    - restart index
- Phase-B family selection is pct-first:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
  - lines `754-817`
  - `_phaseb_rank_key(...)` starts with `end_score_pct`
  - `end_score_raw` is later in the key
  - dedupe is by `(start_hash, end_hash)`
  - tie-band widening is still around `end_score_pct`
- The active avg/full-text profile really does set raw-score-led Stage-3 solve
  defaults and wider profile budgets:
  - `tools/benchmarks/config/no_wli_pipeline_profiles.py`
  - lines `242-306`
  - fields:
    - `stage3_initial_keys = 64`
    - `stage12_archive_keep = 192`
    - `stage12_promote_top = 96`
    - `solver_stage3["use_raw_score"] = True`
- The current live compare is not a single-variable test:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
  - `stage3_preserve_tieband_probe_p9` at lines `153-197`
  - `lexical_phasec_rescue_wide_finish` at lines `524-568`
  - the candidate changes multiple knobs at once:
    - `force_stage3_initial_keys`
    - `force_stage3_span_basin_judge_tie_max_seeds`
    - Phase-A steps
    - Phase-B `top_n`
    - Phase-B steps / gate floors
    - Phase-C start keys / proposals
- The single saved Phase-B top-k row case is explainable by current solver
  telemetry semantics, not automatically by a save bug:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_topk.py`
  - lines `10-60`
  - `src/rune_decrypter_prime/solvers/kaeding_periodic_structured.py`
  - lines `317-338`, `601-605`
  - Kaeding `top_candidates` is only extended on new global raw-score bests via
    `_record_top(...)`, then `top_keys/top_raw/top_pct` are emitted from that
    list
  - a run can therefore have a broad Phase-B selected set but only one saved
    `phaseB_topk` row

Saved-artifact cross-checks:

- one-row Phase-B top-k case:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T192204224097Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
  - fields:
    - `phaseB_top_n_used = 8`
    - `phaseB_selected_unique_end_hash = 8`
    - `phaseB_topk_saved_count = 1`
- same weak run appears in the catalog audit:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
  - one row records `stage3_topk_rows = 1`

Important caveats:

- the profile-level raw-score / widened-budget point is confirmed at the profile
  definition layer, but active live presets can override some of those budget
  fields
- the current v36 comparison is therefore evidence about a multi-knob live
  package, not a pure readout of the base avg/full-text profile defaults
- none of the code checks above proves causality by itself; they confirm that
  the reviewer's proposed mechanisms are plausible and materially present in the
  implementation

Working conclusion:

- the reviewer concern is materially supported by code:
  - Stage-3 inner search can be raw-score-led
  - Phase-B family selection remains pct-led
  - wider preservation can reduce local mutation depth per promoted family if
    `init3_n` does not scale with family count
- this is now one of the strongest code-backed explanations for why weak-seed
  families may be underfed at entry and then collapsed too early downstream

Still not fully verified:

- exact survival of distinct Phase-B families into Phase-C starts and Stage-3.5
  seed construction
- whether the decisive weak-seed failures are mostly:
  - entry dilution
  - objective mismatch
  - early family collapse
  - or a combination

Raw working-doc snapshots included in the same pack:

- `planning/working/no_wli_external_review_pack_2026-03-26/appendix_science_run_log_2026-03-26.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/appendix_pipeline_hardening_review_2026-03-25.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/appendix_solve_integrity_plan_2026-03-21.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/appendix_deep_research_report.md`
- `planning/working/no_wli_external_review_pack_2026-03-26/deep_research_pack_snapshot/`

Current live status included in the pack:

- active short run control files:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`

## 2026-03-27 Study 1 implementation: explicit constant-local-depth Stage-3 entry

Question:

- can Study 1 be implemented as an explicit, auditable Stage-3 entry policy
  while preserving legacy behavior by default and preparing a clean two-job
  live compare on `seed211`?

Implemented code surface:

- Stage-3 entry policy and telemetry:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_seeding.py`
- Stage-3 stop-line and diagnostics propagation:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_iteration_flow.py`
- explicit default config:
  - `tools/benchmarks/periodic_sub_trans/no_wli/runtime_defaults.py`
  - `tools/benchmarks/config/no_wli_pipeline_profiles.py`
- preset/cap forwarding:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
- next live compare lane:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`

What changed:

- legacy Stage-3 entry remains the default policy:
  - `entry_allocation_policy = "legacy_fixed_budget"`
- new explicit Study 1 policy added:
  - `entry_allocation_policy = "constant_local_depth"`
- the new policy uses:
  - explicit `entry_mutations_per_promoted`
  - round-robin family allocation after seeding each promoted family once
  - explicit cap reporting through:
    - `stage3_entry_base_budget`
    - `stage3_entry_target_before_cap`
    - `stage3_entry_cap`
    - `stage3_entry_cap_applied`
    - `stage3_entry_mutation_calls_per_promoted`
- fixture-matrix presets can now override:
  - `STAGE3_ENTRY_ALLOCATION_POLICY` via
    `force_stage3_entry_allocation_policy`
  - `STAGE3_ENTRY_MUTATIONS_PER_PROMOTED` via
    `force_stage3_entry_mutations_per_promoted`
  - real Kaeding solver fields via `force_solver_stage3_overrides`
  - `STAGE3_INIT_KEYS_CAP` via `force_stage3_init_keys_cap`

Prepared live compare:

- active matrix config now targets the first Study 1 live comparison:
  - seed:
    - `211`
  - presets:
    - `stage3_preserve_tieband_probe_p9`
    - `stage3_entry_const_local_depth_p9`
  - control files:
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v37_p9c3_seed211_stage3_entry_compare_2job.jsonl`
    - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`

Candidate semantics:

- preset:
  - `stage3_entry_const_local_depth_p9`
- key overrides in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
- intended behavior:
  - keep the same narrow preserved lane as control
  - keep `force_stage3_initial_keys = 64`
  - raise `force_stage3_init_keys_cap = 288`
  - set:
    - `entry_allocation_policy = "constant_local_depth"`
    - `entry_mutations_per_promoted = 1`
- interpretation:
  - on large promoted pools, aim to give each promoted family one explicit local
    mutation before truncation/cap, rather than letting the old fixed-budget
    math collapse the family set down toward the legacy target

Short validation:

- focused regression slice:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_seeding.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_periodic_sub_trans_runner_scorer_impl.py tests/tools/test_no_wli_resume_handoff_artifacts.py -q`
  - outcome:
    - `78 passed`
- config materialization check:
  - inline module load against `run_fixture_matrix`
  - result:
    - `job_count = 2`
    - `run_seeds = [211, 211]`
    - `preset_ids = ["stage3_preserve_tieband_probe_p9", "stage3_entry_const_local_depth_p9"]`
    - `run_state_path = output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`

Meaningful new test coverage:

- `tests/tools/test_no_wli_stage3_seeding.py`
  - legacy fixed-budget behavior stays stable
  - constant-local-depth scales target budget
  - cap application is explicit and auditable
- `tests/tools/test_no_wli_fixture_matrix_runtime.py`
  - active config materializes the intended Study 1 two-job lane
  - new preset forwards `force_stage3_init_keys_cap`
  - new preset forwards the explicit Stage-3 entry controls
  - direct `apply_job(...)` wiring updates:
    - `STAGE3_INIT_KEYS_CAP`
    - `STAGE3_ENTRY_ALLOCATION_POLICY`
    - `STAGE3_ENTRY_MUTATIONS_PER_PROMOTED`
    - without contaminating `SOLVER_STAGE3`
- `tests/tools/test_periodic_sub_trans_runner_scorer_impl.py`
  - stop-line diagnostics now assert:
    - `entry_policy=`
    - `entry_target_before_cap=`
    - `entry_mutation_calls_per_promoted=`

Conclusion:

- Study 1 is now implemented as an explicit, testable policy rather than an
  implicit tuning change
- baseline semantics remain available under the legacy mode
- the next long run should now be the prepared `seed211` control vs
  `stage3_entry_const_local_depth_p9` compare
- no live outcome is claimed yet; only implementation and short validation are
  complete

### 2026-03-27 Study 1 live run started and readout checklist prepared

Run-start evidence:

- state file:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`
  - current start snapshot:
    - `completed_jobs = 0`
    - `remaining_jobs = 2`
    - `started_utc = 2026-03-28T00:50:34.858013+00:00`
- event log:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v37_p9c3_seed211_stage3_entry_compare_2job.jsonl`
  - first event confirms:
    - job 1 preset = `stage3_preserve_tieband_probe_p9`
    - total jobs = `2`

Prepared post-run readout:

- `planning/working/no_wli_study1_readout_checklist_2026-03-27.md`

Purpose of the checklist:

- verify that the candidate really exercised:
  - `entry_allocation_policy = "constant_local_depth"`
  - `entry_mutations_per_promoted = 1`
  - `stage3_init_keys_cap = 288`
- verify whether the candidate actually widened:
  - `stage3_entry_target_before_cap`
  - `init3_n`
  - `stage2_to_stage3.stage3_init3_count`
- separate "policy executed" from "policy helped"

### 2026-03-27 Study 1 first launch exposed runtime-config boundary leak

Failure evidence:

- state file after first launch:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`
  - shows:
    - `completed_jobs = 0`
    - `remaining_jobs = 2`
    - `stopped_early = 1`
    - `last_error.error_type = "ValueError"`
    - `last_error.error = "Unknown kaeding parameter(s): entry_allocation_policy, entry_mutations_per_promoted ..."`
- event log:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v37_p9c3_seed211_stage3_entry_compare_2job.jsonl`
  - shows:
    - `job_started` for control preset
    - then `job_error` with the same unknown-parameter message

Interpretation:

- the new Study 1 keys were correctly introduced as Stage-3 entry controls
- but they were still leaking into the downstream Kaeding runtime solver config
- this is a boundary bug, not a negative scientific result
- no completed run from this first launch should be interpreted

Fix applied:

- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_seeding.py`
  - added explicit stripping of Stage-3 entry-only keys before emitting
    `solver_stage3_cfg` downstream
- Stage-3 entry metadata still remains separately observable via:
  - `stage3_entry_allocation_policy`
  - `stage3_entry_target_before_cap`
  - `stage3_entry_mutations_per_promoted_cfg`
  - `stage3_entry_mutation_calls_per_promoted`

Regression coverage added:

- `tests/tools/test_no_wli_stage3_seeding.py`
  - now asserts:
    - `entry_allocation_policy` is absent from emitted `solver_stage3_cfg`
    - `entry_mutations_per_promoted` is absent from emitted `solver_stage3_cfg`
    - the emitted `solver_stage3_cfg` is accepted by the real
      `SolverSpec.kaeding(...)` validator

Short validation after the fix:

- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_seeding.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_periodic_sub_trans_runner_scorer_impl.py -q`
  - outcome:
    - `68 passed`

Rerun note:

- rerunning the same matrix command is the expected next step
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_runtime.py`
  rebuilds the run-state header each session and only skips jobs listed in
  `completed_job_keys`
- since `completed_job_keys = []`, the Study 1 lane can be rerun without a code
  change to the state file path

### 2026-03-27 Study 1 second failed rerun clarified the real root cause and the canary now passes

Cross-checked failed rerun evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v37_p9c3_seed211_stage3_entry_compare_2job.json`
  - `completed_jobs = 0`
  - `remaining_jobs = 0`
  - `stopped_early = 0`
  - `completed_utc = 2026-03-28T00:57:26.311066+00:00`
  - `last_error.error_type = "ValueError"`
  - `last_error.error = "Unknown kaeding parameter(s): entry_allocation_policy, entry_mutations_per_promoted ..."`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v37_p9c3_seed211_stage3_entry_compare_2job.jsonl`
  - job 1 control preset `stage3_preserve_tieband_probe_p9` failed with the
    same unknown-parameter error
  - job 2 candidate preset `stage3_entry_const_local_depth_p9` failed with the
    same unknown-parameter error

Corrected root cause:

- the first fix was too narrow
- the Study 1 entry controls were incorrectly living inside the canonical
  `SOLVER_STAGE3` runtime config surface
- because of that, both the unchanged control path and the candidate path could
  still leak non-Kaeding keys into `SolverSpec.kaeding(...)`

Architectural fix completed:

- `tools/benchmarks/periodic_sub_trans/no_wli/runtime_defaults.py`
  - removed Study 1 entry controls from `DEFAULT_SOLVER_STAGE3`
  - added:
    - `DEFAULT_STAGE3_ENTRY_ALLOCATION_POLICY`
    - `DEFAULT_STAGE3_ENTRY_MUTATIONS_PER_PROMOTED`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_defaults.py`
  - added explicit runtime state:
    - `STAGE3_ENTRY_ALLOCATION_POLICY`
    - `STAGE3_ENTRY_MUTATIONS_PER_PROMOTED`
- `tools/benchmarks/periodic_sub_trans/no_wli/profile_defaults.py`
  - now splits Stage-3 entry controls out of profile `solver_stage3`
  - keeps `SOLVER_STAGE3` clean
- `tools/benchmarks/config/no_wli_pipeline_profiles.py`
  - removed Study 1 entry controls from the profile `solver_stage3` dict
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - extracts legacy Study 1 keys out of `force_solver_stage3_overrides`
  - forwards explicit entry-control overrides separately
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
  - applies the entry controls to explicit runtime state
  - keeps `SOLVER_STAGE3` restricted to real Kaeding fields
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`
  - now writes a separate `stage3.entry` block
- `tools/benchmarks/periodic_sub_trans/no_wli/run_lock_payload.py`
  - now writes a separate `stage3_search.entry` block
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_bridges.py`
  - passes Study 1 entry controls explicitly into Stage-3 prep
- `tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume.py`
  - resume/live Stage-3 prep now read the same explicit `entry` block

Meaningful canary added:

- `tests/tools/test_no_wli_stage3_entry_canary.py`
  - resolves the live Study 1 preset
  - applies it to a live-like no-WLI state
  - proves:
    - `SOLVER_STAGE3` stays clean
    - run config writes `stage3.entry`
    - non-scoring lock writes `stage3_search.entry`
    - Stage-3 prep bridge emits a clean `solver_stage3_cfg`
    - the emitted solver config is accepted by the real
      `SolverSpec.kaeding(...)` validator

Focused validation after the architectural fix:

- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_entry_canary.py tests/tools/test_no_wli_stage3_seeding.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_run_config_span_aux.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_periodic_sub_trans_runner_scorer_impl.py -q`
  - outcome:
    - `83 passed`

Updated interpretation:

- the failed Study 1 reruns remain invalid scientifically
- but the boundary bug is now fixed at the correct architectural level rather
  than patched only in one downstream payload
- the new canary is the short proof required before the next long rerun

Planning follow-up:

- next-stage implementation plan written in:
  - `planning/working/no_wli_next_phase_implementation_plan_2026-03-27.md`
- current planned order remains:
  1. close Study 1 readout
  2. implement isolated Study 3 Phase-C start balancing
  3. defer Study 2 Phase-B family preservation until after Study 3 readout

### 2026-03-28 Study 1 `seed211` live compare finished: policy executed, no solve gain

Completed runs:

- control preserve run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T013131043374Z__bench_solve_pipeline_no_wli__55b7159`
  - matrix event elapsed:
    - `12980.378674268723s`
- candidate constant-local-depth run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T050751414997Z__bench_solve_pipeline_no_wli__55b7159`
  - matrix event elapsed:
    - `13750.395778656006s`

Execution proof:

- control Stage-3 prep:
  - `resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/stage3_prep.json`
  - `stage3_entry_allocation_policy = "legacy_fixed_budget"`
  - `stage3_entry_base_budget = 64`
  - `stage3_entry_target_before_cap = 64`
  - `init3_n = 64`
- candidate Stage-3 prep:
  - `resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/stage3_prep.json`
  - `stage3_entry_allocation_policy = "constant_local_depth"`
  - `stage3_entry_base_budget = 64`
  - `stage3_entry_target_before_cap = 288`
  - `stage3_entry_cap = 288`
  - `init3_n = 288`

Live handoff counts:

- control manifest:
  - `stage2_promoted_from_topk_count = 144`
  - `stage3_init3_count = 64`
- candidate manifest:
  - `stage2_promoted_from_topk_count = 144`
  - `stage3_init3_count = 144`

So Study 1 did execute the intended widening:
- same promoted pool size
- materially larger Stage-3 target
- materially larger realized Stage-3 init set

Solve outcome:

- control:
  - `best_stage = "stage3_full_refine"`
  - `best_match_ratio = 0.574`
  - `stage3_match_ratio = 0.574`
- candidate:
  - `best_stage = "stage3_full_refine"`
  - `best_match_ratio = 0.574`
  - `stage3_match_ratio = 0.574`

Downstream comparison:

- both runs show:
  - `phaseB_selected_unique_end_hash = 8`
  - `phaseC_candidate_pool_unique_end_hash = 8`
  - `phaseC_start_keys_used = 6`
  - `phaseC_candidate_pool_source_counts = { stage3_best_phaseB: 1, phaseB_topk: 1, phaseA_selected: 8 }`
  - `phaseC_start_source_counts = { stage3_best_phaseB: 1, phaseA_selected: 5 }`

Interpretation:

- this is a valid negative result, not an execution failure
- constant local-depth Stage-3 entry widened upstream entry substantially on
  `211`
- but that widening alone did not improve solve quality or downstream family
  diversity metrics
- current best reading remains:
  - `211` looks more like a `good_family_absent` case than a simple
    entry-budget starvation case
- Study 1 should therefore be treated as:
  - successful implementation
  - successful execution proof
  - negative scientific result on this seed

### 2026-03-28 Study 3 implementation complete: isolated Phase-C start balancing

Implementation boundary:

- objective:
  - test whether downstream exploited variety improves if Phase-C start slots
    are balanced across surviving sources on `seed411`
- changed:
  - Phase-C `start_records` selection policy only
- explicitly unchanged:
  - Phase-C candidate-pool composition
  - Phase-B ranking and tie-band logic
  - rescue eligibility and rescue policy
  - Phase-B family-preservation policy

Code paths changed:

- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
  - new `stage3_phasec_start_policy` surface
  - new balanced source-order implementation:
    - `balanced_sources_v1`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_runtime_calls.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_bridges.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runtime_defaults.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_defaults.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/profile_defaults.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_lock_payload.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume.py`

Meaningful Study 3 canary and deterministic proof:

- `tests/tools/test_no_wli_phasec_start_policy_canary.py`
  - proves preset resolution, job application, run-config emission,
    non-scoring lock emission, and Stage-3 runtime-call bridge propagation of
    `STAGE3_PHASEC_START_POLICY`
- `tests/tools/test_no_wli_stage3_phasec.py`
  - deterministic synthetic test proves:
    - same Phase-C pool
    - same start budget
    - different start ordering under `balanced_sources_v1`

Focused short validation:

- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_phasec_start_policy_canary.py tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_run_config_span_aux.py tests/tools/test_no_wli_artifact_resume.py -q`
  - outcome:
    - `42 passed`
- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_entry_canary.py tests/tools/test_no_wli_phasec_start_policy_canary.py tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_run_config_span_aux.py tests/tools/test_no_wli_artifact_resume.py -q`
  - outcome:
    - `43 passed`

Config materialization cross-check:

- active matrix config now resolves exactly:
  - `job_count = 2`
  - `run_seeds = [411, 411]`
  - presets:
    - `stage3_preserve_tieband_probe_p9`
    - `stage3_phasec_start_balanced_p9`

User long-run handoff prepared:

- active compare target:
  - `seed411`
- control preset:
  - `stage3_preserve_tieband_probe_p9`
- candidate preset:
  - `stage3_phasec_start_balanced_p9`
- active matrix control files:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v38_p9c3_seed411_phasec_start_compare_2job.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v38_p9c3_seed411_phasec_start_compare_2job.jsonl`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v38_p9c3_seed411_phasec_start_compare_2job.json`

Current interpretation:

- Study 1 closed as a valid negative on `seed211`
- Study 3 is now isolated cleanly enough to test the downstream
  exploited-variety bottleneck on `seed411`
- if Study 3 is also negative, the next best move becomes more clearly:
  - upstream basin-generation work for `211`-like cases
  - then Phase-B family-preservation policy for `411`-like cases

### 2026-03-28 Study 3 `seed411` live compare finished: policy executed, no distinct new starts

Completed runs:

- control preserve run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T174120032623Z__bench_solve_pipeline_no_wli__55b7159`
  - matrix event elapsed:
    - `12561.021997451782s`
- candidate balanced-start run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T211041031812Z__bench_solve_pipeline_no_wli__55b7159`
  - matrix event elapsed:
    - `10083.177921056747s`

Isolation check:

- `git diff --no-index -- output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T174120032623Z__bench_solve_pipeline_no_wli__55b7159/run_config.json output/tools/benchmarks/periodic_sub_trans/no_wli/20260328T211041031812Z__bench_solve_pipeline_no_wli__55b7159/run_config.json`
  - meaningful semantic difference:
    - `stage3.two_phase.phase_c.start_policy`
      - control:
        - `source_order`
      - candidate:
        - `balanced_sources_v1`
  - other differences were expected lock hashes / normalized float formatting only

Execution proof:

- control run config:
  - `stage3.two_phase.phase_c.start_policy = "source_order"`
- candidate run config:
  - `stage3.two_phase.phase_c.start_policy = "balanced_sources_v1"`
- both runs emitted live handoffs:
  - `resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed411/manifest.json`
  - `stage2_to_stage3.source = "live_stage3_pipeline"`

Top-level solve outcome:

- control:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`
- candidate:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`

Phase-C pool vs starts:

- control Stage-3 summary:
  - `phaseC_candidate_pool_count = 10`
  - `phaseC_candidate_pool_unique_end_hash = 8`
  - `phaseC_candidate_pool_source_counts = { "stage3_best_phaseB": 1, "phaseB_topk": 1, "phaseA_selected": 8 }`
  - `phaseC_start_keys_used = 6`
  - `phaseC_start_unique_end_hash = 6`
  - `phaseC_start_source_counts = { "stage3_best_phaseB": 1, "phaseA_selected": 5 }`
- candidate Stage-3 summary:
  - `phaseC_candidate_pool_count = 10`
  - `phaseC_candidate_pool_unique_end_hash = 8`
  - `phaseC_candidate_pool_source_counts = { "stage3_best_phaseB": 1, "phaseB_topk": 1, "phaseA_selected": 8 }`
  - `phaseC_start_keys_used = 6`
  - `phaseC_start_unique_end_hash = 6`
  - `phaseC_start_source_counts = { "stage3_best_phaseB": 1, "phaseA_selected": 5 }`

Start-level checkpoint comparison:

- control:
  - `phasec_start_checkpoints.jsonl`
- candidate:
  - `phasec_start_checkpoints.jsonl`
- observed:
  - same six `candidate_hash` values in the same order
  - no `phaseB_topk` start in either run
  - both runs started:
    - anchor `stage3_best_phaseB`
    - then five `phaseA_selected` challengers

Interpretation:

- this is a valid negative result for the implemented Study 3 intervention
- the new Phase-C start policy executed correctly
- but it did not produce any new distinct Phase-C starts on `seed411`
- the strongest current reading is:
  - by the time Phase-C starts are chosen, the single carried `phaseB_topk`
    row is not contributing an additional distinct startable key beyond the
    anchor / `phaseA_selected` pool
- so Phase-C start balancing alone is not the marginal lever here

Programme effect:

- Study 3 should now be treated as:
  - successful implementation
  - successful execution proof
  - negative scientific result on this seed / current pool shape
- this shifts the next meaningful intervention downstream-but-earlier:
  - Phase-B family preservation / family-aware downstream slot retention
- next implementation brief:
  - `planning/working/no_wli_study2_phaseb_preservation_plan_2026-03-28.md`
- locked experiment specs:
  - `planning/working/no_wli_locked_experiment_specs_2026-03-28.md`

### 2026-03-28 Study 2 implementation ready: isolated Phase-B family preservation with robust canary

Locked implementation boundary:

- preserve more distinct families only in the downstream carry-forward path
- leave ordinary Phase-B ranking unchanged
- leave Phase-B run seeds unchanged
- leave Phase-C rescue logic unchanged

Implemented policy surface:

- `phaseb_family_preservation_policy = reserve_by_family_v1`
- `phaseb_family_view_id = prefix_hamming_le_24`
- `phaseb_family_reserved_slots = 2`

Implementation surfaces:

- shared family-view helper:
  - `tools/benchmarks/periodic_sub_trans/no_wli/family_views.py`
- audit helper now imports the shared family view definitions:
  - `tools/benchmarks/periodic_sub_trans/no_wli/audit_basin_family_diversity_alignment.py`
- runtime/config/bridge/plumbing:
  - `tools/benchmarks/periodic_sub_trans/no_wli/runtime_defaults.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_defaults.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/profile_defaults.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_runtime_calls.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/runner_bridges.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/run_lock_payload.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
- core downstream preservation logic:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`

New proof assets:

- deterministic policy test:
  - `tests/tools/test_no_wli_stage3_phasec.py`
    - proves the Study 2 policy changes downstream carry-forward composition
      while leaving ordinary Phase-B selected count unchanged
- dedicated Study 2 canary:
  - `tests/tools/test_no_wli_phaseb_family_preservation_canary.py`
    - proves preset resolution, live state, `run_config`, lock payload,
      runtime bridge, and resume parsing all carry the new Study 2 fields
- fixture runtime coverage:
  - `tests/tools/test_no_wli_fixture_matrix_runtime.py`
    - proves the active v39 compare materializes as the intended 2-job
      `seed411` control-vs-candidate lane

Short proof history:

- initial focused Study 2 slice surfaced two real correctness issues before
  any long run:
  - missing default imports in `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
  - synthetic deterministic test keys that were still transitively connected
    under the real `prefix_hamming_le_24` family view
- both were corrected before final proof was accepted

Focused proof slice after fixes:

- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - outcome:
    - `30 passed`

Broader meaningful confirmation slice:

- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_artifact_resume.py tests/tools/test_periodic_sub_trans_runner_scorer_impl.py -q`
  - outcome:
    - `95 passed`

Prepared live compare for the user:

- seed:
  - `411`
- control:
  - `stage3_preserve_tieband_probe_p9`
- candidate:
  - `stage3_phaseb_family_preserve_p9`
- active matrix control files:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v39_p9c3_seed411_phaseb_family_compare_2job.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v39_p9c3_seed411_phaseb_family_compare_2job.jsonl`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v39_p9c3_seed411_phaseb_family_compare_2job.json`

Interpretation lock before the long run:

- Study 1:
  - valid negative on `211`
- Study 3:
  - valid negative on `411`
- Study 2:
  - now isolated cleanly enough for the next meaningful `seed411` live compare

### 2026-03-29 Study 2 `seed411` live compare finished: visible outcome negative, persistence telemetry incomplete

Completed runs:

- control preserve run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260329T020350857797Z__bench_solve_pipeline_no_wli__55b7159`
  - matrix event elapsed:
    - `14454.284437179565s`
- candidate family-preserve run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260329T060445115113Z__bench_solve_pipeline_no_wli__55b7159`
  - matrix event elapsed:
    - `14831.120589017868s`

Validity checks that passed:

- matrix state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v39_p9c3_seed411_phaseb_family_compare_2job.json`
  - `completed_jobs = 2`
  - `stopped_early = 0`
- intended config delta present:
  - control `run_config.json`
    - `stage3.two_phase.family_preservation.policy = "off"`
    - `stage3.two_phase.family_preservation.family_view_id = "prefix_hamming_le_24"`
    - `stage3.two_phase.family_preservation.reserved_slots = 0`
  - candidate `run_config.json`
    - `stage3.two_phase.family_preservation.policy = "reserve_by_family_v1"`
    - `stage3.two_phase.family_preservation.family_view_id = "prefix_hamming_le_24"`
    - `stage3.two_phase.family_preservation.reserved_slots = 2`
- unchanged guard field:
  - both runs kept:
    - `stage3.two_phase.phase_c.start_policy = "source_order"`
- both runs emitted live handoffs:
  - `resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed411/manifest.json`
  - `stage2_to_stage3.source = "live_stage3_pipeline"`

Visible top-level outcome:

- control:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`
- candidate:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`

Visible downstream outcome:

- control:
  - `phaseB_selected_unique_end_hash = 8`
  - `phaseC_candidate_pool_unique_end_hash = 8`
  - `phaseC_candidate_pool_source_counts = { "stage3_best_phaseB": 1, "phaseB_topk": 1, "phaseA_selected": 8 }`
  - `phaseC_start_keys_used = 6`
  - `phaseC_start_unique_end_hash = 6`
  - `phaseC_start_source_counts = { "stage3_best_phaseB": 1, "phaseA_selected": 5 }`
- candidate:
  - `phaseB_selected_unique_end_hash = 8`
  - `phaseC_candidate_pool_unique_end_hash = 8`
  - `phaseC_candidate_pool_source_counts = { "stage3_best_phaseB": 1, "phaseB_topk": 1, "phaseA_selected": 8 }`
  - `phaseC_start_keys_used = 6`
  - `phaseC_start_unique_end_hash = 6`
  - `phaseC_start_source_counts = { "stage3_best_phaseB": 1, "phaseA_selected": 5 }`

Checkpoint comparison:

- control:
  - `phasec_start_checkpoints.jsonl`
- candidate:
  - `phasec_start_checkpoints.jsonl`
- observed:
  - same six `candidate_hash` values
  - same order
  - same sources:
    - anchor `stage3_best_phaseB`
    - then five `phaseA_selected` challengers

Important limitation:

- the new Study 2 family telemetry did not persist into the saved readout
  artifacts:
  - not present in `best/best_instance.json`
  - not present in `stages.json`
- missing persisted fields include:
  - `phaseB_family_count_in_top_band`
  - `phaseB_family_preserved_count`
  - `phaseB_family_reservation_applied`
  - `phaseB_downstream_selected_count`
  - `phaseB_downstream_selected_unique_end_hash`

Interpretation:

- the run is operationally negative on all visible downstream and solve outputs
- but it is not yet a fully locked scientific negative under the current
  standard, because the policy-specific preservation telemetry was not saved
- that means the exact question remains open:
  - did the policy truly have no downstream effect
  - or did it apply but later collapse back to the same observable Phase-C pool

Next action:

- do not move to a new science phase yet
- first fix persistence of the Study 2 family telemetry into the saved artifact
  path
- then rerun the same v39 `seed411` control-vs-candidate compare

### 2026-03-29 Study 2 persistence bug confirmed and fixed before rerun

Root cause:

- the Study 2 family-preservation fields were produced in:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_two_phase.py`
- but they were dropped before saved artifact emission because:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage3_iteration_flow.py`
    did not carry them into iteration state
  - `tools/benchmarks/periodic_sub_trans/no_wli/iteration_post_stage3.py`
    did not pass them into `build_stage3_diagnostics(...)`
  - `tools/benchmarks/periodic_sub_trans/no_wli/iteration_outcome.py`
    did not serialize them into `stage3_diagnostics`

Code changes:

- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_iteration_flow.py`
  - now propagates:
    - `phaseB_family_preservation_policy`
    - `phaseB_family_view_id`
    - `phaseB_family_reserved_slots`
    - `phaseB_family_count_in_top_band`
    - `phaseB_family_preserved_count`
    - `phaseB_family_reservation_applied`
    - `phaseB_downstream_selected_count`
    - `phaseB_downstream_selected_unique_end_hash`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_post_stage3.py`
  - now passes those fields into `build_stage3_diagnostics(...)`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_outcome.py`
  - now serializes those fields into `stage3_diagnostics`

New regression coverage:

- `tests/tools/test_no_wli_truth_diagnostics.py`
  - extended to prove the new Study 2 fields survive diagnostics building
- `tests/tools/test_no_wli_stage35_substitution_solver.py`
  - added a focused `stage3_iteration_flow` propagation test for the new
    Study 2 fields

Meaningful proof slice after fix:

- `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_truth_diagnostics.py tests/tools/test_no_wli_stage35_substitution_solver.py tests/tools/test_no_wli_stage3_phasec.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_artifact_resume.py -q`
  - outcome:
    - `56 passed`

Decision:

- the next run should be the same v39 Study 2 compare
- interpret the previous completed v39 run as invalid for final science
  lock, because the saved artifact path was incomplete

### 2026-03-29 Study 2 rerun re-armed on fresh control files

The first post-fix rerun attempt resumed immediately because the matrix still
pointed at the already-completed v39 control files.

Science configuration remains unchanged:

- seed:
  - `411`
- control preset:
  - `stage3_preserve_tieband_probe_p9`
- candidate preset:
  - `stage3_phaseb_family_preserve_p9`

Only the control-file paths were advanced to a fresh rerun set:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.jsonl`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.json`

Purpose:

- rerun the same Study 2 compare unchanged
- capture the newly persisted family-preservation telemetry
- only then decide whether Study 2 is a valid negative or not

### 2026-03-29 Study 2 rerun result: valid negative on seed 411

Completed rerun:

- control run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260329T155853670179Z__bench_solve_pipeline_no_wli__55b7159`
- candidate run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260329T204310438057Z__bench_solve_pipeline_no_wli__55b7159`
- matrix control files:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v40_p9c3_seed411_phaseb_family_compare_2job_rerun.jsonl`

Top-level result:

- control:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`
- candidate:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`

Persisted Study 2 telemetry recovered from:

- control:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260329T155853670179Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`
- candidate:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260329T204310438057Z__bench_solve_pipeline_no_wli__55b7159/best/best_instance.json`

Observed Study 2 telemetry:

- control:
  - `phaseB_family_preservation_policy = "off"`
  - `phaseB_family_view_id = "prefix_hamming_le_24"`
  - `phaseB_family_reserved_slots = 0`
  - `phaseB_family_count_in_top_band = 8`
  - `phaseB_family_preserved_count = 8`
  - `phaseB_family_reservation_applied = 0`
  - `phaseB_downstream_selected_count = 8`
  - `phaseB_downstream_selected_unique_end_hash = 8`
- candidate:
  - `phaseB_family_preservation_policy = "reserve_by_family_v1"`
  - `phaseB_family_view_id = "prefix_hamming_le_24"`
  - `phaseB_family_reserved_slots = 2`
  - `phaseB_family_count_in_top_band = 8`
  - `phaseB_family_preserved_count = 8`
  - `phaseB_family_reservation_applied = 1`
  - `phaseB_downstream_selected_count = 8`
  - `phaseB_downstream_selected_unique_end_hash = 8`

Visible downstream outcome remained unchanged:

- `phaseB_selected_unique_end_hash = 8`
- `phaseC_candidate_pool_unique_end_hash = 8`
- `phaseC_start_keys_used = 6`
- `phaseC_start_source_counts = { "stage3_best_phaseB": 1, "phaseA_selected": 5 }`
- `phasec_start_checkpoints.jsonl` was identical between runs

Interpretation:

- the Study 2 policy did execute
- it did not change the downstream selected set
- the cleanest reading is that Phase-B family reservation inside the current
  top-8 band is not the bottleneck on `seed411`
- the bottleneck is now more likely the width or valuation of the band that is
  being carried forward, not preservation inside that band

Next test prepared:

- v41 isolated Phase-B carry-forward-width probe
- control preset:
  - `stage3_preserve_tieband_probe_p9`
- candidate preset:
  - `stage3_phaseb_width_probe_p9`
- only intended semantic change:
  - `force_stage3_phaseb_top_n = 32`

### 2026-03-30 v41 width probe status: invalid due accelerator failure

The first width-probe long run did not produce a candidate science result.

Evidence:

- matrix state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v41_p9c3_seed411_phaseb_width_compare_2job.json`
- matrix events:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v41_p9c3_seed411_phaseb_width_compare_2job.jsonl`

Observed outcome:

- control job completed:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260330T034031451631Z__bench_solve_pipeline_no_wli__55b7159`
- candidate job started, then failed after about `58.9s` with:
  - `error_type = "AcceleratorError"`
  - `error = "CUDA error: unknown error"`
- partial candidate run dir:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260330T085228874213Z__bench_solve_pipeline_no_wli__55b7159`

Why this run is invalid for science:

- the candidate run never wrote any progress units
- `run_manifest.json` stayed at:
  - `run_status = "running"`
  - `done_units = 0`
  - `history_rows_written = 0`
- no `instances.json`, `stages.json`, or Phase-C checkpoints were produced

Follow-up sanity check:

- immediate CUDA smoke check succeeded on the same machine:
  - `cuda_available = True`
  - matrix multiply completed successfully

Current interpretation:

- treat v41 as an accelerator/runtime failure, not as a negative width result
- rerun the exact same width compare on fresh control files

Rerun re-armed:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.jsonl`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.json`

### 2026-03-30 hardening backlog recorded while v42 is running

A concrete pipeline-hardening backlog has been written while the v42 width
compare is in flight:

- `planning/working/no_wli_pipeline_hardening_backlog_2026-03-30.md`

Purpose:

- turn the recent reliability discussion into a concrete file-level plan
- separate science-blocking bug classes from lower-priority cleanup
- define the minimum canaries needed before future long compares

Main conclusions recorded there:

- the central config/state smell is real:
  - `run_fixture_matrix.py` still passes `globals()` into the matrix mainflow
  - `fixture_matrix_mainflow.py` still consumes a broad mutable `state` bag
  - `runner_state_defaults.py` still mirrors active values into many
    `_..._DEFAULT` shadow keys
- the recommended target is not one giant config object but several smaller
  typed layers:
  - matrix config
  - matrix control files
  - typed tuning presets
  - resolved run config
  - runner services
  - narrow stage-boundary payloads
- the highest-priority hardening phases are:
  - runtime preflight
  - matrix config spine
  - rerun hygiene
  - preset typing
  - stage-boundary payloads
  - diagnostics persistence unification

This is planning only; it does not change the currently running v42 science
configuration.

### 2026-03-30 first hardening slice implemented

The first concrete slice of the hardening backlog is now implemented.

Files changed:

- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_models.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_fixture_matrix.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_mainflow.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runtime_preflight.py`

What changed:

- fixture-matrix entry no longer passes `globals()` into mainflow
- matrix entry now goes through a typed `FixtureMatrixMainflowConfig`
- state/event/plan control files now derive from a single
  `EXPERIMENT_RUN_ID`
- experiment identity is now recorded in:
  - matrix-entry state
  - plan payload
  - run-state metadata
- a torch/CUDA runtime preflight boundary now exists and fails early if the
  smoke test itself fails

Evidence:

- focused proof:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_runtime_preflight.py tests/tools/test_no_wli_fixture_matrix_mainflow.py tests/tools/test_no_wli_fixture_matrix_runtime.py -q`
  - `25 passed`
- broader guard slice:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_fixture_matrix.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_fixture_matrix_mainflow.py tests/tools/test_no_wli_runtime_preflight.py -q`
  - `35 passed`

Important scope note:

- this is a completed hardening slice, not the full backlog
- it closes:
  - matrix-entry `globals()` usage
  - control-file derivation drift
  - missing experiment id metadata
  - absence of runtime preflight
- it does not yet close:
  - typed preset migration
  - resolved run-config object
  - diagnostics persistence unification

### 2026-03-30 v42 width probe closed as a valid negative with a useful structural signal

The v42 rerun completed cleanly and is scientifically valid.

Evidence:

- matrix state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.json`
- matrix events:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v42_p9c3_seed411_phaseb_width_compare_2job_rerun.jsonl`
- control run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260330T150529396668Z__bench_solve_pipeline_no_wli__55b7159`
- candidate run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260330T175546232525Z__bench_solve_pipeline_no_wli__55b7159`

Correctness/validity:

- `completed_jobs = 2`
- `stopped_early = 0`
- no `job_error` row
- intended config delta present:
  - control:
    - `run_config.json -> stage3.two_phase.phase_b_top_n = 8`
  - candidate:
    - `run_config.json -> stage3.two_phase.phase_b_top_n = 32`
- other late knobs stayed stable:
  - `phase_c.start_policy = "source_order"`
  - `family_preservation.policy = "off"`
  - `phase_c.start_keys = 6`

Top-level outcome:

- control:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`
- candidate:
  - `best_stage = "stage2_search"`
  - `best_match_ratio = 0.041`
  - `stage3_match_ratio = 0.039`

What changed materially:

- control `best/best_instance.json -> stage3_diagnostics`:
  - `phaseB_top_n_used = 8`
  - `phaseB_selected_unique_end_hash = 8`
  - `phaseB_downstream_selected_unique_end_hash = 8`
  - `phaseC_candidate_pool_count = 10`
  - `phaseC_candidate_pool_unique_end_hash = 8`
  - `phaseC_candidate_pool_source_counts = {"stage3_best_phaseB":1,"phaseB_topk":1,"phaseA_selected":8}`
- candidate `best/best_instance.json -> stage3_diagnostics`:
  - `phaseB_top_n_used = 32`
  - `phaseB_selected_unique_end_hash = 32`
  - `phaseB_downstream_selected_unique_end_hash = 32`
  - `phaseC_candidate_pool_count = 34`
  - `phaseC_candidate_pool_unique_end_hash = 32`
  - `phaseC_candidate_pool_source_counts = {"stage3_best_phaseB":1,"phaseB_topk":1,"phaseA_selected":32}`

What did not change:

- actual Phase-C starts were identical:
  - `phaseC_start_keys_used = 6`
  - `phaseC_start_unique_end_hash = 6`
  - `phaseC_start_source_counts = {"stage3_best_phaseB":1,"phaseA_selected":5}`
- `phasec_start_checkpoints.jsonl` had the same six `candidate_hash` values in
  the same order in both runs

Interpretation:

- widening the Phase-B carry-forward band from `8` to `32` clearly increased
  carried variety
- that extra variety still did not become exploited variety
- width alone is therefore not the marginal lever on `seed411`

Sharpened next-study reading:

- the bottleneck now appears later than simple band width and later than family
  reservation inside the top band
- but it is also sharper than the original Phase-C source-order hypothesis:
  the widened variety is mostly in `phaseA_selected`, not in a distinct
  `phaseB_topk` row that later balancing could trivially rescue
- the next science study, if resumed, should be about how starts are chosen
  within the widened downstream pool, especially inside the larger
  `phaseA_selected` carry-forward set

Practical consequence:

- this is not a reason to run another pure width compare
- current best use of the result is to fold it into the next exploitation study
  design while continuing pipeline hardening

### 2026-03-30 second hardening slice: preset typing and stale-rerun rejection

While carrying the valid v42 width result forward, the next pipeline-hardening
slice has also been implemented and proven.

What changed:

- typed `Stage3TuningPreset` normalization now exists at the fixture-matrix
  boundary
- unknown preset fields now fail at normalization time instead of being silently
  tolerated
- `run_fixture_matrix.py` now materializes normalized presets into mainflow
  state instead of passing raw preset dicts through
- rerun/run-state identity is now explicit:
  - `experiment_run_id`
  - `planned_job_count`
  - `planned_job_keys_signature`
  - `run_state_version = "v2"`
- stale run-state files are now rejected if:
  - the `experiment_run_id` does not match
  - the planned job-key signature does not match
  - identity fields are missing from an existing run-state file
- duplicate materialized job keys are now rejected before checkpoint execution

Evidence:

- code:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_models.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/run_fixture_matrix.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_runtime.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_mainflow.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan.py`
- proof tests:
  - `tests/tools/test_no_wli_fixture_matrix_hardening.py`
  - `tests/tools/test_no_wli_fixture_matrix_runtime.py`
  - `tests/tools/test_no_wli_fixture_matrix_mainflow.py`

Meaningful proof:

- focused:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_fixture_matrix_hardening.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_fixture_matrix_mainflow.py tests/tools/test_no_wli_fixture_matrix.py -q`
  - `38 passed`
- broader guard:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_fixture_matrix_hardening.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_fixture_matrix_mainflow.py tests/tools/test_no_wli_fixture_matrix.py tests/tools/test_no_wli_runtime_preflight.py tests/tools/test_no_wli_stage3_entry_canary.py tests/tools/test_no_wli_phasec_start_policy_canary.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py -q`
  - `45 passed`

Interpretation:

- this does not produce a new science result by itself
- it does materially improve trust in future long compares
- especially for the bug classes that have already wasted runs:
  - malformed preset/config payloads
  - accidental stale reruns
  - ambiguous control-file identity

### 2026-03-30 finalize-path persistence hardening

The next hardening slice is now in place on the artifact/instance finalize path.

What changed:

- one shared `IterationPersistencePayload` now builds the finalize-path
  reviewer-facing enrichment fields instead of `iteration_finalize.py`
  hand-threading them piecemeal
- this now centralizes:
  - truth diagnostics
  - word-ngram report payloads
  - Stage-3.5 archive/seed rows
  - Stage-3.5 summary flags/fields
  - target-key payload fields

Evidence:

- code:
  - `tools/benchmarks/periodic_sub_trans/no_wli/stage_iteration_payload.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/iteration_finalize.py`
- proof tests:
  - `tests/tools/test_no_wli_iteration_persistence_payload.py`
  - `tests/tools/test_no_wli_iteration_finalize_word_ngram.py`
  - `tests/tools/test_no_wli_truth_diagnostics.py`
  - `tests/tools/test_no_wli_run_completion.py`

Meaningful proof:

- focused:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_iteration_persistence_payload.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_truth_diagnostics.py tests/tools/test_no_wli_run_completion.py -q`
  - `7 passed`
- combined guard:
  - `C:\Python\Python311\python.exe -m pytest tests/tools/test_no_wli_fixture_matrix_hardening.py tests/tools/test_no_wli_fixture_matrix_runtime.py tests/tools/test_no_wli_fixture_matrix_mainflow.py tests/tools/test_no_wli_fixture_matrix.py tests/tools/test_no_wli_runtime_preflight.py tests/tools/test_no_wli_iteration_persistence_payload.py tests/tools/test_no_wli_iteration_finalize_word_ngram.py tests/tools/test_no_wli_truth_diagnostics.py tests/tools/test_no_wli_run_completion.py tests/tools/test_no_wli_stage3_entry_canary.py tests/tools/test_no_wli_phasec_start_policy_canary.py tests/tools/test_no_wli_phaseb_family_preservation_canary.py -q`
  - `52 passed`

Interpretation:

- this is another trust-improving hardening step, not a new science result
- it closes more of the exact bug class that previously made Study 2
  persistence scientifically incomplete on the first pass
