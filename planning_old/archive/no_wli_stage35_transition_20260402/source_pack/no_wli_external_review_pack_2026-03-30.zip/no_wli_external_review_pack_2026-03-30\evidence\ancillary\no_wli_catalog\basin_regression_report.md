# no_wli Basin Regression Report

## Conclusion

- Primary culprit: `inside_stage3_basin_generation`
- Rationale: Stage-2 candidate quality is effectively unchanged, but the regression appears immediately in the Stage-3 top-k family.

## Primary A/B

- Old reference: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e`
- Current proof branch: `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159`

| Metric | Old | Current | Delta |
| --- | ---: | ---: | ---: |
| stage2_topk_top5_mean_match | 0.096 | 0.096 | 0.000 |
| stage3_topk_top5_mean_match | 0.768 | 0.638 | -0.130 |
| final_best_match_ratio | 0.773 | 0.668 | -0.105 |
| stage3_phaseB_steps | 5200.000 | 3200.000 | -2000.000 |
| stage3_init_keys | 80.000 | 128.000 | 48.000 |

## Old Family Context

| Run | Best Match | Stage3 Top5 Mean | PhaseB Steps |
| --- | ---: | ---: | ---: |
| 20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e | 0.773 | 0.768 | 5200 |
| 20260315T001203236783Z__bench_solve_pipeline_no_wli__5961d3e | 0.765 | 0.755 | 2200 |
| 20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e | 0.761 | 0.755 | 2200 |

## Supporting Notes

- The primary old and current runs have effectively identical `stage2_topk` top-5 match quality.
- The regression first appears in `stage3_topk`, which points away from a pre-Stage-3 cause.
- The current branch also reduced Phase-B depth while increasing Stage-3 entry width and late add-ons.
- The invalid Stage-3.5 proof path remains important, but it does not explain the already-weaker `stage3_topk` family.

## Canonical Inputs

- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/run_config.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/run_config.json`
