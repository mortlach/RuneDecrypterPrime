# Pipeline Hardening Status

This note focuses on the hardening that materially affects whether long-run
results can be trusted.

## Why the hardening work mattered

The science studies increasingly looked like real negatives, but the pipeline
still had recurring reliability risks:

- config and services moving through large mutable state bags
- new study knobs appearing in more than one config surface
- telemetry existing in memory but not always in saved artifacts
- stale rerun control files causing accidental resume/skip behavior
- runtime failures invalidating a compare before evidence existed

The goal was not to fix every bug in the repo. It was to make the no-WLI
experiment loop dependable enough that a finished run could be classified
correctly.

## Hardening completed in this stage

### 1. Runtime preflight and early recording

Implemented:
- small runtime preflight before long fixture-matrix runs
- explicit recorded abort path on preflight failure

Main files:
- `tools/benchmarks/periodic_sub_trans/no_wli/runtime_preflight.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_fixture_matrix.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_mainflow.py`

Meaningful proof:
- focused slice: `25 passed`
- broader guard slice: `35 passed`

Why it matters:
- infrastructure failure becomes an explicit run class instead of a confusing
  late crash

### 2. Matrix-entry config spine hardening

Implemented:
- removed the `state=globals()` entry path
- introduced explicit matrix mainflow config/state builders
- added `MatrixControlFiles`
- derived control files from one `EXPERIMENT_RUN_ID`

Main files:
- `tools/benchmarks/periodic_sub_trans/no_wli/run_fixture_matrix.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_models.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_config.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_mainflow.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan.py`

Why it matters:
- one experiment id now defines the state/events/plan file set
- the matrix entry path is narrower and easier to reason about

### 3. Typed Stage-3 tuning presets

Implemented:
- typed `Stage3TuningPreset` normalization
- strict preset-key rejection
- normalized preset materialization before job creation

Main files:
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_models.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_fixture_matrix.py`

Meaningful proof:
- focused slice: `38 passed`
- broader guard slice: `45 passed`

Why it matters:
- a new study knob can no longer silently leak through as a loose dict field

### 4. Rerun hygiene and stale-state rejection

Implemented:
- duplicate planned job keys now fail early
- run-state identity now includes:
  - `experiment_run_id`
  - `planned_job_count`
  - `planned_job_keys_signature`
  - `run_state_version`
- stale state reuse now fails on identity mismatch instead of silently skipping

Main files:
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_runtime.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_mainflow.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan.py`
- `tests/tools/test_no_wli_fixture_matrix_hardening.py`

Why it matters:
- it directly addresses the accidental "resume: skipping pre-completed jobs"
  problem that kept recurring during science work

### 5. Finalize-path persistence unification

Implemented:
- one `IterationPersistencePayload` serializer for finalize-path persistence
- consistent mapping into:
  - `best/best_instance.json`
  - `final_instances/...json`
  - instance-row payloads

Main files:
- `tools/benchmarks/periodic_sub_trans/no_wli/stage_iteration_payload.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_finalize.py`

Meaningful proof:
- focused slice: `7 passed`
- combined guard slice: `52 passed`

Why it matters:
- this reduces the risk that telemetry exists in memory but disappears from the
  reviewer-facing artifacts

## What this hardening already changed in practice

The pipeline is still not perfect, but the experiment loop is now stronger in
ways that matter:

- long-run identities are clearer
- stale resume mistakes are harder to trigger
- study knobs are less likely to drift silently
- reviewer-facing artifact loss is less likely on finalize paths
- infrastructure failures are easier to separate from science negatives

That is why the later valid negatives in this pack are more trustworthy than
some of the earlier exploratory runs.

## Important hardening still open

The backlog is not finished. The biggest remaining items are:

### 1. Resolved runtime-config object

Still missing:
- one typed final config object that holds the fully merged runtime settings

Why it matters:
- live behavior and saved `run_config.json` still depend on more than one config
  surface

### 2. Broader stage-boundary payload typing

Still missing:
- wider use of explicit payload objects for:
  - pre-stage3
  - stage3 diagnostics
  - post-stage3 / commit transitions

Why it matters:
- broad mutable state bags still exist outside the hardened edges

### 3. Full persistence parity outside finalize paths

Still missing:
- complete unification for non-finalize persistence surfaces

Why it matters:
- some telemetry paths are still more manual than ideal

### 4. Runtime/environment stability

Still open:
- accelerator/runtime failures can still invalidate a long compare

Evidence:
- `evidence/invalid_or_incomplete_runs/fixture_matrix_run_state_tune_v41_p9c3_seed411_phaseb_width_compare_2job.json`
- `evidence/invalid_or_incomplete_runs/20260330T085228874213Z__bench_solve_pipeline_no_wli__55b7159`

Why it matters:
- this is an experiment-trust blocker even when the algorithmic hypothesis is
  good

## Bottom line

The hardening should be viewed as experiment-loop hardening, not broad cleanup.

It has already improved:
- trust in completed negatives
- trust in rerun identity
- trust in artifact persistence

But meaningful science progress still depends on finishing more of the config
and boundary hardening backlog.
