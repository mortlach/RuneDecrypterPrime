# no_wli Selector Ladder Audit

Generated: 2026-03-21T18:04:26.820222+00:00

## Scope

Frozen ladder:
- easy: `p5/c1`, `p5/c3`, `p7/c1`, `p7/c5`
- medium: `p9/c1`
- hard: `p9/c3`

This audit checks current live-visible Stage-3 ordering, not oracle-only reranking.

## Main findings

- Hard tier still shows some non-zero within-run selector regret, but it is small: `p9/c3` mean `stage3_topk` truth regret is 0.0007, with best-truth rank 1 only 82.5% of the time.
- Ranking imperfections are not unique to the hard family: `p9/c1` mean `stage3_topk` truth regret is 0.0034, which is larger than the hard-tier mean.
- Across-run full-score ordering is not globally inverted: `p9/c3` score/match correlation is 0.915 and `p9/c1` is 0.539, so Stage-3 ranking is imperfect but the larger regression still points to basin generation rather than a totally broken scorer.
- The hard-tier score signal is useful but not perfect: the best-score `p9/c3` run reaches match `0.765`, while the best-match run reaches `0.773`.
- Easy controls remain stable: all four easy ladder cases have top-k regret bounded at 0.0000 or below.

## Tier summary

| Tier | Artifacts | Cases | Best Match | Top-Is-Best Rate | Mean Topk Regret | Mean Topk Spearman | Final Score/Match Corr |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| easy | 4 | 4 | 1.000 | 1.000 | 0.0000 | 0.727 | 1.000 |
| medium | 9 | 1 | 0.557 | 0.444 | 0.0034 | -0.170 | 0.539 |
| hard | 63 | 1 | 0.773 | 0.825 | 0.0007 | 0.372 | 0.915 |

## Case summary

| Case | Tier | Artifacts | Best Match | Best Score | Best-Score Run Match | Mean Topk Regret | Max Topk Regret | Final Score/Match Corr |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fixture_fixture_001_p5_c1_l1000 | easy | 1 | 1.000 | 0.501111 | 1.000 | 0.0000 | 0.0000 | nan |
| fixture_fixture_001_p5_c3_l1000 | easy | 1 | 1.000 | 0.501111 | 1.000 | 0.0000 | 0.0000 | nan |
| fixture_fixture_001_p7_c1_l1000 | easy | 1 | 1.000 | 0.501111 | 1.000 | 0.0000 | 0.0000 | nan |
| fixture_fixture_001_p7_c5_l1000 | easy | 1 | 0.997 | 0.499538 | 0.997 | 0.0000 | 0.0000 | nan |
| fixture_fixture_001_p9_c1_l1000 | medium | 9 | 0.557 | 0.172383 | 0.557 | 0.0034 | 0.0110 | 0.539 |
| fixture_fixture_001_p9_c3_l1000 | hard | 63 | 0.773 | 0.345301 | 0.765 | 0.0007 | 0.0110 | 0.915 |

## Hard-tier note

- Worst observed `p9/c3` within-run regret in this ladder slice: `0.0110` at `output\tools\benchmarks\periodic_sub_trans\no_wli\20260312T020424363346Z__bench_solve_pipeline_no_wli__5961d3e\final_instances\fixture_fixture_001_p9_c3_l1000__text0__seed411.json`.
- That run still had `stage3_topk` best-truth rank `4` rather than 1.

