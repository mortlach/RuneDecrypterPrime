# no_wli Output Catalog

This folder is a local catalog for the canonical no-WLI output tree:

- source tree: `output/tools/benchmarks/periodic_sub_trans/no_wli`

It exists to make the results easier to browse and share without moving the original run directories around and breaking existing references.

## Important consolidation note

On 2026-03-21, the local tree was compared against the DJ-MINI mirror.

Result:

- the DJ-MINI `no_wli` output set was a strict subset of the local tree on this machine
- no remote-only `no_wli` run directories were found
- so no physical merge-from-network was needed for the `no_wli` benchmark outputs

## What is in this catalog

- `inventory_summary.json`
  - high-level counts and the DJ-MINI comparison note
- `solve_status_report.md`
  - current shared note on what the no-WLI `p9/c3` branch is doing, what is failing, and what should be investigated next
- `run_manifest.csv`
  - one row per canonical no-WLI run directory
- `special_analysis_manifest.csv`
  - replay and analysis folders such as:
    - `phasec_rescue_replay`
    - `phasec_slice_signal_analysis`
    - `stage35_substitution_replay`
    - `word_ngram_tiebreak_profile`
    - `legacy_import`
- `fixture_matrix_files.csv`
  - `fixture_matrix_run_state_*`, `fixture_matrix_run_events_*`, and `fixture_matrix_plan_*`
- `notable_artifacts.json`
  - quick pointers to the strongest runs and the best `p9/c3` artifacts

## How to read the original run directories

Canonical run directories use this shape:

- `TIMESTAMP__bench_solve_pipeline_no_wli__HASH/`

The most important files inside a run directory are:

- `run_config.json`
  - exact config used for that run
- `stages.json`
  - per-stage summaries
- `final_instances/*.json`
  - final artifact(s) for each fixture/text/seed
- `phasec_start_checkpoints.jsonl`
  - per-start late-stage checkpoints when Phase-C checkpointing was active

## How to read the fixture-matrix files

These are top-level files in the source tree, not inside a run dir:

- `fixture_matrix_run_state_*.json`
  - resumable run-state checkpoint
- `fixture_matrix_run_events_*.jsonl`
  - append-only event log for the matrix session
- `fixture_matrix_plan_*.json`
  - the planned job list and resolved preset structure

## How to read the analysis folders

- `phasec_rescue_replay/*`
  - offline rescue replay experiments and selector/guard sweeps
- `phasec_slice_signal_analysis/*`
  - slice-signal analysis outputs
- `stage35_substitution_replay/*`
  - offline Stage-3.5 replay/evaluation summaries
- `word_ngram_tiebreak_profile/*`
  - word-ngram tie-break experiments

## Regenerating this catalog

The manifest files in this folder are generated from the canonical source tree with:

- `tools/benchmarks/periodic_sub_trans/no_wli/build_output_catalog.py`

That script takes no CLI args and writes back into this folder.
