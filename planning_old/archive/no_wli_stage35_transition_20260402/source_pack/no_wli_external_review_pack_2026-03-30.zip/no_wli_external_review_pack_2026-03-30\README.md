# No-WLI External Review Pack

Date:
- 2026-03-30

Purpose:
- provide one self-contained review bundle for the current no-WLI periodic
  substitution + transposition work
- combine the current planning logs, locked review position, the four completed
  live studies, the key precursor compare, hardening status, and copied
  evidence files in one place

Recommended reading order:
1. `01_summary_for_reviewers.md`
2. `02_four_live_tests_and_results.md`
3. `03_pipeline_hardening_status.md`
4. `04_open_questions_and_blockers.md`
5. `05_evidence_index.md`

Current working position:
- the main problem is still best understood as a Stage-3 family-handling problem
- the strongest current seed split is:
  - `211`-like: mainly upstream reach / `good_family_absent`
  - `411`-like: mainly downstream exploitation / `good_family_undervalued`
- four live studies are now locked:
  - Study 1: valid negative on `211`
  - Study 3: valid negative on `411`
  - Study 2: valid negative on `411`
  - Phase-B width probe: valid negative on `411`, but with a strong
    carried-variety versus exploited-variety signal

What is in this pack:
- reviewer-facing summary documents at the pack root
- copied planning logs in `planning_logs/`
- copied fixture-matrix state/event/plan files in `evidence/matrix_controls/`
- copied run directories for the key compares in `evidence/run_dirs/`
- ancillary evidence in `evidence/ancillary/`
- a small appendix of invalid or incomplete runs in
  `evidence/invalid_or_incomplete_runs/`
- the previous review pack zip in `appendices/`

Scope note:
- this pack does not try to retell every bug that was fixed
- it does include the hardening work that materially affects whether long-run
  results are scientifically trustworthy
