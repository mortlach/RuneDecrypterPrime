# Open Questions And Blockers

## Main open scientific question

Why do different seeds on the same `p9/c3/l1000` fixture behave so differently?

The current working split is:

- `211`-like:
  - mainly upstream reach / `good_family_absent`
- `411`-like:
  - mainly downstream exploitation / `good_family_undervalued`

That split is useful, but it still leaves the deeper puzzle:

- what produces the sharp seed-to-seed divergence in the first place?

This pack does not solve that puzzle. It narrows it.

## What the current evidence says is probably not the main answer

The current locked negatives make several simple stories less convincing:

- not simple Stage-3 entry-budget starvation on `211`
- not Phase-C start ordering alone on `411`
- not family reservation within the current top-8 band on `411`
- not simple late-band width alone on `411`

That means the missing insight is more likely to be structural:

- upstream basin generation / reach
- late family valuation
- or the transition from carried diversity to actually exploited starts

## Strongest open downstream question on `411`

The width probe is the most important current downstream clue:

- carried variety widened from `8` to `32`
- exploited starts stayed at `6`

So the most urgent `411` question is:

- why does a much wider carried late-stage set still collapse to the same
  actual Phase-C starts?

Possible explanations still open:
- selection pressure earlier than the Phase-C start policy
- valuation/ranking mismatch inside the widened band
- effective duplication inside the widened carried set despite more nominal
  unique end hashes
- missing source-family information in the actual start-selection path

Best current downstream target:

- not generic source balancing
- not generic width alone
- but novel-start carry-through:
  - force at least one or two genuinely distinct non-anchor challengers from
    the widened late pool into the actual explored start set

## Strongest open upstream question on `211`

Study 1 weakened the simple entry-budget-starvation hypothesis.

So the most urgent `211` question is:

- why is the good family still not arriving, even when Stage-3 entry becomes
  materially wider?

Possible explanations still open:
- the right family is missing upstream
- the widened entry is still feeding the same wrong neighborhood
- the basin-generation objective is not surfacing the right family strongly
  enough before Stage-3 local search begins

## Remaining pipeline inadequacies that can still block progress

### 1. Config remains more distributed than it should be

Even after recent hardening:
- config still lives across multiple layers
- the final merged runtime config is not yet a single typed source of truth

Blocker risk:
- a future study can still behave one way in memory and another way in saved
  config if that boundary is not finished cleanly

### 2. Stage-boundary payloads are only partially hardened

Some hot boundaries are better now, but broad mutable state still exists in
other paths.

Blocker risk:
- future study telemetry may still need too much manual threading

### 3. Reviewer-facing artifact semantics are still not always obvious

Example:
- one-row saved top-k artifacts are not proof that only one meaningful
  contender existed, because Kaeding top-k telemetry only records new global
  raw-score bests

Blocker risk:
- reviewers can still overread some artifacts without the surrounding context

### 4. Runtime instability remains a real experimental risk

The v41 width probe failure is in this pack as a reminder that:
- infrastructure can still invalidate a long compare before useful evidence is
  written

Blocker risk:
- a good science lane can still be lost to runtime instability

## What meaningful progress probably requires next

Not another broad tuning sweep.

More likely:
- more hardening on the config spine and stage-boundary contracts
- then the next science move aimed at the carried-to-exploited transition on
  `411`
- and separately, a more upstream basin-generation intervention for `211`

In other words:
- the repo still needs hardening
- but the science side also needs a deeper search-strategy insight rather than
  another small late-stage tweak
