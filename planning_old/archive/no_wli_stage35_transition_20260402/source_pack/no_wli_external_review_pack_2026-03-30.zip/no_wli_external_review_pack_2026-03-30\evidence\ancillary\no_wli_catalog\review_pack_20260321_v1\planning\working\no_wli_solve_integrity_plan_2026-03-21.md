# no_wli Solve-Integrity Plan

Date: 2026-03-21
Status: Active working plan
Scope: `tools/benchmarks/periodic_sub_trans/no_wli`

## Purpose

This is the active plan for the no-WLI hard-solve programme.

It is deliberately **not** a broad repo tidy-up plan and **not** a new late-solver invention plan.
The immediate goal is to restore trustworthy learning by fixing proof integrity first and then identifying where the stronger old hard-case basin was lost.

This file should be treated as the working checklist for the branch and updated in place as phases complete.

## Current evidence snapshot

Canonical references:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/inventory_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/best_p9_c3_runs.csv`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/solve_status_report.md`

Key artifacts:

- old best hard-case run:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- latest bounded proof attempt:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/run_config.json`
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`

Evidence summary:

- best `p9/c3/l1000` run still `0.773`
- latest bounded proof `0.668`
- old `stage3_topk` cluster: `0.773, 0.770, 0.769, 0.767, 0.760`
- latest bounded proof `stage3_topk` cluster: `0.638, 0.638, 0.640, 0.640, 0.633`
- latest proof request had `stage3.stage35.enabled = true` in `run_config.json`
- latest proof final artifact still reported:
  - `stage35_enabled_cfg = 0`
  - `stage35_ran = 0`
  - `stage35_archive_count = 0`

Current interpretation:

1. The latest proof artifact is an **invalid Stage-3.5 proof**, not a meaningful Stage-3.5 result.
2. The larger solver blocker is **basin regression before final late refinement**, not general code mess.

## Scope and non-goals

### In scope

- proof-integrity hardening
- hard-case basin-regression analysis
- selector/scorer audit on a small real ladder
- one bounded recovery proof after the above gates

### Out of scope for now

- broad v1 repo tidy-up
- new solver invention before regression is understood
- broad run sweeps / wide matrices
- `p11` / `p13` as the main decision ladder

## Baseline ladder

This ladder is frozen for near-term evaluation.

### Easy controls

- `fixture_fixture_001_p5_c1_l1000`
- `fixture_fixture_001_p5_c3_l1000`
- `fixture_fixture_001_p7_c1_l1000`
- `fixture_fixture_001_p7_c5_l1000`

### Medium-ish control

- `fixture_fixture_001_p9_c1_l1000`

### Hard target

- `fixture_fixture_001_p9_c3_l1000`

Rule:
- no new major claim should be made without checking behaviour against this ladder

## Phase status board

- Phase 0: Freeze baseline ladder and active plan
  - Status: completed
- Phase 1: Proof-integrity hardening
  - Status: completed
- Phase 2: Basin-regression A/B analysis
  - Status: completed
- Phase 3: Selector/scorer audit on the real ladder
  - Status: completed
- Phase 4: One bounded recovery proof
  - Status: in_progress
- Phase 5: One clean bounded Stage-3.5 proof
  - Status: pending

## Phase 1: Proof-integrity hardening

### Goal

Prevent a requested Stage-3.5 proof from silently completing as a nominal result when Stage-3.5 did not actually run.

### Expected files

- `tools/benchmarks/periodic_sub_trans/no_wli/stage3_iteration_flow.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage35_substitution_solver.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_post_stage3.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_outcome.py`
- if needed:
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_api.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_jobs.py`
  - `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`

### Required behaviour

- Final outputs must distinguish:
  - Stage-3.5 requested
  - Stage-3.5 effectively enabled in the live path
  - Stage-3.5 ran
  - proof validity / invalid reason
- A proof with `stage35 requested = true` but `stage35_ran = 0` must be marked invalid and must not be treated as a normal proof result.

### Meaningful tests

- strengthen `tests/tools/test_no_wli_stage35_substitution_solver.py`
- strengthen `tests/tools/test_no_wli_fixture_matrix_runtime.py`
- add one integration-style proof-validity test if current coverage is not enough

Minimum assertions:

- requested Stage-3.5 cannot end with `ran = 0` and no invalid marker
- disabled Stage-3.5 stays cleanly disabled
- the specific `run_config enabled / final artifact ran=0` mismatch is reproducible as a regression test and then blocked

### Gate 1

No new proof run until:

- a requested Stage-3.5 proof cannot silently finish with `stage35_ran = 0`

### 2026-03-21 update

Gate 1 cleared.

Implemented:

- threaded `STAGE35_ENABLED` / `STAGE35_CFG` through the iteration-matrix and stage-engine bridge path
- added explicit proof markers:
  - `stage35_requested_cfg`
  - `stage35_proof_valid`
  - `stage35_proof_invalid_reason`
- exposed those markers in final Stage-3 diagnostics and top-level final outputs
- added a flow-level regression test for the old invalid shape:
  - requested Stage-3.5
  - `ran = 0`
  - explicit invalid-proof marker instead of silent nominal result

Validated with:

- `tests/tools/test_no_wli_iteration_matrix_fixed_seed_parity.py`
- `tests/tools/test_no_wli_truth_diagnostics.py`
- `tests/tools/test_no_wli_stage35_substitution_solver.py`
- `tests/tools/test_no_wli_fixture_matrix_runtime.py`
- `tests/tools/test_no_wli_stage_engine_iteration_bridge.py`
- `tests/tools/test_no_wli_run_completion.py`
- `tests/tools/test_no_wli_iteration_finalize_word_ngram.py`

Next action:

- Phase 2 basin-regression A/B analysis

## Phase 2: Basin-regression A/B analysis

### Goal

Find where the old stronger `p9/c3` basin is lost.

### Comparison set

Primary:

- `20260312T002501438386Z__bench_solve_pipeline_no_wli__5961d3e`
- `20260321T005721635958Z__bench_solve_pipeline_no_wli__55b7159`

Secondary:

- `20260315T001203236783Z__bench_solve_pipeline_no_wli__5961d3e`
- `20260315T215112716215Z__bench_solve_pipeline_no_wli__5961d3e`

### Inputs to compare

- `run_config.json`
- `stages.json`
- `final_instances/*.json`
- `phasec_start_checkpoints.jsonl` when present

### Questions to answer

- Did the regression happen before Stage 3?
- Did it happen inside Stage-3 basin generation?
- Did it happen at late handoff into refinement?

### Required deliverable

This phase must end with exactly:

- one primary culprit:
  - `pre_stage3_regression`
  - `inside_stage3_basin_generation`
  - `late_handoff_regression`
- optional secondary contributors ranked below it
- one short evidence table backing the ranking

This phase is not complete without naming one primary culprit.

### Meaningful tests

- deterministic artifact-parser tests for the March and March 21 comparison set
- stable comparison-summary tests if a helper is added

### Gate 2

No new late-solver design or proof run until:

- Phase 2 names one primary culprit with explicit evidence

### 2026-03-21 update

Gate 2 cleared.

Canonical outputs:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`

Primary culprit:

- `inside_stage3_basin_generation`

Ranked conclusion:

1. `inside_stage3_basin_generation`
2. no strong secondary contributor named yet

Short evidence table:

- `stage2_topk` top-5 mean match:
  - old `0.0958`
  - current `0.0958`
  - delta `0.0000`
- `stage3_topk` top-5 mean match:
  - old `0.7678`
  - current `0.6378`
  - delta `-0.1300`
- final best match:
  - old `0.773`
  - current `0.668`
  - delta `-0.105`

Interpretation:

- the regression is not primarily pre-Stage-3, because the Stage-2 top-k family is effectively unchanged
- the regression is not primarily late handoff, because the weaker family is already visible in `stage3_topk`
- the strongest evidence points to Stage-3 basin generation itself

Next action:

- Phase 3 selector/scorer audit on the frozen ladder

## Phase 3: Selector/scorer audit on the real ladder

### Goal

Check whether current live-visible ranking signals separate better and worse basins across easy, medium, and hard tiers.

### Likely code surface

- `tools/benchmarks/periodic_sub_trans/no_wli/replay_phasec_rescue_sweep.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/replay_stage35_substitution_solver.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/stage35_ranking.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/phasec_rescue_selector.py`

### Questions

- On easy solved controls, do current selectors preserve good outcomes?
- On `p9/c1`, do selectors separate stronger basins from weaker ones?
- On `p9/c3`, what selector regret remains on close candidates?
- Do current score/search-led signals actually rank the better basin above the worse basin?

### Meaningful tests

- deterministic replay summary tests on a fixed artifact subset
- stable ladder-audit output on the same inputs
- no-oracle safety remains covered

### Gate 3

No selector/ranking change should proceed unless it:

- does not break easy controls
- helps at least the medium/hard side of the ladder
- improves candidate choice, not just diagnostics

### 2026-03-21 update

Phase 3 audit completed.

Canonical outputs:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_report.md`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`

Key findings:

- easy controls remain stable with zero observed top-k truth regret
- `p9/c1` shows non-zero within-run selector regret:
  - mean `0.0034`
  - top-is-best rate `0.444`
- `p9/c3` also shows selector imperfection, but it is smaller than the Stage-3 basin drop:
  - mean top-k regret `0.0007`
  - top-is-best rate `0.825`
  - final score/match correlation across runs `0.915`

Interpretation:

- current score-led ranking is imperfect and not fully robust
- but the audit does not support “totally broken scorer” as the primary explanation
- the Phase 2 conclusion still stands:
  - the dominant regression is inside Stage-3 basin generation

Next action:

- Phase 4 bounded recovery proof setup using the older narrow Stage-3 regime that already reached the strong `0.761` family

## Phase 4: One bounded recovery proof

### 2026-03-21 update

Phase 4 setup is in progress.

Chosen recovery target:

- the Phase-C-enabled March 15 `0.761` family, not the newer wide/deep proof preset

Recovery preset shape:

- `init_keys = 64`
- `span_basin_judge.k / tie_max_seeds = 64`
- `phase_a.steps = 800`
- `phase_b.steps = 2200`
- `phase_b_top_n = 8`
- `gate_delta_floor = 0.003`
- `gate_end_gain_floor = 0.001`
- `phase_c.enabled = true`
- `phase_c.start_keys = 6`
- `phase_c.cfg.steps = 96`
- `stage35.enabled = false`

Reason:

- this older narrow Stage-3 regime already produced a strong hard-family run (`0.761`) with Phase-C enabled
- it is a cleaner recovery target than the newer wide/deep proof preset
- it keeps the next run focused on basin recovery rather than mixing in a fresh Stage-3.5 claim

Local validation added:

- fixture-matrix preset forwarding test for `stage3_recovery_p9_8h`
- recovery finalize-path smoke test using the real payload builder bridge

What this now guarantees before the live run:

- the active recovery preset reaches the runtime apply path with the intended narrow Stage-3 overrides
- the bounded recovery artifact path preserves:
  - Phase-C checkpoint markers
  - Stage-3 diagnostics
  - explicit Stage-3.5-disabled validity markers

### Goal

Recover the stronger hard-case basin before asking Stage-3.5 to prove anything.

### Run shape

- one bounded `p9/c3/l1000` run
- one seed
- one preset
- no matrix sweep

### Success bar

At least one of:

- final result materially above `0.668`
- `stage3_topk` family materially closer to the old `0.77x` cluster
- clear evidence that the regression point named in Phase 2 was actually fixed

### Gate 4

If the recovery proof still lands in the `0.63x / 0.64x` family, stop and reassess upstream search rather than piling on more late logic.

## Phase 5: One clean bounded Stage-3.5 proof

### Goal

Answer the real question:

- can live Stage-3.5 beat the stable Phase-C baseline on a credible `p9` run?

### Proof requirements

A valid proof must show:

- `run_config` requested Stage-3.5
- final artifact records Stage-3.5 as effectively enabled
- `stage35_ran = 1`
- `stage35_archive_count > 0`
- proof validity passes
- result is auditable against the preserved baseline

### Success bar

Strong:

- Stage-3.5 runs
- archive is non-empty
- proof is valid
- final result beats the recovered baseline

Weak but still useful:

- Stage-3.5 runs cleanly and produces a coherent archive even if it does not yet beat the recovered baseline

### Gate 5

Only after a clean `p9` proof should `p11` be considered.
`p13` remains out of scope until then.

## Required meaningful test set

These are the branch-anchor tests this plan expects:

1. proof-integrity integration test
   - requested Stage-3.5 cannot silently end as a nominal result with `ran = 0`
2. config-propagation regression test
   - proof preset reaches final artifact state correctly
3. basin comparison parser test
   - March and March 21 artifacts compare deterministically
4. selector/scorer ladder audit test
   - fixed artifact subset produces stable audit output
5. no-oracle Stage-3.5 safety test
   - live seed/ranking path remains truth-free
6. recovery-proof smoke test
   - bounded proof path emits expected late artifacts and validity markers

## Update protocol

When work progresses, update this file in place:

- change the phase status line
- add a dated note under the phase if a gate is cleared
- if a gate fails, record the failure explicitly rather than rewriting history

Do not replace this file with a fresh summary. Keep it as the running record.

## Current next action

Immediate next action:

- Phase 1 proof-integrity hardening

Nothing else should outrank that until Gate 1 is cleared.
