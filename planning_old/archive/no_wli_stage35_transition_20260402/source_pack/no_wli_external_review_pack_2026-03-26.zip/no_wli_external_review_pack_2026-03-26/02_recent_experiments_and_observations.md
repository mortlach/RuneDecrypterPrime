# Recent Experiments And Observations

This is a short evidence-backed timeline of the recent work most relevant to
outside review.

## 2026-03-21: recovered strong Stage-3 basin on the hard anchor

Question:

- can the stronger `p9/c3/l1000` family still be reached on the current branch?

Evidence:

- artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260321T190828084704Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- fields:
  - `best_match_ratio = 0.771`
  - `best_stage = "stage3_full_refine"`

What was learned:

- the project is not fundamentally unable to reach a strong hard-case basin
- a meaningful recovery baseline exists on the current branch

## 2026-03-22: clean Stage-3.5 proof on top of the recovered basin

Question:

- does Stage-3.5 add real value when Stage-3 is already strong?

Evidence:

- artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T001521766633Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed511.json`
- fields:
  - `best_match_ratio = 0.794`
  - `best_stage = "stage35_substitution_only"`
  - `stage35_ran = 1`
  - `stage35_proof_valid = 1`
  - `stage35_selected = 1`

What was learned:

- Stage-3.5 can help when the upstream basin is already strong
- this is a capability proof, not a reliability proof across seeds

## 2026-03-22: weak-seed Stage-3.5 did not generalize

Question:

- does the same general Stage-3.5 idea rescue a weak `seed211` case?

Evidence:

- artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260322T192204224097Z__bench_solve_pipeline_no_wli__55b7159/final_instances/fixture_fixture_001_p9_c3_l1000__text0__seed211.json`
- fields:
  - `best_match_ratio = 0.574`
  - `best_stage = "stage3_full_refine"`

What was learned:

- the strong `seed511` proof did not imply cross-seed robustness
- weak seeds remained the real problem

## 2026-03-21 catalog diagnosis: regression is mainly inside Stage-3 basin generation

Question:

- where was the older stronger family lost?

Evidence:

- artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- fields:
  - `primary_culprit = "inside_stage3_basin_generation"`
  - `stage2_topk_top5_mean_match`: old `0.0958`, new `0.0958`
  - `stage3_topk_top5_mean_match`: old `0.7678`, new `0.6378`

What was learned:

- the strongest current diagnosis still points to Stage-3 basin generation
- this makes pure downstream rescue less likely to be the main fix

## 2026-03-21 to 2026-03-23 catalog diagnosis: late signals are informative, early ones are weak

Question:

- are the scorers/rankers totally broken, or mainly weak before Stage 3?

Evidence:

- artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- findings include:
  - hard-tier `p9/c3` final score/match correlation `0.9149015639353775`
  - hard-tier mean top-k truth regret `0.0007142857142857149`
- artifact:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`
- findings include:
  - `score_stage2` run-max/final-match correlation `0.26520435915928153`
  - `stage3_topk` `score_judge` run-max/final-match correlation `0.8800871518964658`
  - conclusion:
    - early signals are weak
    - Stage-3 top-k and later signals become informative

What was learned:

- the system does have useful discrimination once it reaches a useful family
- the weak point is earlier basin reach, not obviously a totally broken late scorer

## 2026-03-25: live pipeline hardening after repeated commit/handoff crashes

Question:

- was the live handoff failure just one isolated missing key, or a broader state-contract bug?

Evidence:

- review doc:
  - `planning/working/no_wli_pipeline_hardening_review_2026-03-25.md`
- observed failures summarized there:
  - live rerun crashed with `KeyError: 'base'`
  - later rerun crashed with `KeyError: 'write_json'`

What was learned:

- the real issue was a broad mutable state contract at the commit / handoff
  boundary
- reliability work needed to be structural, not just another small patch

## 2026-03-26: live handoff-emission canary passed

Question:

- after the hardening work, does a live run finish cleanly and emit the live
  Stage-2 to Stage-3 handoff bundle?

Evidence:

- run directory:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159`
- manifest:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/resume_handoffs/fixture_fixture_001_p9_c3_l1000__text0__seed211/manifest.json`
  - field:
    - `stage2_to_stage3.source = "live_stage3_pipeline"`
- result:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T012915418495Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`

What was learned:

- live handoff emission is fixed on a real path
- solve quality still did not improve

## 2026-03-25 fixed-handoff seed411 ranking probe: small lexical changes were negative

Question:

- can small lexical gate and tie-window changes rescue the saved weak `seed411`
  downstream state?

Evidence:

- report:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- summary:
  - `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/summary.json`
- result:
  - every variant `resume_best_match_ratio = 0.032`
  - `best_truth_match = 0.099`
  - `between_family_truth_gap = 0.067`

What was learned:

- small lexical gating changes were not enough
- the next `seed411` test should be materially broader

## 2026-03-26 overnight weak-seed live matrix: too broad, too slow, still negative on seed211

Question:

- should broad live matrices be the main learning loop right now?

Evidence:

- run state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v35_p9c3_weakseed_overnight_10h.json`
  - fields:
    - `completed_jobs = 3`
    - `remaining_jobs = 7`
    - `stopped_early = 1`
- event log:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v35_p9c3_weakseed_overnight_10h.jsonl`
  - elapsed times:
    - job 1 preserve `13193.243979...`
    - job 2 recovery `11181.895447...`
    - job 3 Stage-3.5 proof `51995.484903...`
- all three completed `seed211` jobs stayed at `best_match_ratio = 0.574`

What was learned:

- broad live matrices were too slow for fast iteration
- the first three jobs were already enough to show no `seed211` improvement
- Stage-3.5 should not be the default short-cycle lane

## 2026-03-26 / 2026-03-27 active v36 run: short seed411 control vs broader rescue

Question:

- on live `seed411`, does a materially broader Phase-C rescue package beat the
  preserved control?

Evidence:

- plan:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`
- jobs:
  - job 1:
    - `stage3_preserve_tieband_probe_p9`
  - job 2:
    - `lexical_phasec_rescue_wide_finish`
- state:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_state_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - current fields:
    - `completed_jobs = 0`
    - `remaining_jobs = 2`
- event log:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_run_events_tune_v36_p9c3_seed411_phasec_compare_2job.jsonl`
  - current event:
    - job 1 started on `seed411`

What this run is meant to decide:

- if the broader candidate loses or ties the control:
  - deprioritize downstream ranking/rescue
  - move more attention upstream
- if it wins materially:
  - keep seed411 downstream rescue in play
