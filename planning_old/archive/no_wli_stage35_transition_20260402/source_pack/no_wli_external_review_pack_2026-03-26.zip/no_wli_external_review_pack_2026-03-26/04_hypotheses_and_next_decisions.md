# Hypotheses And Next Decisions

## Current working diagnosis

The strongest current diagnosis remains:

- the main regression is inside Stage-3 basin generation
- late signals are useful once a good family is reached
- weak seeds are still not reaching comparable basins often enough

Primary evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/basin_regression_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/selector_ladder_audit_summary.json`
- `output/tools/benchmarks/periodic_sub_trans/no_wli_catalog/partial_state_signal_audit_summary.json`

## What recent negative results already rule out

### On seed211

Recent live evidence already weakens these ideas:

- preserve-only lift
- recovery preset as currently configured
- Stage-3.5 as a default short-cycle lane

Evidence:

- preserve lane:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T054251138284Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`
- recovery lane:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T092244385214Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`
- Stage-3.5 proof lane:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/20260326T122906196863Z__bench_solve_pipeline_no_wli__55b7159/instances.json`
  - `best_match_ratio = 0.574`

### On seed411

The fixed-handoff ranking probe already weakens:

- tiny lexical-gate or tie-window relaxations as the main answer

Evidence:

- `tools/benchmarks/periodic_sub_trans/no_wli/output/tools/benchmarks/periodic_sub_trans/no_wli/artifact_resume/20260325T145319Z_seed411_phasec_ranking_probe/report.md`
- all variants ended at `Resume Match 0.032`

## Why the current v36 run is meaningful

The active run is deliberately narrow:

- control:
  - `stage3_preserve_tieband_probe_p9`
- candidate:
  - `lexical_phasec_rescue_wide_finish`
- seed:
  - `411`

Evidence:

- `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`

The candidate is meaningfully broader than the failed small-gate probe because
it changes several downstream search dimensions at once:

- `force_stage3_initial_keys = 128`
- `force_stage3_phaseb_top_n = 32`
- Phase-C rescue enabled
- broader rescue candidate pool
- longer rescue polish budget

Evidence:

- preset definition in:
  - `output/tools/benchmarks/periodic_sub_trans/no_wli/fixture_matrix_plan_tune_v36_p9c3_seed411_phasec_compare_2job.json`
  - preset:
    - `lexical_phasec_rescue_wide_finish`

## Decision tree after the current v36 run

### If the broader seed411 candidate beats the preserved control materially

Interpretation:

- downstream rescue/ranking is still alive as a path for weak `seed411`
- the next step should still stay narrow:
  - rerun the winning idea once more on `seed411`
  - then test whether the same idea helps `seed211`

Recommended next move:

- do not jump back to broad 10-job matrices
- run one confirmation and one cross-seed check

### If the broader seed411 candidate ties or loses

Interpretation:

- another downstream-rescue expansion failed
- that does not prove downstream work is useless forever, but it makes it less
  likely to be the next best lever

Recommended next move:

- deprioritize more downstream lexical rescue variants
- move attention back upstream:
  - Stage-3 basin generation
  - Stage-3 candidate diversity
  - earlier signal / reach improvements

## The stronger strategic question for reviewers

The central external-review question is not:

- "which small tuning preset should we try next?"

It is:

- "given the current evidence, are we still looking in the right part of the
  system?"

The evidence currently favors this answer:

- the project should spend more decision energy on upstream basin reach than on
  adding more downstream ranking layers

That is not a certainty.
It is the current best-supported working diagnosis.

## What should probably not happen next

Based on the recent evidence, these would be low-confidence next steps:

- another broad overnight matrix with many weak-seed presets
- making Stage-3.5 a default live comparison lane
- another tiny lexical-threshold tweak on fixed `seed411`
- declaring general pipeline reliability from one successful canary

## What seems highest leverage after the current v36 run

If the review agrees with the current diagnosis, the highest-value next work is
likely one of:

- upstream Stage-3 basin recovery / reach work
- stronger early-to-mid discriminative signals
- seed-diversity / candidate-diversity improvements in Stage 3
- better benchmark design for weak-seed learning loops

This is also broadly aligned with the earlier strategic review in:

- `appendix_deep_research_report.md`
- `deep_research_pack_snapshot/`
