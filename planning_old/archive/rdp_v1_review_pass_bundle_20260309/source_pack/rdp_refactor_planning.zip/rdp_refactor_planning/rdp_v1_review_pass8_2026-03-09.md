# RDP v1 review pass 8 — local code bundle deep pass

Date: 2026-03-09

## Scope used in this pass

Used the user-provided local bundle rather than partial web fetches.

Bundle summary:
- included files: 633
- roots covered: `src`, `tests`, `tools/benchmarks`
- included benchmark subdirs: `community`, `periodic_sub_trans`, `scoring`

Important limitation:
- static review is now much easier
- local end-to-end pytest is still incomplete because the bundle excludes some data modules imported by test startup (for example `rune_decrypter_prime.data`)

## Stronger findings from this pass

### 1) Word-ngram report path still depends on mutable scorer state

`tools/benchmarks/periodic_sub_trans/no_wli/word_ngram_report.py`

`score_word_ngram_report_for_plaintext(...)`:
- calls `score_plaintexts_chunked(...)`
- ignores the returned `_stats`
- then re-reads `scorer_runtime.last_stats()`
- builds the payload from that mutable state

This is workable for single-candidate use, but it is not the cleanest report contract.

Why it matters:
- report correctness depends on scorer-side mutable state rather than the direct scoring return value
- future batching / reuse changes could silently break report fidelity

### 2) The current tests explicitly lock that mutable-state pattern

`tests/tools/test_no_wli_word_ngram_report.py`

There is a test named `test_score_word_ngram_report_for_plaintext_uses_last_stats`.
That means the current behaviour is not accidental; it is part of the tested contract today.

Implication:
- fixing this later is possible, but it is a deliberate contract change and needs a test rewrite, not just an implementation tidy-up

### 3) Default word-ngram report enablement is still implicit and mtime-driven

`tools/benchmarks/periodic_sub_trans/no_wli/runner_defaults.py`

Defaults still:
- auto-discover candidate SQLite assets from several locations
- choose the newest file by modification time
- enable `WORD_NGRAM_REPORT_ENABLED` automatically when a candidate is found

This is convenient for development, but poor for a release-facing benchmark default.

Why it matters:
- two working copies can get different default behaviour without an explicit config change
- this weakens reproducibility and makes benchmark interpretation harder

### 4) Run-config persistence still writes twice

`tools/benchmarks/periodic_sub_trans/no_wli/run_config_io.py`

`persist_run_config_with_locks(...)` writes `run_config.json`, computes lock hashes, mutates the payload, then writes the same file again.

Why it matters:
- there is a partial-write window
- the file hash is of the second write only
- this is a brittle pattern for a release-facing benchmark artefact

### 5) Base scorer contract is still transitional

`src/rune_decrypter_prime/scoring/base_scorer.py`

This file still mixes:
- legacy string-objective parsing helpers
- newer enum / `ObjectiveSpec` expectations
- two `telemetry()` definitions in the same class body

Judgement:
- not a release blocker on its own
- but it is evidence that the scoring contract has not yet fully converged to one shape

### 6) `scorer_report` is real, but evidence is still smoke-level on the benchmark side

`src/rune_decrypter_prime/scoring/scorer_report.py`
`src/rune_decrypter_prime/scoring/scorer_report_builder.py`
`tests/tools/test_benchmark_scorer_report_sidecar_smoke.py`

Good news:
- the typed report object is real
- it has JSON-safe coercion and finite-float checks
- the builder pulls telemetry and last-stats into a structured report
- there is a benchmark-side smoke test for the Gate-0 preflight sidecar path

Remaining concern:
- I still do not have strong end-to-end evidence from this bundle that the main no-WLI runtime path uses one canonical scorer-report contract throughout
- current evidence is stronger for helper-level correctness than for benchmark-wide integration

## Current v1 ranking after this pass

### Must-fix
1. explicit run-dir ownership instead of before/after directory diffing
2. single-write run-config persistence
3. remove mtime-driven default asset selection for release benchmarks

### Should-fix
1. give word-ngram report its own narrow report contract instead of relying on `last_stats()` state
2. decide whether `scorer_report` is the canonical benchmark report payload and use it consistently
3. converge scoring contract around one objective representation internally
4. unify JSON / JSONL / hashing / path-redaction output policy

### Later
1. larger repo-shape tidy
2. no-WLI keep/merge/delete refactor once behaviour is locked

## What I still need for stronger runtime confidence

One of these would help:
- the matching `src/rune_decrypter_prime/data/...` surface
- or a fuller repo zip that includes the data package and any required small assets for the targeted tests
- or a known-good minimal test slice that is intended to run from the no-bloat bundle alone

Without that, I can keep doing a serious static engineering review, but runtime verdicts remain partial.
