# RDP v1 code review — pass 25 — internal policy enforcement and anti-drift rules

Date: 2026-03-09
Scope: local static review from `src_test_bench_nobloat__20260309T161023Z.zip`
Focus: internal engineering policies that should be explicit and enforceable, so the codebase does not drift back into local habits.

---

## Restated aim

This pass is about the **rules behind the architecture**, not just local bugs.

The question is: where does the repo already have good anti-drift policies, where are those policies only half-enforced, and what policy shape would best support v1 hardening?

In plain English: if we want rules like “core uses enums, not magic strings”, “boundary layers may be forgiving but core is strict”, and “all file output goes through one owner”, where is that already true and where is it still only aspirational?

---

## High-level judgement

The repo already has the beginnings of the right policy model, but it is **uneven**.

The pattern I now see is:

- **core** is trying to be strict
- **API boundary** is intentionally forgiving
- **benchmark/tools** often slip back into stringly local conventions
- some policy tests are real and helpful
- some policy tests exist only as half-enforced intent

So the problem is not that RDP has no policy discipline.
The problem is that **the policy tiers are not yet explicit enough, and not enforced consistently enough, across all layers**.

---

## What is already good

### 1. Core enum discipline is real

`src/rune_decrypter_prime/core/types.py` is clearly trying to be the strict centre for:
- `Direction`
- `Device`
- `ScorerImpl`
- `ScorerName`
- `SolverName`
- `CipherKind`
- `KeyKind`
- `KeyOpsFamily`

It also states the intended rule directly in comments, for example:
- “Core uses this Enum only”
- “Avoid magic strings in engine/cipher builders”

That is exactly the sort of explicit policy statement the codebase needs.

Evidence:
- `src/rune_decrypter_prime/core/types.py`

### 2. Some guardrail tests are doing the right job

There are several good anti-drift guardrails already in place, for example:
- `tests/guardrails/test_core_no_magic_direction_tokens.py`
- `tests/guardrails/test_core_no_raw_ltr_rtl_literals.py`
- `tests/guardrails/test_core_no_backend_optimizer_magic_literals.py`
- `tests/guardrails/test_engine_no_legacy_default_direction.py`

These are not merely behaviour tests. They are **policy tests**, which is exactly what v1 needs more of.

Evidence:
- `tests/guardrails/test_core_no_magic_direction_tokens.py`
- `tests/guardrails/test_core_no_raw_ltr_rtl_literals.py`
- `tests/guardrails/test_core_no_backend_optimizer_magic_literals.py`
- `tests/guardrails/test_engine_no_legacy_default_direction.py`

### 3. The API edge already recognises the right split

`tests/api_contract/test_normalize_direction_accepts_enum_and_string.py` makes the policy explicit:
- API accepts strings or enums
- core should only see canonical enums

That is a sound layered rule.

Evidence:
- `tests/api_contract/test_normalize_direction_accepts_enum_and_string.py`
- `src/rune_decrypter_prime/api/normalize.py`

---

## Where the policy picture is still weak or inconsistent

### 1. Strict core policy is real, but core config is still not fully strict

`src/rune_decrypter_prime/core/config/run.py` still exposes mixed unions like:
- `scorer_name: ScorerName | str`
- `optimizer_name: Optional[SolverName | str]`

and then normalises them in `__post_init__`.

That is understandable during migration, but it means the “core is enums only” policy is not yet fully true in the config layer.

The same pattern appears in `src/rune_decrypter_prime/core/config/solver.py`, where `SolverConfig` still accepts `SolverName | str` and preserves a legacy `.name` string view.

So the current state is not “strict core only”.
It is closer to: **strict-ish core with compatibility mixed into core config objects**.

Evidence:
- `src/rune_decrypter_prime/core/config/run.py`
- `src/rune_decrypter_prime/core/config/solver.py`

### 2. The scoring config is becoming a policy sink

`src/rune_decrypter_prime/core/config/scoring.py` is carrying a lot of benchmark-local or experiment-local intent as plain strings, for example:
- `smoothing: str`
- `oov_policy: str`
- `hamming_direction_mode: str`
- `span_hamming_mode: str`
- `span_hamming_bucket_policy: str`
- `span_hamming_combine_mode: str`
- `span_hamming_gate_fail_policy: str`
- `span_hamming_lm_profile_source: str`

Some of that may be acceptable if it is a serialisation boundary, but right now it is inside the main scoring config dataclass.

That means policy is drifting from:
- “strict typed core, forgiving boundary”

towards:
- “typed around the edges, but still many raw tokens in the middle”.

This is one of the main reasons the scoring side now feels harder to reason about than it should.

Evidence:
- `src/rune_decrypter_prime/core/config/scoring.py`

### 3. Benchmark/tooling code is still very string-and-dict heavy

The benchmark side has made some progress. For example:
- `tools/benchmarks/periodic_sub_trans/common/core_enums.py` defines enums like `BenchmarkOrder`, `PipelineRunMode`, `InstanceStatus`, `InstanceStopReason`

But that discipline is not used consistently.

Examples:
- `tools/benchmarks/periodic_sub_trans/no_wli/order_dispatch.py` normalises raw strings and returns string payloads
- `tools/benchmarks/periodic_sub_trans/no_wli/scoring_experiment_config.py` uses many raw profile names and option strings such as `"a_baseline"`, `"b_min"`, `"c_min_late"`, `"off"`, `"char_only"`, `"score_floor"`
- stage configuration is still built as copied dicts rather than a clearer typed role spec

So benchmark code is currently in a mixed state:
- it has some local enums
- but much of the real behaviour is still controlled by raw string tokens and ad hoc dict payloads

Evidence:
- `tools/benchmarks/periodic_sub_trans/common/core_enums.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/order_dispatch.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/scoring_experiment_config.py`

### 4. One policy test is present but not actually enforced

`tests/guardrails/test_only_scoring_can_say_fwd_rev.py` is especially revealing.

The file explains the intended rule in its docstring:
- legacy `fwd` / `rev` tokens should be isolated to the scoring boundary only

But the actual assertion is commented out.

That makes this a good example of a broader issue:
**some policy rules exist socially or aspirationally, but are not yet enforced as live constraints**.

Evidence:
- `tests/guardrails/test_only_scoring_can_say_fwd_rev.py`

### 5. Run and campaign layers still rely heavily on local dict conventions

`src/rune_decrypter_prime/api/run.py` still takes several dict-like configuration surfaces and passes them through normalisers into runtime config objects.

The community and benchmark layers then add further dict-based conventions on top of that.

This is one of the clearest reasons a first-class config runner now makes sense: it would let you define the policy once, instead of letting multiple layers each invent their own quasi-schema.

Evidence:
- `src/rune_decrypter_prime/api/run.py`
- `src/rune_decrypter_prime/api/normalize.py`
- `tools/benchmarks/community/_run_single_job.py`
- `tools/benchmarks/community/shard_manifest.py`

---

## Policy shape I now recommend for v1

I think the cleanest anti-drift policy model is a **four-tier rule set**.

### Tier 1: Core runtime

Rule:
- enums, typed dataclasses, and explicit objects only
- no raw control strings except enum values used during serialisation
- no compatibility aliases
- no benchmark-local intent

Applies to:
- `core/types.py`
- `core/config/*`
- solver engine contracts
- cipher/key-op registry inputs after normalisation

### Tier 2: Public API boundary

Rule:
- may accept strings, aliases, legacy spellings, and loose user inputs
- must normalise once into Tier-1 objects
- must not leak loose forms past the boundary

Applies to:
- `api/normalize.py`
- top-level `RunAPI`
- future core config runner input parsing

### Tier 3: Campaign / benchmark layer

Rule:
- may use serialisable JSON/YAML schema forms
- should use typed internal role specs and enums once loaded
- should not reintroduce lots of free-form strings into runtime logic

Applies to:
- community manifest/job schemas
- benchmark runner policy
- scorer-role specs
- experiment sweep definitions

### Tier 4: Artifact / logging / telemetry output

Rule:
- one shared owner for JSON, JSONL, hashing, path redaction, identity redaction, and output placement
- no local file-writing one-offs
- no ad hoc screen printing for release-facing codepaths

Applies to:
- run logger
- telemetry dumpers
- benchmark writers
- sidecars and manifests

---

## Strongest recommendation from this pass

The next phase of hardening should not only be “fix local bugs”.
It should also explicitly codify a small number of **repo-wide engineering policies** and add tests for them.

In particular:

1. **Core strictness policy**
   - core config/runtime objects should stop accepting raw strings once migration is complete

2. **Boundary normalisation policy**
   - API/config runner is where aliases and loose inputs are accepted

3. **Typed benchmark-role policy**
   - benchmark/campaign internals should move away from copied config dicts and string profile names toward typed role specs

4. **Single artifact/output policy**
   - all persisted output, telemetry, hashes, and path redaction through one owner

5. **Live guardrail policy**
   - if a rule matters, the test enforcing it should not be commented out or half-disabled

---

## Concrete examples of tests worth adding or tightening

### A. Core config strictness after normalisation

Add a guardrail that confirms core runtime entrypoints do not accept raw direction/scorer/solver tokens directly once normalisation is done.

### B. ScoringConfig token audit

Add a review test or static allowlist for string-valued policy fields in `ScoringConfig`, so the list is deliberate and does not keep growing silently.

### C. Benchmark internal enum/role policy

Add focused tests proving benchmark internals convert serialised string inputs into typed role or enum objects early, rather than passing raw strings deep into runtime logic.

### D. Guardrail tests must actually assert

Audit `tests/guardrails/` for commented-out assertions or “TODO later” policy files and either:
- enable them,
- narrow them,
- or delete them.

### E. Single output policy coverage

Add tests that cover:
- JSONL event privacy
- trace-event path redaction
- telemetry dump placement
- benchmark sidecar writers

---

## Bottom line

The repo is not lacking policy intent.
It is lacking **full policy convergence**.

That is good news, because it means v1 does not need a whole new philosophy.
It mainly needs:
- clearer tier boundaries,
- fewer mixed strict/legacy objects in core,
- fewer raw strings in benchmark runtime logic,
- and stronger guardrail tests that are actually live.

The best concise rule set I can see from the current code is:

- **core is strict**
- **boundary is forgiving**
- **campaign is serialisable but typed internally**
- **artifact/output policy has one owner**
- **important rules get live guardrail tests**

That would give you the kind of internal anti-drift contract you are after, both for people and for agents.
