# RDP v1 engineering review — pass 5 (priority and consolidation map)

Date: 2026-03-09
Branch surface reviewed: `experimental/merge` from `repo_links.csv`
Scope in this pass: turn the earlier findings into a v1 fix programme, with emphasis on benchmark hardening, output-policy unification, and no-WLI consolidation.

## What changed in this pass

This pass does **not** treat lagging docs for newly-added scoring options as a major release blocker by itself.

The focus here is:
- correctness and brittle release paths
- cross-cutting duplication that is now expensive to maintain
- places where recent scoring growth has left transitional glue behind
- the smallest safe sequence to get from “works” to “v1-hardened”

## Inventory facts relevant to this pass

From the surfaced CSV inventory:
- `tools/benchmarks/periodic_sub_trans/no_wli/`: **98** files surfaced, **97** of them `.py`
- `tools/benchmarks/periodic_sub_trans/common/`: **24** files surfaced
- `tools/benchmarks/community/`: **30** files surfaced
- `src/rune_decrypter_prime/scoring/`: **50** files surfaced

That does not prove bloat on its own, but it does strongly support a consolidation review in the benchmark area, especially where the public behavioural surface is much smaller than the file count behind it.

## Priority buckets

### Must-fix before v1

#### 1. Remove the double-write path for no-WLI `run_config.json`
`persist_run_config_with_locks(...)` currently writes the config file once, then mutates the payload by adding lock hashes and git metadata, then writes it again.

Why this matters:
- it creates an avoidable partial-write window in a release-facing run path
- it weakens the “one canonical written payload” story
- it makes later hash/audit reasoning less clean than it needs to be

Recommended change:
- build the final payload fully in memory first
- write exactly once
- hash the final written bytes

Test to add:
- focused unit test that proves the writer is called once, and that the written payload already contains `lock_hashes` and `git`

#### 2. Replace inferred run-directory ownership in community single-job execution
`_run_single_job.py` still identifies the pipeline output directory by comparing flavour directories before and after a run, then falling back to the lexicographically latest directory if no new directory appears.

Why this matters:
- it is brittle under reruns, failures, and concurrent/manual output reuse
- it binds a community benchmark job to an output directory by inference rather than explicit ownership
- if it picks the wrong run directory, the job row can silently report the wrong artefacts

Recommended change:
- have the pipeline side return the chosen run directory explicitly, or
- stamp a job-specific run identifier into the run config / summary and resolve by that identifier rather than directory diffing

Test to add:
- direct test for the run-directory selection rule, including the “no new dir exists” case
- direct test that a job cannot accidentally attach to a pre-existing unrelated run directory

### Should-fix in the v1 clean-up window

#### 3. Standardise JSON / JSONL / hash / path-redaction policy behind one output-artifact layer
There are now several overlapping local policies across community and periodic benchmark code:
- JSON writing
- JSONL writing
- canonical JSON for hashing
- payload hashing
- repo-relative path redaction
- snapshot/report emission

This is now one of the clearest consolidation targets in the repo.

Why this matters:
- same class of behaviour is implemented in several local helpers
- slightly different serialisation choices create drift risk
- benchmark output and audit logic are part of the release surface, not incidental tooling

Recommended change:
- create one shared artifact/output policy module for benchmark-facing write rules
- make writer choices explicit: pretty JSON vs canonical JSON vs JSONL append
- make path-redaction behaviour explicit and shared
- keep the call sites small, thin, and obvious

Good boundary:
- `tools/benchmarks/common_output/` or equivalent benchmark-shared layer
- **not** a giant generic utility bag

#### 4. Clear transitional scoring-base drift
`BaseScorer` still carries legacy string-objective parsing helpers while also enforcing the newer enum/objective-spec path. It also currently defines `telemetry()` twice.

Why this matters:
- it signals an unfinished internal contract transition
- duplicate method definition in a base class is a classic “small drift in important code” smell
- the scoring base should be one of the cleanest places in the repo by v1

Recommended change:
- remove the duplicate `telemetry()` definition
- decide whether legacy string objective parsing remains supported in v1 or is strictly compatibility glue
- if compatibility glue remains, isolate it clearly rather than mixing it into the core base contract

Test to add:
- targeted base-scorer contract tests for telemetry, raw-score support, and objective enforcement

#### 5. Consolidate no-WLI orchestration layers
The no-WLI tree now appears heavily over-sliced. The runner is largely an orchestration shell over many helper modules, which helped earlier refactors and testing, but the current file count and layering suggest there is now room to merge several purely-local split modules back together.

The likely merge candidates are the tiny “runner state / entrypoint / defaults / binding / bridge” slices and some of the narrowly split run-mode and stage wiring helpers.

Recommended approach:
- do a keep / merge / delete pass
- keep modules that define a real domain boundary or support re-use
- merge modules that exist mainly to hold a few glue functions or globals wiring

### Later / optional after v1 freeze

#### 6. Broader repo-shape tidy-up
This includes moves, renames, and broader structure improvements across benchmark trees and docs.

Worth doing, but only after:
- behaviour is locked by tests
- brittle release paths are fixed
- output policy is unified

#### 7. Further pruning of experimental reproducer files and historical copies
The surfaced no-WLI tree still includes legacy-looking or reproducer-style files. These are candidates for archive, relocation, or removal once ownership and value are confirmed.

## Consolidation map

### Strong consolidation candidates

#### A. Output writing and audit policy
Current split:
- community: canonical JSON bytes, hashing, JSON/JSONL helpers, integrity chain helpers
- periodic benchmark common: JSON/CSV writers, pipeline snapshot writers
- no-WLI helpers: path redaction, payload hashing, git metadata helpers

Recommended target:
- one benchmark artifact policy layer with clear responsibilities:
  - user-facing JSON write
  - canonical JSON / hash
  - JSONL write / append
  - repo-relative path redaction
  - snapshot emission helpers

#### B. Community result-row construction and pipeline result ownership
`_run_single_job.py` currently bundles:
- module configuration
- pipeline execution
- run-dir discovery
- stage-score extraction
- status/stop-reason mapping
- result-row building

That is a lot for one release-facing adapter module.

Recommended target:
- keep one top-level driver
- lift result-row mapping and run-result ownership into explicit small contracts
- avoid hidden ownership rules based on directory diffs

#### C. no-WLI runner glue
The surfaced tree suggests the no-WLI runner has been refactored into many very thin files.

Recommended target:
- retain a small number of real boundaries, likely something like:
  - runtime/config surface
  - stage execution / orchestration
  - artifact/output handling
  - optional fixture-matrix support
- merge thin wrapper modules whose only role is forwarding globals or one small call

### Areas to avoid over-consolidating

#### D. Score schedule application
This area appears to have solid dedicated tests already and the split seems to encode real behavioural contracts. This is less attractive as a code-volume clean-up target than output writing or runner glue.

#### E. Schema and example assets for community benchmark
These add file count, but they are release artefacts rather than accidental bloat.

## Test posture from this pass

Good signs:
- broad test coverage exists around runner scoring implementation and schedule application
- benchmark schema tests exist and are clearly release-facing
- path privacy / repo-relative output coverage exists

Gap still worth filling:
- direct tests for community single-job run-directory ownership / selection
- direct test for one-write run-config persistence
- direct tests for the shared output artifact policy once introduced

## Smallest safe v1 clean-up sequence

### Phase 1 — harden the brittle release paths
1. add test for one-write run-config persistence
2. change no-WLI run-config persistence to build-final-payload then write once
3. add direct tests for community run-directory ownership
4. replace run-directory inference with explicit ownership

### Phase 2 — unify output behaviour
5. introduce one benchmark output/artifact policy module
6. migrate JSON / JSONL / hash / path-redaction callers onto it
7. add focused parity tests so emitted outputs remain stable where intended

### Phase 3 — scoring-base tidy
8. remove duplicate `telemetry()` in `BaseScorer`
9. make legacy string-objective support an explicit compatibility boundary, not mixed contract glue
10. add focused base-contract tests if they do not already exist elsewhere

### Phase 4 — no-WLI consolidation
11. do keep / merge / delete review over the no-WLI helper tree
12. merge the thinnest local wrapper modules first
13. only then consider broader directory tidy-up

## Current review judgement

The project still looks like it is in the right overall place for a v1 hardening push.

The main story is **not** “missing features”.
The main story is:
- tidy the brittle benchmark release paths
- unify output and audit behaviour
- finish a few obvious internal contract clean-ups
- reduce no-WLI orchestration sprawl where it is no longer buying enough clarity

That is a good kind of work to be doing before v1.
