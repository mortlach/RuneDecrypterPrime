# RDP v1 engineering review - pass 4 (scoring, solver, repo-shape)

Date: 2026-03-09
Branch under review: `experimental/merge`
Basis: surfaced repo links from `repo_links.csv`, plus locally cached copies fetched from those surfaced links during this review.

## Purpose of this pass

This pass moves past docs drift and into the deeper v1 questions:

- is the scoring contract actually settling into one clear shape?
- are the solver and benchmark abstractions carrying their weight?
- where has recent modularisation become file-count bloat?
- which simplifications look safe before v1?

## Main findings

### 1) The scoring contract is improving, but it is still half-strict and half-legacy

**What I found**

The new scorer surface is clearly trying to standardise around strict enums and `ObjectiveSpec`.

- `src/rune_decrypter_prime/scoring/base_scorer.py`
  - presents itself as the minimal stable scorer contract
  - imports the enum/objective family types
  - exposes `_require_objective_pct_logp_win(...)`
  - but still also carries `parse_objective(...)` and `normalize_objective(...)` for legacy string spellings such as `pct.logp.win10`
- `src/rune_decrypter_prime/scoring/rune_scorer.py`
  - describes the input contract as enums plus `ObjectiveSpec`
  - normalises scorer config into that stricter form
  - still has compatibility logic for legacy win/default handling

**Assessment**

This is not a correctness bug by itself. It looks like an expected transition state after recent scoring work.

But for v1 it means the contract is not yet fully single-shape. There are still two mental models alive at once:

1. strict typed objective/config
2. legacy string objective aliases

That increases code volume and review surface. It also makes it harder to tell which forms are truly supported API and which are just transition glue.

**Recommendation**

For v1, make a deliberate choice:

- either keep both forms as a supported public contract and document that clearly
- or declare one canonical internal form (`ObjectiveSpec` + enums), keep string parsing only at the outer boundary, and remove string-normalisation helpers from the deeper scorer base layer

My preference is the second option.

**Priority**: medium

---

### 2) `BaseScorer` shows small but telling layer drift

**What I found**

`src/rune_decrypter_prime/scoring/base_scorer.py` currently defines `telemetry()` twice.

The earlier definition returns `getattr(self, "_telemetry", {}) or {}`.
The later definition returns `dict(self._telemetry) if hasattr(self, "_telemetry") else {}`.

The later definition silently overwrites the earlier one.

**Assessment**

This is a small issue, but it is exactly the sort of thing that appears when a base layer has been edited repeatedly during a transition. It does not necessarily break behaviour, but it is noise in a release-facing core abstraction.

It also weakens confidence in the idea that this file is the single minimal stable contract.

**Recommendation**

Clean `BaseScorer` back down to one authoritative public contract:

- one `telemetry()` method
- one objective-normalisation responsibility boundary
- one clear statement of what concrete scorers must implement

**Priority**: low to medium

---

### 3) The Kaeding solver looks capable, but its parameter surface is now broad enough to justify consolidation

**What I found**

`src/rune_decrypter_prime/solvers/kaeding_periodic_structured.py` is now carrying a large flat parameter surface directly inside `solve()`.

The method reads and mixes policy for:

- step counts and restarts
- block schedule
- slip cadence and slip policy
- column-move cadence
- raw-vs-percentile acceptance
- plateau settings
- seed ranking policy
- top-k retention
- progress and telemetry details

It also mixes two optimisation views in one flow:

- raw score is used for some acceptance / ranking behaviour
- percentile score is used for public progress / stop-score decisions

That may be completely intentional, but it means the solver’s behaviour depends on a fairly wide set of loosely grouped knobs.

**Assessment**

I do not think this is a rewrite target before v1.

But I do think it is now a strong candidate for **policy extraction rather than new features**. The code reads like a mature solver that has accumulated experimental controls. The risk is not that it cannot work; the risk is that its behaviour becomes harder to reason about and harder to keep stable across profile changes.

**Recommendation**

For v1, I would not redesign the solver algorithm. I would do the smaller, safer thing:

- define a smaller set of canonical Kaeding policy bundles/presets
- separate the public solver contract from the long tail of tuning knobs
- keep unusual knobs available, but push them behind named profiles rather than letting every callsite reason about them individually

That reduces mental load without changing the core search logic.

**Priority**: medium

---

### 4) Output writing and canonicalisation are still spread across multiple local policies

**What I found**

This review pass confirms the earlier impression.

There are still at least three overlapping I/O policy surfaces in the benchmark/campaign area:

- `tools/benchmarks/periodic_sub_trans/common/io_reports.py`
  - pretty JSON writer
  - CSV row writers
  - pipeline snapshot files
- `tools/benchmarks/community/_campaign_common.py`
  - canonical JSON bytes for hashing
  - sorted-key pretty JSON writer
  - JSONL writer/reader
  - integrity chain logic
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py`
  - path sanitising
  - canonical JSON text for hashing
  - file SHA helpers
  - repo-relative output transforms

These modules do related jobs, but they do not present a single shared “artifact I/O” policy.

**Assessment**

This is one of the strongest consolidation targets in the whole review.

It is not just about fewer lines. It is about making these behaviours impossible to drift apart:

- pretty output JSON
- canonical JSON for hashing
- JSONL writing rules
- path redaction / repo-relative formatting
- file hashing / payload hashing

These are all release-grade concerns.

**Recommendation**

Create one benchmark-facing artifact/output policy layer and let the current modules shrink around it.

I would split responsibilities like this:

- `artifact_json.py`
  - pretty write
  - canonical write / canonical bytes
  - jsonl read/write
- `artifact_paths.py`
  - repo-relative path rendering
  - redaction policy for external absolute paths
- `artifact_hash.py`
  - payload hash
  - file hash
  - integrity-chain helpers if they stay generic enough

Then the campaign and no-WLI modules can import that policy rather than each carrying their own partial variant.

**Priority**: high

---

### 5) The no-WLI tree has crossed from modular into over-sliced

**What I found**

From the CSV inventory, `tools/benchmarks/periodic_sub_trans/no_wli/` currently contains **98 surfaced files**.

That includes:

- the live runner and many very small helper modules
- `old/` snapshot files
- repro scripts
- focused one-off run scripts
- verification utilities mixed into the live tree

The main `runner.py` is now mostly orchestration and state wiring over many sibling modules.

**Assessment**

This is now a strong repo-shape issue.

Some of this modularity helped create test seams, which was useful during active development. But for v1, the current shape has real costs:

- more files to inspect for one behaviour
- more import wiring and state threading
- more places for local policy drift
- harder contributor navigation
- harder release review

**Recommendation**

Do a keep/merge/delete pass on this subtree before v1.

My likely buckets would be:

**Keep as first-class runtime modules**
- main orchestration
- config application
- stage execution units
- manifest/finalisation
- trace/integrity pieces that are truly part of the runtime contract

**Merge where modules are too thin**
- tiny runtime glue files that mostly forward state or one helper
- paired files that split one concept too aggressively
- setup/logging payload helpers if they add little independent value

**Move out of the live tree**
- `old/` snapshots
- one-off repro scripts
- one-off focus scripts
- ad hoc verification utilities not needed by normal runtime

This is one of the biggest file-count reduction opportunities in the repo.

**Priority**: high

---

### 6) One concrete hardening bug remains in no-WLI run-config persistence

**What I found**

`tools/benchmarks/periodic_sub_trans/no_wli/run_config_io.py` currently writes `run_config.json` twice:

1. once before lock hashes and git metadata are injected
2. again after mutating the in-memory payload

**Assessment**

This is a real release-hardening issue.

Even if it “works” in normal runs, it creates an avoidable partial-write window and makes the file-writing contract less clean than it should be.

**Recommendation**

Build the final payload first, then write once.

If you want stronger hardening, write to a temporary path in the same directory and replace atomically.

**Priority**: high

---

### 7) Existing tests give a good base for the next clean-up round

**What I found**

The surfaced tests I reviewed show useful release-minded guardrails already exist, including:

- fixed-seed parity tests for the main periodic-sub-trans runners
- path privacy tests for repo-relative/redacted output paths
- community config wiring tests

**Assessment**

This is good news. The repo already has the right testing instinct in several places.

The next clean-up wave should build on that rather than adding broad new integration machinery.

**Recommended next tests**

1. `test_persist_run_config_with_locks_writes_once_and_hashes_final_payload`
2. `test_artifact_json_pretty_and_canonical_paths_use_shared_policy`
3. `test_no_wli_output_path_redaction_matches_campaign_policy`
4. `test_no_wli_runner_runtime_contract_smoke_after_module_merge`

## Repo-shape conclusion from this pass

My current view is:

- **core scoring** is close to a stable v1 shape, but should finish the transition from legacy string support to one canonical internal contract
- **solver code** should be hardened through policy bundling, not rewritten
- **benchmark/campaign I/O** should be standardised aggressively before v1
- **no-WLI structure** should be simplified because file-count and orchestration-layer bloat are now real maintenance issues

## Suggested next review step

The next useful pass is the **fix-programme pass**:

- rank findings into must-fix / should-fix / later
- map each change to the smallest safe test-first sequence
- propose the target repo-shape for the benchmark and no-WLI areas

That is the point where this turns from “review findings” into an actual v1 clean-up plan.
