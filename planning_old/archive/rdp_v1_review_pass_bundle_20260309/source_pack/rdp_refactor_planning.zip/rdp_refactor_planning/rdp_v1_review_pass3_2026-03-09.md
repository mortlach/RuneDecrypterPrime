# RDP v1 engineering review — pass 3 (core contracts, benchmark seams, consolidation map)

Date: 2026-03-09
Branch surface: `experimental/merge` from `repo_links.csv`
Reviewer mode: evidence-led, v1 hardening, no feature expansion

## What this pass covered

This pass moved from the benchmark kickoff into the deeper core and cross-cutting review:

- scorer and solver contract surfaces
- benchmark output writing and path handling
- no-WLI runner structure and consolidation opportunities
- test coverage around determinism, path privacy, and campaign wiring

## Files inspected in this pass

Docs / public contract surface:

- `docs/README.md`
- `src/rune_decrypter_prime/README.md`
- `docs/guides/scoring.md`
- `docs/guides/solvers.md`
- `docs/guides/telemetry.md`
- `docs/guides/outputs.md`
- `tools/benchmarks/periodic_sub_trans/no_wli/README.md`

Core code / benchmark code:

- `src/rune_decrypter_prime/scoring/base_scorer.py`
- `src/rune_decrypter_prime/scoring/scoring_adapter.py`
- `src/rune_decrypter_prime/scoring/rune_scorer.py`
- `src/rune_decrypter_prime/solvers/solver_base.py`
- `src/rune_decrypter_prime/solvers/kaeding_periodic_structured.py`
- `tools/benchmarks/community/_campaign_common.py`
- `tools/benchmarks/community/_run_single_job.py`
- `tools/benchmarks/community/run_shard.py`
- `tools/benchmarks/periodic_sub_trans/common/io_reports.py`
- `tools/benchmarks/periodic_sub_trans/common/paths.py`
- `tools/benchmarks/periodic_sub_trans/common/campaign_run_config.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_io.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_completion.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`

Tests inspected in this pass:

- `tests/community/test_campaign_schemas_v1_1.py`
- `tests/community/test_run_single_job_config_v1_1.py`
- `tests/tools/test_periodic_sub_trans_runner_fixed_seed_parity.py`
- `tests/tools/test_no_wli_path_privacy.py`

## Repo-shape facts relevant to this pass

From `repo_links.csv`:

- `tools/benchmarks/community/`: 30 surfaced files
- `src/rune_decrypter_prime/scoring/`: 50 surfaced files
- `tools/benchmarks/periodic_sub_trans/no_wli/`: 98 surfaced files

Inside the surfaced `no_wli/` tree, the top-level file-name groups are heavily fragmented:

- `run_*`: 22 files
- `stage3_*`: 12 files
- `runner_*`: 11 files
- `fixture_*`: 9 files
- `iteration_*`: 7 files
- `runtime_*`: 5 files
- `stage_*`: 5 files
- `oracle_*`: 4 files
- `verify_*`: 4 files
- `old/`: 8 historical files

This does not prove the split is wrong, but it is strong evidence that the no-WLI surface is now in the zone where consolidation should be reviewed seriously before v1.

## Findings

### F-006 — scorer contract drift in docs
Severity: **medium**

The public docs are not aligned about what a scorer returns.

Evidence:

- `docs/README.md` describes the scorer as returning **WLI pairs**, and says the first value ranks candidates.
- `docs/guides/scoring.md` describes `pct.*` outputs as a single percentile in `[0, 1]`.
- `src/rune_decrypter_prime/scoring/base_scorer.py` defines `score(...) -> float` and batch score as a numeric batch interface.
- `src/rune_decrypter_prime/scoring/scoring_adapter.py` exposes a single numeric interface to solvers.

Why this matters:

This is an explicit public contract drift. For v1, scorer input/output shape must be described in one way only. Right now a reader could reasonably infer two different APIs.

Recommendation:

- Decide the canonical public scorer contract.
- Update `docs/README.md` to match the actual solver-facing scorer interface.
- Keep WLI described as input metadata, not as scorer output, unless there is a separate report channel that truly returns it.
- Add or extend a docs/test check so this wording cannot drift again.

### F-007 — release-signal drift still present
Severity: **medium**

The top-level docs present a stable v1 release story, while the package README still presents an early tester preview story.

Evidence:

- `docs/README.md` says “Rune Decrypter Prime (v1)” and describes stable interfaces and deterministic runs.
- `src/rune_decrypter_prime/README.md` still says “Friendly Tester Preview (v0.1.0)” and mentions small variation may still occur.

Why this matters:

This is a release-readiness messaging problem. For v1, public maturity signalling should be coherent.

Recommendation:

- Choose one release story for the branch.
- If this branch is the v1 release candidate, retire the preview framing.
- If it is not yet the v1 release candidate, tone down the top-level “stable v1” framing until the hardening work is complete.

### F-008 — benchmark output-writing policy is fragmented
Severity: **high**

JSON and JSONL writing are handled through several different local policies.

Evidence:

- `tools/benchmarks/periodic_sub_trans/common/io_reports.py`
  - `write_json(...)`: pretty JSON, no sorted keys, no newline.
  - CSV writing and snapshot writing live here too.
- `tools/benchmarks/community/_campaign_common.py`
  - `write_json(...)`: pretty JSON with sorted keys and newline.
  - `write_jsonl(...)`: compact sorted JSONL with `allow_nan=False`.
- `tools/benchmarks/community/run_shard.py`
  - `_write_result_row(...)`: its own JSONL append writer.
- `tools/benchmarks/periodic_sub_trans/no_wli/run_completion.py`
  - mixes `write_json_fn(...)` calls with direct `Path.write_text(...)` for `best_preview.txt`.

Why this matters:

This is exactly the kind of local policy drift that grows maintenance cost and makes behaviour harder to reason about. It also makes reproducibility and file-diff behaviour less predictable.

Recommendation:

Create one shared benchmark I/O surface with a small number of explicit policies, for example:

- `write_json_pretty(...)`
- `write_json_canonical(...)`
- `append_jsonl_row(...)`
- `write_csv_rows(...)`
- `write_text_utf8(...)`
- optional atomic write helper

Then move benchmark surfaces onto those helpers and delete local variants.

### F-009 — run config currently writes twice, creating a partial-write risk
Severity: **high**

`persist_run_config_with_locks(...)` writes the config file once before lock hashes and git metadata are attached, then mutates the payload and writes it again.

Evidence:

- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_io.py`
  - line 20 writes the initial config.
  - lines 21–33 compute lock hashes and git metadata.
  - line 34 writes the config again.

Why this matters:

For a hardening release, startup config should be emitted as one coherent artefact. The current pattern creates a transient half-populated file if the process dies between writes, and it also makes “file observed while being produced” semantics harder to reason about.

Recommendation:

- Build the final payload entirely in memory first.
- Write it once.
- Prefer an atomic temp-file-and-replace write helper if this file is treated as a contract artefact.
- Add a focused test that asserts the final file contains hashes/git fields and is emitted through a single helper path.

### F-010 — path-redaction policy is duplicated and semantically inconsistent
Severity: **medium**

Path handling and path redaction are implemented in several places with different output semantics.

Evidence:

- `tools/benchmarks/community/_run_single_job.py`
  - `_to_repo_rel_path(...)` returns a repo-relative path when possible, but otherwise returns the raw string form of the path.
- `tools/benchmarks/community/run_shard.py`
  - `_sanitize_path_for_log(...)` returns repo-relative text when possible, otherwise `"<abs_path>"` / `"<redacted_path>"`.
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py`
  - `to_repo_rel_path(...)` returns repo-relative text when possible, otherwise `"<external>"` for external absolute paths.
- `tests/tools/test_no_wli_path_privacy.py` locks the `"<external>"` behaviour for the no-WLI helper only.

Why this matters:

The benchmark stack clearly cares about path privacy and portability, but the policy is not yet one policy. This is a classic release-hardening clean-up target.

Recommendation:

- Standardise on one shared path policy helper.
- Make the output modes explicit, for example:
  - repo-relative string
  - external absolute redacted marker
  - temporary path marker
- Reuse that helper across community and no-WLI code.
- Extend tests beyond the no-WLI helper so community paths/logs are also locked.

### F-011 — community single-job run-dir ownership remains brittle
Severity: **high**

The single-job helper still infers “which run directory belongs to this job” by comparing flavour directories before and after execution, then falling back to the latest existing directory if there was no new directory.

Evidence:

- `tools/benchmarks/community/_run_single_job.py`
  - `_pick_run_dir(...)` chooses the newest newly-created directory when possible.
  - if no new directory appears, it falls back to the lexicographically latest existing directory.
  - `run_single_job(...)` uses this inferred run dir after `pipeline_module.main()` completes.

Why this matters:

This is acceptable for early glue code, but it is not a strong ownership contract for a release-facing benchmark runner. It is vulnerable to ambiguity when multiple runs touch the same flavour output area.

Current test picture from this pass:

- `tests/community/test_run_single_job_config_v1_1.py` strongly checks config forwarding and relative path handling.
- In the files inspected for this pass, I did **not** find a direct test that locks `_pick_run_dir(...)` behaviour under collision or pre-existing-directory scenarios.

Recommendation:

Prefer an explicit handshake from the pipeline side, for example:

- pipeline returns the allocated run dir, or
- pipeline writes a `run_manifest.json` / `run_id` file that the helper can bind to directly.

Then add one focused test for ambiguous pre/post directory states.

### F-012 — no-WLI runner surface is over-sliced and globals-heavy
Severity: **medium/high**

The active no-WLI implementation looks more modular than the old runner, but it has crossed into a “many thin orchestration layers” shape.

Evidence:

- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py` is mostly a glue layer.
- It imports a large number of helper modules.
- It repeatedly passes `state=globals()` into setup/entrypoint/orchestrator functions.
- `main()` itself is largely wiring for injected helper functions.
- The surfaced `no_wli/` tree now contains 98 files, including 22 `run_*`, 12 `stage3_*`, and 11 `runner_*` files.

Why this matters:

This shape can be useful during refactor-in-flight work because it creates seams. But for v1, it also raises the cost of understanding the system, tracing behaviour, and reviewing future changes.

Recommendation:

Do a keep/merge/delete pass over the active no-WLI modules and collapse them into a smaller number of cohesive units, for example:

- `config_surface.py`
- `startup.py`
- `execution.py`
- `outputs.py`
- `fixture_matrix.py`
- `entrypoints.py`

That would still preserve testable seams, but it would reduce file-count overhead and make responsibilities clearer.

### F-013 — `BaseScorer` contains small but real duplication/bloat
Severity: **low**

`BaseScorer` appears to contain duplicated or near-duplicated content.

Evidence:

- `src/rune_decrypter_prime/scoring/base_scorer.py`
  - duplicate `telemetry(...)` definitions appear in the class.
  - duplicated helper comment line above `_stash_stats(...)`.

Why this matters:

This is not a high-risk bug by itself, but it is a sign that the scorer base has accumulated local edits and should get a small clean-up before v1.

Recommendation:

- Remove the duplicate `telemetry(...)` definition.
- Trim repeated comments and unused imports.
- Add one tiny test if needed only when behaviour changes; otherwise keep this as a no-behaviour-change clean-up.

## Strengths confirmed in this pass

These are worth preserving during simplification:

- `tests/community/test_campaign_schemas_v1_1.py` gives a good release-facing floor for required benchmark files and schema validity.
- `tests/community/test_run_single_job_config_v1_1.py` checks important campaign wiring and path-portability behaviour.
- `tests/tools/test_periodic_sub_trans_runner_fixed_seed_parity.py` gives a useful determinism/parity safety net for the main runner families.
- `tests/tools/test_no_wli_path_privacy.py` already locks one path-redaction contract explicitly.
- `tools/benchmarks/community/run_shard.py` does careful identity validation and integrity-chain handling around result rows.

## Immediate v1 actions suggested by this pass

1. **Lock output-writing policy**
   - choose one benchmark JSON / JSONL / text writing surface
   - route benchmark writers through it

2. **Fix the double-write run-config path**
   - compute final payload first
   - single write
   - ideally atomic write

3. **Replace inferred run-dir ownership with an explicit token or returned path**
   - then add one ambiguity test

4. **Unify path-redaction semantics across community + no-WLI**
   - keep repo-relative where safe
   - redact external paths consistently

5. **Clean the public contract story**
   - scorer output docs
   - v1 vs preview messaging

6. **Run a no-WLI consolidation pass**
   - keep helper seams where they genuinely help
   - merge thin orchestration modules where they now only forward state

## What remains to review

Still to do for the full review:

- deeper pass over scoring internals and scorer registry consistency
- solver/telemetry cross-check against docs and tests
- repo layout map with concrete move/merge/delete candidates
- benchmark campaign profile catalogue and schema/catalog coherence
- dead/historical surface review (`old/`, historical snapshots, obsolete docs/examples)

## Current judgement

The project is clearly moving toward v1 discipline, and several important release-facing pieces are already in good shape. The main remaining v1 work is not feature expansion. It is contract clean-up, writer-policy unification, path/privacy consistency, and reducing over-sliced orchestration in the benchmark stack.
