# RDP v1 engineering review – pass 23

Date: 2026-03-09
Scope: holistic logging / file-writing / screen output / telemetry / privacy contract
Source surface: local no-bloat review bundle (`src`, `tests`, benchmark subtrees)

## Why this pass

A recurring theme in the review is that output behaviour is still owned by too many places at once:
- run-dir creation and metadata snapshots
- JSONL event logging
- telemetry dumping
- benchmark JSON / JSONL / CSV writers
- path redaction and hashing
- console progress and human-readable traces

The code is close to a coherent model, but not there yet. This matters for v1 because logging/output is where privacy drift, path leaks, duplicated policy, and agent drift tend to accumulate.

## Main conclusions

### 1) There is not yet one canonical output/privacy contract

The repo already has the right *intention*:
- `core/config/logging_config.py` owns run-dir lifecycle, `META.json`, and `config/logging.json`
- `io/README.txt` says new sinks should never write outside the run directory and should honour `LoggingConfig.redact_identity`
- `telemetry/README.txt` says telemetry should respect privacy toggles and go through common helpers

But the implementation is still split:
- `io/run_logger.py` writes JSONL events and trace files and records absolute trace paths into `app.jsonl`
- `telemetry/pipeline.py` has a separate default mirror location under `output/telemetry/logs`
- `tools/benchmarks/community/_campaign_common.py` owns one JSON / JSONL / hash policy
- `tools/benchmarks/periodic_sub_trans/common/io_reports.py` owns another JSON / CSV snapshot policy
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py` owns path redaction, canonical JSON, and hashing again

This is now one of the clearest v1 convergence jobs in the whole repo.

### 2) Privacy intent exists, but pass-through is incomplete

A concrete mismatch:
- `LoggingConfig` includes `redact_identity`
- `api/logging_utils.py::normalize_logging_cfg(...)` does **not** allow that field through its allow-list

So a user-facing logging dict cannot currently enable the privacy flag even though core logging supports it.

That is a real contract gap, not just a style issue.

### 3) Absolute paths are still leaking into event streams

`tests/test_logging_paths.py` only protects:
- `META.json`
- `config/logging.json`

Those tests are good, but they do not cover the JSONL event stream.

Meanwhile `io/run_logger.py`:
- resolves `run_dir`
- resolves `logs/app.jsonl`
- resolves trace file paths
- logs `{"type": "trace_written", ..., "path": str(path)}`

So path privacy is currently stronger in snapshot files than in streamed events.

### 4) Library code still self-initialises output state

`io/run_logger.py` will self-initialise logging with a default `LoggingConfig(...)` if no run dir exists yet.

That was useful for tests/dev convenience, but for v1 it weakens the contract:
- output ownership becomes implicit
- library code can create run trees without the caller making that decision explicitly
- future GUI / API / agent front ends become harder to reason about

For v1 I would prefer one explicit initialisation boundary, with test helpers wrapping that if needed.

### 5) Telemetry still has a second default destination

`telemetry/pipeline.py::dump_telemetry(...)` writes to `output/telemetry/logs/run-<timestamp>.jsonl` when no base dir is given.

That is a second default output policy outside the normal run-dir contract.

Given the rest of the repo direction, I do not think v1 should have two default homes for telemetry.

### 6) Console output is still too ad hoc in benchmark code

The benchmark side, especially `no_wli/setup_logging.py`, still prints large amounts of configuration and stage information directly to stdout.

That is understandable historically, but holistically it means the repo still has at least three parallel user-facing output channels:
- structured JSONL events
- human-readable text traces
- direct `print(...)` status lines

For v1 that needs a clearer contract.

I do **not** think all printing should vanish.
But I do think it should become:
- explicitly gated
- categorised (`progress`, `summary`, `warning`, `debug`)
- and derived from one shared console/report policy rather than many local prints

### 7) Canonical JSON / hashing policy is still duplicated

This was already visible earlier, but it matters even more on the holistic logging/output pass.

At the moment there are multiple active canonicalisation and hashing owners:
- community benchmark canonical JSON and integrity chain
- no-WLI path/hash helpers
- benchmark report writers

They are not all semantically identical.

That means two nearby subsystems can both claim to be producing “canonical JSON” while using slightly different float handling, path handling, or sanitisation.

For v1, that should become one shared owner.

## Recommended target architecture

I think the repo now wants one explicit owner for output policy.

### Proposed owner

`rune_decrypter_prime.artifacts` or `rune_decrypter_prime.output`

This should own:
- run-dir policy
- file layout contract
- JSON / JSONL writing helpers
- canonical JSON / hashing helpers
- path redaction / repo-relative policy
- telemetry dump placement
- text trace placement
- small typed write intents (`event`, `trace`, `summary`, `artifact`, `report`)

I would keep logging config itself in core config, but make it configure this owner rather than partly re-implementing policy in several places.

### Suggested contract shape

#### `OutputPolicy`
A strict config object controlling:
- base output root
- fixed run dir or auto run dir
- repo root
- privacy mode (`redact_identity`, maybe later `redact_paths` level)
- whether JSONL is enabled
- whether text traces are enabled
- console verbosity/profile

#### `ArtifactWriter`
The single write surface for:
- `write_json(...)`
- `append_jsonl(...)`
- `write_text_trace(...)`
- `write_csv_rows(...)`
- `canonical_json_bytes(...)`
- `hash_payload(...)`
- `repo_local_path(...)`

#### `ConsoleReporter`
A very small layer for:
- `progress(...)`
- `summary(...)`
- `warning(...)`
- `debug(...)`

This gives you one place to define what is allowed to hit stdout.

## What I would change before v1

### Must-fix

1. **Pass `redact_identity` through `api/logging_utils.py`**
2. **Stop logging absolute trace paths in `io/run_logger.py` events**
3. **Stop default telemetry dumps from going to a second output tree**
4. **Add tests for JSONL path privacy, not just `META.json` / `logging.json`**

### Should-fix

5. **Remove library self-init from `RunLogger` or contain it behind an explicit test helper**
6. **Unify canonical JSON / hashing / path-redaction helpers**
7. **Move benchmark JSON/JSONL/CSV writing onto one shared artifact layer**
8. **Replace large direct `print(...)` clusters with a small console/report contract**

### Later but worth doing

9. add event/type enums or constants for console/report categories
10. add a policy level for external-path redaction (`keep_repo_rel`, `external_placeholder`, `basename_only`)
11. decide whether `ScorerReport` and future `SolverReport` should be written through the same artifact layer as first-class typed summaries

## Tests I would add

1. `tests/test_logging_jsonl_paths_redacted.py`
   - initialise logging with `redact_identity=True`
   - emit a trace event
   - assert no absolute path leaks into `logs/app.jsonl`

2. `tests/test_logging_utils_redact_identity_passthrough.py`
   - pass a dict with `redact_identity=True`
   - assert the returned core config preserves it

3. `tests/telemetry/test_dump_telemetry_uses_run_policy.py`
   - assert telemetry dump goes under the active run dir unless explicitly overridden

4. `tests/tools/test_artifact_hash_policy_parity.py`
   - same payload through community and no-WLI helpers should hash identically once unified

5. `tests/tools/test_console_reporting_gates.py`
   - assert progress/debug printing is suppressed when the chosen console policy disables it

## Design recommendation for AI agents and future tooling

You explicitly mentioned wanting a clear contract that AI agents can follow without drift.

I think the repo should eventually document a short **Output and Privacy Contract** something like this:

1. Never write outside the active run/artifact policy root unless the caller explicitly overrides it.
2. Never emit absolute filesystem paths into persisted JSON / JSONL unless explicitly allowed.
3. Use repo-relative paths where possible; use `<external>` or another redacted token for paths outside the repo.
4. Do not self-initialise output directories inside low-level helpers.
5. All JSON / JSONL / trace writes go through the shared artifact layer.
6. Console printing must go through the shared console/report layer.
7. Respect privacy toggles consistently across metadata, events, traces, and reports.
8. If a new component needs persistence, add or extend a shared write intent rather than inventing a local writer.

That would genuinely help both human contributors and AI agents.

## Overall judgement after this pass

The repo does **not** need a giant logging rewrite.

It needs convergence:
- one output owner
- one privacy/path policy
- one canonical JSON / hashing policy
- one explicit console/report contract

This is exactly the sort of cleanup that pays off before a first-class config runner, GUI layer, or wider community campaign surface.
