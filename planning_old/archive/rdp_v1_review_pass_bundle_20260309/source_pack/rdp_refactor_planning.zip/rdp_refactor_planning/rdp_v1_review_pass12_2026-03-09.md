# RDP v1 engineering review – pass 12 (direction, alternatives, and structural convergence)

Date: 2026-03-09
Reviewer: ChatGPT
Scope used in this pass: local `src + tests + benchmarks` bundle supplied by user

## Purpose of this pass

This pass is not mainly about finding one more local bug.

It is about pressure-testing the overall direction for v1:
- where I agree with the current direction,
- where I think the repo is still carrying too much benchmark-local complexity in the wrong layer,
- and what I think is the safest *alternative final structure* for convergence.

The key point is this:

**I do not think the main blocker is missing scoring features. I think the main blocker is that scoring roles, benchmark roles, artifact policy, and runner structure have not fully converged yet.**

That matters because it changes what I would do next.

---

## Where I agree with your framing

I agree with your broad picture:
- alpha-style feature exploration looks largely complete,
- the repo now needs hardening, simplification, convergence, tuning, proof, and then speed work,
- and the no-WLI split was a necessary step to escape one giant 5,000-line file.

I also agree that we should **not** assume too quickly that we already know the final ideal structure for no-WLI. The current split clearly helped make the moving parts visible.

So my recommendation is **not** “collapse it back into one file” and **not** “delete slices just because there are many files”.

What I *do* think is true is that the repo is now at the point where the next structure should be chosen to support:
- stable scorer roles,
- explicit artifact/output contracts,
- clear benchmark orchestration,
- and future tuning of span/word-ngram behaviour without multiplying ad hoc wiring.

---

## Where I would push back slightly

I would be careful about this idea:

> “we may need even more slices to properly support the newer scoring methods”

That may be true in one narrow sense, but I think the bigger risk now is **not too few slices**. It is that we keep adding new slices and new config flags without first deciding what belongs in:
- the **core scorer contract**,
- the **benchmark role contract**, and
- the **artifact/report contract**.

In other words:

**the next scaling move should probably be more role clarity, not just more files.**

Right now the repo already shows signs that benchmark-local concerns are being expressed through wider and wider scorer config surfaces.

### Evidence

In `src/rune_decrypter_prime/core/config/scoring.py`, `ScoringConfig` now carries a large surface for calibrated span behaviour, optional span LM extension, and word-ngram judge fields. The span-related fields occupy a long block, and the word-ngram judge side-channel is also embedded directly into the same config object (`span_hamming_*`, `span_hamming_lm_*`, `word_ngram_judge_*`).

This is not wrong by itself, but it is a sign that the core scorer contract is starting to absorb benchmark-local orchestration choices.

Relevant local file pointers:
- `src/rune_decrypter_prime/core/config/scoring.py:103-144`
- `src/rune_decrypter_prime/core/config/scoring.py:220-284`

---

## Strong new structural finding: the no-WLI runner still depends heavily on global state choreography

The current `no_wli/runner.py` is not just a thin script entry point. It still acts as a large mutable state hub.

### Evidence

The runner:
- populates defaults via `apply_runner_defaults(state=globals())`,
- initialises runtime state into `globals()`,
- passes `globals()` into profile, run-mode, and campaign config entrypoints,
- then pulls values back out of `globals()` for later use.

Relevant local file pointers:
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py:137-156`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py:160-206`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py:245-276`

This is understandable as a migration step away from the giant original file, but for v1 it is still too implicit.

### Why this matters

This style makes it harder to answer simple questions like:
- which values are true inputs,
- which values are derived,
- which values are mutable during run setup,
- and which values are safe to persist, hash, or expose in reports.

It also makes future scorer integration harder, because every new scorer-side feature has to thread through a large mutable runner namespace instead of one narrow runtime object.

### My recommendation

Do **not** try to rewrite the whole benchmark around classes.

Instead, do one controlled convergence step:

- keep `runner.py` as the script-facing shell,
- but compile globals into a single explicit `RunContext` / `RuntimeInputs` object early,
- then pass that object downward.

That gives most of the benefit without a huge rewrite.

---

## Strong new structural finding: repeated sys.path bootstrap logic is now repo-wide tool bloat

The benchmark/tooling side contains a lot of repeated repo bootstrap code.

### Evidence

A quick static pass over `tools/benchmarks` found **45 Python files** containing `sys.path.insert(...)` bootstrap logic.

That includes:
- community benchmark scripts,
- periodic benchmark runners,
- span-hamming scripts,
- word-ngram asset builders,
- validation tools,
- repro helpers.

Representative local file pointers:
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py:19-24`
- `tools/benchmarks/periodic_sub_trans/col_then_sub/runner.py:50-55`
- `tools/benchmarks/periodic_sub_trans/sub_then_col/runner.py:29-34`
- `tools/benchmarks/community/run_shard.py:18`
- many files under `tools/benchmarks/scoring/span_hamming_nose/...`

### Why this matters

This is not a correctness bug in itself, but it is a classic v1 clean-up target:
- many local copies,
- subtle drift risk,
- and more file noise than needed.

### My recommendation

Create one small shared boot helper for repo-root / src insertion and have these scripts call it.

This is small, safe, and directly reduces code volume and drift.

---

## Strong new structural finding: scorer roles are clearer in intent than in contract

The repo increasingly distinguishes several scorer *roles* in practice:
- stage search scorer,
- stage judge scorer,
- basin judge scorer,
- side-channel report scorer,
- and auxiliary span role.

But those roles are still expressed mostly as **copied config dictionaries** rather than a small explicit role model.

### Evidence

In `iteration_runtime.py`, the runtime builds:
- `scorer_stage3_search`,
- `scorer_full`,
- `scorer_basin_judge`,
- and `scorer_word_ngram_report_cfg`.

The word-ngram report config is built from `base_cfg=dict(scorer_basin_judge)`, then extended with word-ngram judge fields.

Relevant local file pointers:
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_runtime.py:106-136`
- `tools/benchmarks/periodic_sub_trans/no_wli/scoring_experiment_config.py:101-130`

### Why this matters

This is the main place where I think a better alternative exists.

The current code is saying:
- “these are really different runtime roles”,
- but the structure is still saying:
- “copy this other scorer config and tweak it a bit”.

That is good enough for experimentation, but it becomes less intuitive as more scoring methods arrive.

### My recommendation: introduce **benchmark-local scorer role specs**

I would *not* rush to add more fields to `ScoringConfig` unless the core scorer truly needs them.

Instead, I would introduce a very small benchmark-local layer such as:

- `StageSearchRoleSpec`
- `StageJudgeRoleSpec`
- `BasinJudgeRoleSpec`
- `WordNgramReportRoleSpec`

These can stay simple dataclasses or typed dicts in benchmark code.

Then one compile step turns them into `ScoringConfig`.

That gives you three benefits:
1. the benchmark becomes easier to reason about,
2. the core scorer surface stops bloating with benchmark-local intent,
3. new side-channels can be added by adding one role compiler rather than by copying configs in more places.

This is the strongest “better alternative” I currently see.

---

## Strong new structural finding: output / artifact policy still needs one owner

Earlier passes already found duplicate JSON / JSONL / hashing / path-redaction logic. This pass strengthens that conclusion.

### Evidence

Community benchmark helpers use one canonical JSON and float-normalisation policy:
- `tools/benchmarks/community/_campaign_common.py:21-47`

No-WLI hashing helpers use another sanitisation and canonical JSON path:
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py:90-126`

These are not byte-for-byte identical contracts.

### Why this matters

As soon as you care about:
- persisted config hashes,
- audit chains,
- report rows,
- privacy-safe paths,
- scorer sidecars,
- and release reproducibility,

this should be one explicit policy family, not several local ones.

### My recommendation

Create one benchmark artifact policy module that owns:
- canonical JSON
- float policy
- JSONL write policy
- hashing
- repo-relative path redaction
- atomic writes where needed

Then adapt community / no-WLI / periodic code to use that shared layer.

This remains one of the highest-value v1 changes in the whole repo.

---

## Strong new structural finding: exact duplicates and near-duplicates now justify a package tidy

### Exact duplicate already confirmed

`stage_engine_trace.py` is an exact triplicate across:
- `no_wli`
- `col_then_sub`
- `sub_then_col`

The corresponding tests are also three local variants.

### Near-duplicate already confirmed

The `stage_engine_iteration_bridge.py` files in `col_then_sub` and `sub_then_col` differ mainly in stage names, class names, and a few identifying strings.

This is a strong signal that the current flavour layout is carrying more duplication than necessary.

### My recommendation

Do not force all flavour code into one mega-generic bridge.

But do extract:
- exact duplicate helpers immediately,
- and a common bridge skeleton where only stage labels / callbacks differ.

That is the right middle ground.

---

## What I think the best final structure looks like

Not the exact file-by-file end state, but the *shape*.

### For `no_wli`

Keep the stage-based split, but regroup the flat folder into subpackages, for example:

- `no_wli/run/`
  - startup
  - config build/persist
  - environment
  - summary/completion
  - manifest / audit

- `no_wli/runtime/`
  - runtime defaults
  - run-mode resolution
  - runner state compilation
  - iteration runtime assembly

- `no_wli/stages/`
  - stage1
  - stage2
  - stage3
  - iteration flow / commit / outcome

- `no_wli/scoring_roles/`
  - experiment config
  - search role compiler
  - basin judge role compiler
  - word-ngram report role compiler
  - span auxiliary role compiler

- `no_wli/fixture_matrix/`
  - models
  - plan
  - jobs
  - runtime
  - mainflow

- `no_wli/trace_audit/`
  - stage engine trace
  - hash chain verification
  - final artifact verification
  - path/hash helpers

This would preserve the benefits of the split while making the package much easier to scan.

### For scoring integration

Prefer this boundary:
- **core scorer** owns actual scoring capability and strict config validation
- **benchmark role layer** owns how a benchmark uses that capability in search/judge/report roles
- **report layer** owns how results are persisted and compared

That boundary feels cleaner than continuing to push more benchmark intent into the core scorer config surface.

---

## Concrete priority judgement after this pass

### Must-fix before v1

1. `run_config.json` double-write in `run_config_io.py`
2. inferred run-directory ownership in the community single-job helper
3. raw `WORD_NGRAM_REPORT_SQLITE_PATH` persistence in run config
4. mtime-driven auto-selection of word-ngram SQLite asset

### Strong should-fix before v1

5. unify artifact/output/hash/path policy
6. stop relying on copied scorer config dicts for distinct benchmark scorer roles
7. replace global runner state choreography with one early compiled runtime context
8. remove obvious exact duplicates (`stage_engine_trace`, matching trivial tests)
9. move historical snapshots out of the active source tree
10. standardise repo bootstrap helper instead of repeating `sys.path` setup

### Likely after v1 or only if low-risk

11. deeper consolidation of flavour bridges
12. bigger scorer-config contract tightening
13. speed optimisation beyond obvious low-risk wins

---

## Bottom line

I agree with your high-level diagnosis.

Where I would sharpen it is this:

**RDP does not mainly need more slices. It mainly needs clearer ownership of roles.**

The next good structure is not “more benchmark files because scoring got richer”.
It is:
- explicit benchmark scorer roles,
- one artifact/output policy,
- one early runtime context,
- and a tidier package layout that keeps useful decomposition but removes accidental fragmentation.

That is the best alternative I currently see for getting to a smaller, clearer, more trustworthy v1 without losing scoring or solving fidelity.
