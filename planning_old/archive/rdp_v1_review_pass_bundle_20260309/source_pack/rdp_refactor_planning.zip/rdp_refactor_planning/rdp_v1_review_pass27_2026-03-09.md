# RDP v1 review – pass 27 (2026-03-09)

## Focus of this pass

This pass continues the whole-codebase static review from the local no-bloat bundle, with two goals:

1. check more of the remaining public/boundary surface rather than only the core/benchmark internals;
2. estimate how much more review is worth doing before a first full collation and meta-review of the findings.

---

## New findings from this pass

### 1) The public API/tests/tutorials are closer to a config-runner shape than the code is

The test surface under `tests/api`, `tests/api_contract`, and `tests/tutorials` already acts like there is one canonical solve front door:
- `RunAPI.run(...)`
- the free `run(...)` helper
- typed solver/key specs
- normalisation tests at the API boundary
- tutorial-style integration tests for example solves

That is good news. It means a first-class serialisable config runner would not be introducing a foreign model; it would mostly be formalising what the public-facing tests already imply.

What is still missing is the actual serialisable contract and its tests. The current tests mostly exercise call-shape and boundary normalisation, not a stable JSON/YAML `RunSpec` round-trip.

### 2) Tutorials and examples still show some drift between “library surface” and “script surface”

A few tutorial tests still launch example scripts via `subprocess.run(...)` rather than using one common config-runner/library entrypoint.

That is not wrong for tutorial coverage, but it is a sign that the current example story is still split between:
- a Python API/tutorial path; and
- a script/process path.

A proper core config runner would help collapse that split.

### 3) Tooling is still very script-oriented, with a lot of local bootstrap behaviour

In the local bundle, many benchmark and asset-building scripts still use patterns like:
- `sys.path.insert(...)`
- `Path(__file__).resolve().parents[...]`
- direct `print(...)`
- local output-root discovery and path resolution

That is understandable for one-shot tooling, but it reinforces the broader review conclusion:

**the repo still lacks one clear divide between reusable library code and one-off tool scripts.**

For v1 that does not mean “ban scripts”. It means:
- make the reusable owners explicit;
- let scripts be thin wrappers over those owners;
- stop letting script-local habits become de facto contracts.

### 4) There is at least one more concrete low-severity code-cleanliness bug in core utilities

`utils/runeglish.py` defines `rune_to_latin(...)` twice. The second definition overrides the first and a TODO at the bottom explicitly acknowledges this.

This is low severity, but it is exactly the kind of “harmless until it is not” utility drift worth clearing out before v1.

### 5) The current architecture is still carrying too much “bridge code” at the edges

Across API helpers, tutorials, community runner bridges, and benchmark scripts, the current repo often relies on transitional glue rather than one clean public execution contract.

This is consistent with the overall review so far:
- the main problem is not lack of capability;
- the main problem is incomplete convergence around a small number of stable owners and contracts.

---

## Updated architectural judgement

The repo now looks like it wants the following v1 centre of gravity:

- one **core serialisable RunSpec / config runner**;
- one **ProblemSource** layer below it;
- one **SolveResult** / run-result contract;
- one event-style **telemetry** stream;
- a small set of typed summary objects such as **ScorerReport** and probably **SolverReport**;
- one **ArtifactPolicy / ArtifactIO** owner for JSON, JSONL, hashes, path redaction, and console/output placement;
- thin scripts on top, not many competing execution paths.

The API tests/tutorials are already pointing in that direction. The code just has not fully converged to it yet.

---

## How much more review before first collation?

My current assessment is:

### Enough has been reviewed already for a **first serious collation**

We have now covered the main high-value areas:
- scoring and scorer/report wiring
- benchmark/community campaign structure
- no-WLI runtime shape
- output/privacy/path policy
- telemetry/report boundaries
- API / run config seams
- cipher/key-op registry seams
- data/loading ownership
- internal anti-drift policy direction

So if needed, I could already produce a meaningful first full review pack now.

### But there are still about **3 more worthwhile review slices** before that collation becomes as strong as it reasonably can be from this bundle

I would still like to do:

1. **Solver internals / stop-reason / progress / telemetry pass**
   - solver base
   - progress logger/mixin
   - stop reasons, counters, best-candidate reporting
   - where a narrow `SolverReport` should come from

2. **Boundary/examples/tutorials/config-runner-readiness pass**
   - API tutorials/examples/tests as public contract
   - what a serialisable `RunSpec` would need to cover
   - what should stay boundary-only vs move into core

3. **Tool-script / packaging / repo-shape final sweep**
   - remaining script/bootstrap patterns
   - historical shim/debris candidates
   - what should move, shrink, or become thin wrappers

After those 3 slices, I think it becomes efficient to stop gathering and move to:
- first full collation;
- review-of-the-review;
- final ordered v1 cleanup plan.

### So, in plain English

We are **past halfway**.

I would say:
- about **70–80%** of the useful static engineering review has now been done;
- about **20–30%** remains before first collation is the right move.

That remaining part is not “the whole repo again”. It is mostly the last few high-value seams plus a tidy final sweep.

---

## Practical recommendation

Carry on with those last 3 review slices, then switch modes.

At that point, do not keep collecting endlessly.
Instead:
- collate findings;
- group them into must-fix / should-fix / later;
- cross-check against the intended architecture and the original spec;
- then turn that into the v1 hardening/convergence programme.

That now looks like the right point in the process.
