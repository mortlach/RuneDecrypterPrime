# RDP v1 next steps programme

## Purpose

This plan turns the completed review into a controlled hardening phase.

The goal is not to rush into code changes. The goal is to:
- validate the review findings,
- get developer feedback,
- settle the target architecture,
- choose a safe implementation order,
- and then execute the cleanup without losing solving or scoring fidelity.

---

## Overall principle

Use this order:

1. Review the review
2. Get developer and maintainer feedback
3. Freeze the target architecture and internal policies
4. Define the implementation programme
5. Add or tighten tests before structural changes
6. Implement must-fix items first
7. Implement convergence work second
8. Defer speculative work until after the repo is stable again

Do not start with broad refactors.
Do not merge or move large areas before the intended contracts are agreed.
Do not add major new feature work except convergence features that simplify the system.

---

## Phase 1: Review the review

### Goal
Make sure the review is accurate, proportionate, and useful before it drives implementation.

### Inputs
- `rdp_v1_review_collated_programme_2026-03-09.md`
- `rdp_v1_findings_register_2026-03-09.csv`
- individual review passes 1–34

### Method
Run one careful reading pass over the collated review and classify each finding as one of:
- agree
- partly agree
- disagree
- unclear / needs repo check
- true but not for v1

### What to check
For each finding, ask:
- Is the fact correct?
- Is the severity right?
- Is the recommendation sensible?
- Does it preserve solving fidelity?
- Does it assume a final structure too early?
- Is it static-only evidence, or do we need runtime confirmation later?

### Outputs
Create a reviewed version of the findings register with extra columns:
- owner
- review status
- comment
- evidence confidence
- runtime confirmation needed?

### Suggested meeting or async review topics
- Are the must-fix items really must-fix?
- Which findings are definitely branch defects versus cross-branch oversights?
- Which recommendations are architectural and which are just cleanup?
- Which items should be postponed until after the config runner exists?

---

## Phase 2: Get developer feedback

### Goal
Bring in the people who know the intent behind the code so we do not “tidy away” deliberate design choices.

### Who should review
At minimum:
- you as project owner
- one or two developers who worked most on no-WLI / benchmark runner evolution
- one developer familiar with scoring additions and scorer-report plumbing
- one person who knows packaging / install / community-run flow

### Review format
Use short written feedback against the findings register rather than free-form chat.

For each finding, ask reviewers for:
- factual correction if any
- whether the current behaviour is deliberate
- whether the recommendation is safe
- whether they see a better alternative
- what tests would prove the change is safe

### Specific questions for developers
1. Which current weirdness is intentional transition glue?
2. Which duplicated helpers are genuinely temporary?
3. Which benchmark-local config patterns must survive until after tuning work?
4. Which no-WLI slices are helpful decomposition and which are accidental fragmentation?
5. Which parts of `ScoringConfig` are core, and which are benchmark-local role logic leaking inward?
6. Is `ScorerReport` already the intended canonical summary object?
7. Would a narrow `SolverReport` help, or is it premature?
8. Which branch contains the missing outer-surface files and what is the merge plan?

### Outputs
- updated findings register
- “design intent” notes for disputed areas
- shortlist of items that need runtime confirmation later

---

## Phase 3: Freeze the target architecture

### Goal
Agree the intended shape before structural work starts.

### Decisions to settle
#### 1. Top-level structure
Decide the intended repo surfaces. A likely shape is:
- `src/rune_decrypter_prime/` for library/core/API
- `campaigns/` for distributed experiment and community run infrastructure
- `tutorials/` for human-facing examples
- `problem_sources/` or equivalent inside core/library for LP and reusable source definitions
- `tools/` reduced to genuinely auxiliary helpers

#### 2. Core run model
Decide that RDP gets one first-class serialisable `RunSpec` / config runner.

Decide what belongs in:
- problem spec
- solver spec
- scorer role specs
- logging / output policy
- expectations / assertions

#### 3. Campaign model
Decide that campaign infrastructure sits above the core run model.

Campaign adds:
- job identity
- fixture identity
- sweep metadata
- shard / resume policy
- aggregation outputs

It should not invent a second solve-description language.

#### 4. Problem classes
Decide whether no-WLI is:
- the same outer problem with different inner policies, or
- a separate top-level run family

My recommendation remains: same outer model, different inner policies.

#### 5. Report model
Settle the typed summary story:
- telemetry remains event-level detail
- `ScorerReport` remains scorer-local summary
- optionally add a narrow `SolverReport`
- reports do not replace telemetry

#### 6. Artifact/output/privacy policy
Agree that one owner will handle:
- JSON
- JSONL
- hashing
- path redaction
- identity redaction
- trace placement
- console/report policy

#### 7. Internal anti-drift rules
Make the important rules explicit, for example:
- strict in core, forgiving at the boundary
- enums in core, no magic strings in core
- no direct absolute paths in persisted outputs
- no script-style self-bootstrap inside first-class library code
- no duplicated artifact-writing helpers
- important rules must have live guardrail tests

### Outputs
Create one short architecture decision pack:
- target repo shape
- target run/config model
- target artifact/output policy
- target reporting model
- internal anti-drift policy list

Keep it short and decisive.

---

## Phase 4: Build the implementation programme

### Goal
Convert the reviewed findings into an ordered work programme.

### Buckets
#### Must-fix before v1
Examples from the review:
- brittle run-directory ownership in community single-job flow
- double-write of `run_config.json`
- raw `WORD_NGRAM_REPORT_SQLITE_PATH` persistence
- mtime-driven default word-ngram asset selection
- broken outer-surface install/CI references on the reviewed branch
- output/privacy gaps such as absolute trace paths in JSONL events

#### Should-fix in v1 hardening
- unify artifact/output/hash/path-redaction policy
- collapse exact duplicates such as `stage_engine_trace.py`
- reduce module-global runner choreography
- tighten scorer/report contracts
- clean up telemetry ownership split
- regroup no-WLI package shape
- remove or clearly quarantine shim debt and historical snapshots

#### Later / post-v1 or only after more tuning evidence
- big scorer model redesigns
- major performance work beyond obvious wins
- new solver families
- broad new campaign capabilities not required for v1 coherence

### Implementation order
1. test-lock intended behaviour
2. fix correctness and privacy defects
3. unify output/artifact policy
4. introduce the core config runner and typed run spec
5. shift campaign layer to build on that runner
6. regroup repo shape and package ownership
7. remove shims and duplicate helpers
8. do tuning and speed work on the cleaned system

### Output
Create a single ordered work list with for each item:
- scope
- files/areas touched
- risk
- prerequisite
- tests needed
- done criteria

---

## Phase 5: Add and tighten tests before major refactor

### Goal
Stop structural cleanup from changing behaviour by accident.

### Highest-value test additions
#### Output/privacy tests
Add explicit tests for:
- JSONL event stream path redaction
- trace event privacy
- word-ngram asset path persistence
- no writes outside the run root
- identity-redaction pass-through

#### Runner/result contract tests
Add explicit tests for:
- run-directory identity ownership
- final result-row construction from one canonical run result
- stop-reason mapping
- scorer-report presence and shape

#### Core anti-drift tests
Tighten or restore:
- guardrail tests with commented assertions
- core enum-only rules
- strict boundary/core separation rules
- no duplicate ownership for artifact policy

#### Config-runner tests
Once the new runner exists, add:
- minimal run spec round-trip tests
- tutorial/example solves through the run spec
- LP/source-backed solves through the same entrypoint
- campaign job translation into run specs

---

## Phase 6: Run a design review before implementation starts

### Goal
Avoid coding from an unreviewed plan.

### Suggested design review agenda
1. Restate the v1 goal
2. Confirm the target architecture
3. Confirm the must-fix list
4. Confirm the config-runner direction
5. Confirm output/privacy contract ownership
6. Confirm repo-shape direction (`campaigns/`, tutorials, problem sources, reduced `tools/`)
7. Confirm what will definitely *not* be done before v1

### Review questions to force clarity
- What must remain stable for existing runs?
- What can change internally without user pain?
- Which current quirks are temporary bridge code versus actual contract?
- Do we agree that campaign should sit above core run specs?
- Is `ScorerReport` the canonical scorer summary object?
- Do we want `SolverReport` now, later, or not at all?
- Are there any scoring/tuning items that block hardening order?

### Output
One signed-off implementation brief.

---

## Phase 7: Implementation style rules for the hardening phase

### Working rules
- small, surgical changes
- tests first where behaviour is easy to destabilise
- no speculative rewrites
- no hidden defaults that affect experimental results
- no new stringly config logic in core
- no new local artifact/output helpers
- no more script-style bootstrap in first-class surfaces
- keep runtime behaviour observable and explicit

### Change review template
For every change, reviewers should ask:
- Does this reduce drift risk?
- Does this reduce code and mental load?
- Does it preserve scoring/solving fidelity?
- Does it move logic toward the right owner?
- Does it add a live guardrail if the rule matters?

---

## Phase 8: Developer feedback loop during implementation

### Goal
Keep implementation aligned without reopening architecture every day.

### Cadence
After each small phase, review:
- what changed
- what tests now prove it
- what old code can now be removed
- whether the agreed target architecture still looks right

### Good review checkpoints
1. after output/privacy policy unification
2. after must-fix runner defects are removed
3. after first working core config runner exists
4. after first campaign job runs through the core run spec
5. after repo-shape moves begin

### Each checkpoint should answer
- what got simpler?
- what got safer?
- what still looks transitional?
- what can now be deleted?

---

## Phase 9: Review the review again after first implementation slice

### Goal
Make sure the review was directionally correct.

Once the first implementation slice lands, do a small retrospective:
- Which findings were most useful?
- Which were overstated?
- Which turned out to be symptoms not root causes?
- Which structural proposals need adjustment?

This prevents the review itself becoming dogma.

---

## Phase 10: Pre-v1 sign-off gates

Before calling the repo v1-ready, explicitly sign off these areas:

### Contracts
- one clear run/config contract
- one clear campaign/job contract layered above it
- one clear artifact/output/privacy contract
- clear report/telemetry contract

### Safety and hygiene
- no raw absolute paths in persisted outputs
- no identity leaks in standard outputs
- no broken install/CI references on the release branch
- no hidden asset-selection defaults that change behaviour silently

### Architecture
- strict in core, forgiving at the boundary
- campaign is first-class and not disguised as helper tools
- `data` ownership is cleaned up
- shim debt is reduced or clearly quarantined

### Confidence
- must-fix items closed
- should-fix items either closed or consciously deferred
- tests added for the most drift-prone seams
- tutorials/examples aligned with the actual public front door

---

## Recommended immediate next actions

If you want the most practical sequence from here, I would do this next:

1. Read the collated programme and findings register once more with a red pen.
2. Mark each finding as agree / disagree / unclear / not for v1.
3. Collect developer comments directly against the register.
4. Hold one architecture decision pass to settle:
   - core config runner
   - campaign layering
   - artifact/output owner
   - report model
   - repo-shape target
5. Freeze the must-fix list.
6. Define the first implementation slice:
   - output/privacy fixes
   - run-config persistence fix
   - run-directory identity fix
   - asset-default fix
7. Add or repair the guardrail tests needed for those items.
8. Only then begin code changes.

---

## My recommendation in one sentence

The next phase should be a **reviewed, developer-informed hardening programme** built around one core run spec, one campaign layer above it, one artifact/output/privacy owner, and explicit anti-drift rules enforced by live tests.
