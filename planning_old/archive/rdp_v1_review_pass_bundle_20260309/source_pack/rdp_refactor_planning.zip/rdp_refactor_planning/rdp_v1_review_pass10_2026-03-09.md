# RDP v1 engineering review – pass 10 (whole-codebase simplification map)

Date: 2026-03-09
Surface reviewed: local `src_test_bench_nobloat__20260309T161023Z.zip` bundle (`src`, `tests`, benchmark subtrees)

## Scope of this pass

This pass shifts from individual bugs into a broader codebase view:
- where active code is still carrying alpha-era structure
- where output / hashing / path rules are duplicated
- where benchmark-side abstractions are now over-sliced
- where scorer/report integration exists but is still split across local channels

## New confirmed findings

### 1) The benchmark side still has several active canonical-JSON / hashing policies

Confirmed active implementations:
- `tools/benchmarks/community/_campaign_common.py:21-55`
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py:90-125`
- `tools/benchmarks/scoring/span_hamming_nose/schema.py:89-104`
- `tools/benchmarks/periodic_sub_trans/no_wli/verify_iteration_audit_chain.py:49-72`

Why this matters:
- community normalises floats to 12 significant digits before hashing
- no-WLI sanitises non-finite floats to `None`
- span-hamming nose has its own canonical JSON path again
- audit verification has a private `_sanitize/_canonical_json` path again

This is not just harmless duplication. These functions are close enough to look “the same”, but not actually the same. That is exactly the kind of drift that later creates very awkward integrity mismatches.

v1 judgement:
- **should-fix before v1**
- create one shared benchmark artifact / integrity utility layer
- allow thin wrappers only where file-family-specific policy genuinely differs

### 2) `no_wli` is now over-sliced for active maintenance

Measured from the active tree excluding `old/`:
- 89 active Python files
- 66 of those are 200 lines or fewer
- 27 are 100 lines or fewer

Largest files still hold the real behaviour:
- `stage2_search.py`
- `stage3_two_phase.py`
- `runner_bridges.py`
- `stage3_iteration_flow.py`
- `runner_bindings.py`
- `runner.py`

Interpretation:
- there is some real modularity benefit here
- but the tree has crossed the line where too many tiny bridge modules now add navigation cost and make the runtime harder to reason about

v1 judgement:
- **should-fix before or during v1 hardening**
- do a keep / merge / delete pass over active `no_wli`
- keep heavy domain modules split where they represent real stage logic
- merge bridge-style files whose job is mostly argument shuffling and state threading

### 3) Some benchmark helper files are exact or near-exact duplicates and should be merged now

Exact duplicate confirmed:
- `tools/benchmarks/periodic_sub_trans/no_wli/stage_engine_trace.py`
- `tools/benchmarks/periodic_sub_trans/col_then_sub/stage_engine_trace.py`
- `tools/benchmarks/periodic_sub_trans/sub_then_col/stage_engine_trace.py`

These are byte-for-byte identical.

Near-duplicate confirmed:
- `tools/benchmarks/periodic_sub_trans/col_then_sub/stage_engine_iteration_bridge.py`
- `tools/benchmarks/periodic_sub_trans/sub_then_col/stage_engine_iteration_bridge.py`

The main differences are type names, stage labels, and default policy id text. The execution shape is otherwise the same.

v1 judgement:
- **easy should-fix**
- `stage_engine_trace` should become one common helper immediately
- the two flavour iteration bridges should be merged behind a small stage-label mapping unless there is a strong future divergence plan

### 4) Path handling is still inconsistent across benchmark code

The no-WLI benchmark already has explicit repo-relative redaction helpers in `path_hash_utils.py:23-51` and tests for redacting external absolute paths in `tests/tools/test_no_wli_path_privacy.py`.

But the run-config builder still writes the word-ngram report SQLite path straight into the persisted config as a raw string:
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py:209-224`

This is inconsistent with the span asset handling in the same benchmark family.

v1 judgement:
- **must-fix if public bundle / reproducibility / privacy matter**
- run-config output should apply one uniform repo-relative path policy to every asset-like path

### 5) `scorer_report` exists, but benchmark reporting is still split into local channels

Confirmed surfaces:
- core report type: `src/rune_decrypter_prime/scoring/scorer_report.py`
- builder: `src/rune_decrypter_prime/scoring/scorer_report_builder.py`
- sidecar JSONL helper: `tools/benchmarks/periodic_sub_trans/common/scorer_sidecar.py:55-84`
- no-WLI nested use: `tools/benchmarks/periodic_sub_trans/no_wli/word_ngram_report.py:144-151`
- gate-0 preflight sidecar path: `tools/benchmarks/periodic_sub_trans/common/bench_solve_periodic_columnar_kaeding.py:1277-1291`

Interpretation:
- the report model is real
- but the benchmark still uses it in at least two different ways:
  - JSONL sidecar rows in the common benchmark path
  - nested `scorer_report` payloads inside no-WLI word-ngram report rows

That is workable, but not yet one obvious benchmark-wide report contract.

v1 judgement:
- **should-fix by contract decision**
- decide whether `ScorerReport` is:
  1. the canonical benchmark scorer-report shape everywhere, or
  2. only an internal helper for selected sidecars
- after that, remove the mixed signalling

### 6) The scoring base still carries transition debt

Confirmed in `src/rune_decrypter_prime/scoring/base_scorer.py`:
- legacy string objective parsing helpers remain (`parse_objective`, `normalize_objective`)
- `_require_objective_pct_logp_win()` expects an ObjectiveSpec-like contract
- `telemetry()` is defined twice in the same class body (`122-124` and `216-218`)

This does not prove a runtime bug on its own, but it does show the core scoring contract has not fully converged to one internal shape.

v1 judgement:
- **should-fix before freezing scorer interfaces**
- choose one internal objective contract for scorer internals
- keep adapter logic at boundaries only
- remove duplicated base-layer methods

### 7) Tooling around span-hamming still contains a lot of local one-off path helpers

Within `tools/benchmarks/scoring/span_hamming_nose`, multiple scripts define their own `_resolve_repo_path(...)` helper instead of importing one shared benchmark path utility.

Confirmed examples:
- `report_nowli_hard_case_sources_v2.py`
- `report_span_hamming_nose_suite.py`
- `build_span_hamming_nose_assets_v1.py`
- `build_span_hamming_nose_assets_wordlen_v1.py`
- `bench_span_hamming_timing_local.py`
- `bench_span_hamming_lm_usage_local.py`
- `report_nowli_hard_cases_v1.py`
- `report_nowli_hard_cases_review_policy_v1.py`
- `build_span_hamming_nose_assets_v1_RTL.py`

Interpretation:
- this is not the highest-risk correctness issue
- but it is clear tooling-level bloat and an indicator that the scoring benchmark side has grown faster than its shared utilities

v1 judgement:
- **later or opportunistic clean-up**
- consolidate low-risk path and output helpers across scoring benchmark scripts

## Updated priority buckets

### Must-fix before v1
1. Stop double-writing `run_config.json` in no-WLI config persistence.
2. Replace brittle run-directory inference in community single-job execution with an explicit run id / run dir handoff.
3. Apply repo-relative / redacted path policy to `WORD_NGRAM_REPORT_SQLITE_PATH` in persisted output.
4. Stop mtime-based auto-selection of word-ngram SQLite assets as a release default.

### Strong should-fix before v1
1. Merge the duplicated benchmark JSON / JSONL / hashing / integrity utilities.
2. Collapse exact duplicate `stage_engine_trace.py` files into one common module.
3. Merge or simplify flavour iteration bridges where only labels differ.
4. Converge the internal scoring objective contract in `BaseScorer`.
5. Decide and document the canonical role of `scorer_report` in benchmark outputs.
6. Do a keep / merge / delete pass over active `no_wli` bridge modules.

### Later / after v1 if needed
1. Broader tidy-up of span-hamming benchmark script helpers.
2. Wider repo-shape clean-up outside the hottest benchmark paths.
3. Speed work after contracts and output policies are stable.

## Suggested next review passes

1. Whole-codebase **findings register** with severity and file touchpoints.
2. Explicit **v1 cleanup programme** in execution order.
3. First-cut **merge map** for `no_wli` active files: keep / merge / move / delete.
4. Separate **speed-optimisation review** only after the contract cleanup map is fixed.

## Current overall judgement

The repo does not mainly look blocked by missing features now. It looks blocked by convergence work:
- too many local artifact/output policies
- too many small bridge modules in the benchmark runtime
- a few brittle persistence and privacy details
- scorer/report integration that exists, but is not yet expressed as one simple contract

That is a good place to be before v1, because it means the work now is mostly hardening, simplification, and convergence rather than invention.
