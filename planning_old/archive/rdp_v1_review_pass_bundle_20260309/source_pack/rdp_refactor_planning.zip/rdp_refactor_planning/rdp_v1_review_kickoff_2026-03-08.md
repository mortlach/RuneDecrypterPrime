# RDP v1 engineering review kickoff — merge branch

Date: 2026-03-08
Branch surface: `experimental/merge`
Source of truth for this session: `repo_links.csv`

## 1. Review frame

This review is being run as a release-hardening review, not a feature-design pass.

Primary goals:
- make contracts explicit
- check docs/config/implementation/tests for drift
- find duplicated logic and local one-off patterns
- identify implicit bugs and determinism risks
- propose the smallest safe consolidation path towards v1

## 2. Inventory snapshot

From `repo_links.csv`:
- surfaced files: 1,134
- all surfaced links point at branch `experimental/merge`
- notable areas:
  - `src/rune_decrypter_prime/`: 206 files
  - `tools/benchmarks/community/`: 30 files
  - `tools/benchmarks/periodic_sub_trans/no_wli/`: 98 files
  - `tools/benchmarks/periodic_sub_trans/common/`: 24 files
  - `tools/benchmarks/periodic_sub_trans/col_then_sub/`: 7 files
  - `tools/benchmarks/periodic_sub_trans/sub_then_col/`: 6 files

Immediate implication:
- the `no_wli` benchmark path is already large enough to justify a dedicated consolidation pass.

## 3. Anchor files inspected in this first pass

Documentation / release framing:
- `docs/README.md`
- `src/rune_decrypter_prime/README.md`
- `docs/appendices/determinism_checklist.md`
- `docs/guides/outputs.md`
- `tools/benchmarks/README.md`
- `tools/benchmarks/community/README_runner.md`

Benchmark community / campaign:
- `tools/benchmarks/community/_campaign_common.py`
- `tools/benchmarks/community/_run_single_job.py`
- `tools/benchmarks/community/profile_catalog_v1_1.json`
- `tools/benchmarks/community/schemas/manifest_schema_v1_1.json`
- `tests/community/test_campaign_schemas_v1_1.py`
- `tests/community/test_run_single_job_config_v1_1.py`

Periodic benchmark I/O / runner:
- `tools/benchmarks/periodic_sub_trans/common/io_reports.py`
- `tools/benchmarks/periodic_sub_trans/common/trace_writer.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
- `tests/tools/test_periodic_sub_trans_runner_fixed_seed_parity.py`

## 4. Early findings

### F1 — release-signal drift between top-level docs and package README
Severity: medium
Type: contract / release-positioning drift

Evidence:
- `docs/README.md` presents the project as `Rune Decrypter Prime (v1)` with stable interfaces, deterministic behaviour, and reproducible runs.
- `src/rune_decrypter_prime/README.md` still presents the package as `Friendly Tester Preview (v0.1.0)` and says some variation may still occur.

Why it matters:
- for a v1 release, the repo should speak with one voice about maturity, determinism expectations, and supported surfaces.
- this is exactly the sort of docs/contract drift that causes downstream confusion for users and contributors.

Recommended action:
- choose one release posture and update all user-facing README surfaces to match it.
- add one small test or docs check that the primary README/version surfaces agree on release family and maturity wording.

### F2 — file-writing policy is already split across multiple local implementations
Severity: medium
Type: consolidation candidate / output contract risk

Evidence:
- `tools/benchmarks/periodic_sub_trans/common/io_reports.py` provides `write_json`, `write_csv_rows`, `append_csv_row`, and snapshot writing.
- `tools/benchmarks/community/_campaign_common.py` provides its own `write_json` and `write_jsonl` with different serialisation choices.
- `tools/benchmarks/periodic_sub_trans/common/trace_writer.py` provides another JSONL append path with its own serialisation choices.
- `docs/guides/outputs.md` says output layout is part of the telemetry contract and that everyone should write to predictable folders.

Why it matters:
- serialisation policy is not one thing here. The code already differs on `sort_keys`, `ensure_ascii`, newline handling, and append/write style.
- that may be justified in some cases, but at minimum the policy is not centralised or named clearly.
- this is a good v1 clean-up target because it affects reproducibility, output diffs, and maintenance burden.

Recommended action:
- define a small output-writing policy layer with named modes, for example:
  - pretty JSON file
  - canonical JSON file
  - canonical JSONL append
  - CSV snapshot / CSV append
- keep the specialised call sites, but make the serialisation rules come from one place.
- add focused tests that lock formatting-sensitive behaviour where reproducibility matters.

### F3 — community single-job runner picks run directories by before/after directory diff
Severity: medium
Type: implicit bug risk

Evidence:
- `tools/benchmarks/community/_run_single_job.py` records pre-run and post-run flavour directories, then chooses the newest new directory; if none are new, it falls back to the lexicographically last existing directory.

Why it matters:
- this is fragile if two runs share the same flavour output root or if a rerun reuses existing directories unexpectedly.
- the fallback of “latest existing directory” is not a strong ownership signal for the run that just happened.

Recommended action:
- prefer an explicit run identifier returned or written by the pipeline entrypoint.
- if that is not available yet, add a focused test covering the no-new-directory case and concurrent-existing-directory ambiguity.

### F4 — benchmark campaign tests look useful, but they currently lock only slices of the contract
Severity: low-medium
Type: test-scope gap

Evidence:
- `tests/community/test_campaign_schemas_v1_1.py` checks required files, schema validity, and example JSON parsing.
- `tests/community/test_run_single_job_config_v1_1.py` checks campaign job configuration behaviour and selected result-row behaviour.
- `tests/tools/test_periodic_sub_trans_runner_fixed_seed_parity.py` gives a useful fixed-seed parity check for the two main periodic runner flavours.

Why it matters:
- these are good tests, but they do not yet fully lock the higher-level campaign contract around run-directory ownership, result mapping edge cases, and the output-writing policy split identified above.

Recommended action:
- keep these tests as the base.
- add narrow tests around:
  - run-directory selection ownership
  - status/stop-reason mapping edge cases
  - output writer formatting policy
  - campaign result reproducibility fields

### F5 — the `no_wli` runner surface is large enough to justify a dedicated simplification pass
Severity: medium
Type: maintainability / layout risk

Evidence:
- `repo_links.csv` surfaces 98 files under `tools/benchmarks/periodic_sub_trans/no_wli/`.
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py` is now a slim entry module, but it imports a large number of `*_external`, `*_entrypoint`, state-init, defaults, startup, sweep, and summary helpers.

Why it matters:
- this may be the right shape after de-monolithing, but it now deserves an explicit review of whether the split is domain-driven or just history-driven.
- for v1, too many micro-modules can become a maintenance tax even if each file is individually tidy.

Recommended action:
- do a no-WLI module map in the next pass:
  - state and defaults
  - campaign configuration
  - startup/bootstrap
  - execution
  - output/reporting
- then decide which splits are earning their keep and which can be re-merged.

## 5. Tests I would add early

1. `tests/community/test_run_single_job_run_dir_selection.py`
- lock the correct run-directory selection behaviour when multiple candidate directories exist.

2. `tests/tools/test_output_writer_policy.py`
- lock canonical JSON vs pretty JSON vs JSONL append behaviour in one shared place.

3. `tests/docs/test_release_surface_consistency.py`
- ensure the main release-facing README/version wording is internally consistent.

4. `tests/community/test_result_row_mapping_edge_cases.py`
- cover skipped/autoskip and ambiguous stop-reason mapping explicitly.

## 6. Next review stages

### Stage A — benchmark campaign deep review
Focus:
- `_run_single_job.py`
- shard/bootstrap/manifest flow
- schema and profile catalogue
- result mapping and integrity-chain logic

### Stage B — cross-cutting output and telemetry policy
Focus:
- all output writers
- logging and telemetry helpers
- docs/output contract

### Stage C — no-WLI simplification map
Focus:
- determine which files express real domain boundaries and which are accidental fragmentation

### Stage D — repo-shape consolidation proposals
Focus:
- move/merge/delete candidates
- target directory shape for v1

## 7. Unverified in this first pass

These need more inspection before I will make stronger claims:
- the full campaign shard/bootstrap flow beyond `_run_single_job.py`
- whether `col_then_sub` and `sub_then_col` duplicate substantial runner logic or only small flavour-specific logic
- how far the telemetry/output policy split extends outside the benchmark tools
- whether there are dormant legacy paths that should be removed before v1
