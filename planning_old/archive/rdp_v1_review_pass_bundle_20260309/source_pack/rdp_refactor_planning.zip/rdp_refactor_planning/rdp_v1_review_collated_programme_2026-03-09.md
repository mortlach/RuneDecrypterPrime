# RDP v1 engineering review — collated programme
_Date: 2026-03-09_

## Scope

This collates the review passes over the merge branch and the later full repo ZIP review. It covers:

- core runtime and API surfaces
- scoring, scorer reports, telemetry, logging, output policy
- benchmark / campaign infrastructure
- no-WLI, WLI, periodic-sub-trans runners
- repo structure, tutorials/examples, fixtures/problem sources
- install / packaging / outer release surface (from the later full repo ZIP)

This is a **static engineering review**. It is strong on contracts, ownership, drift, duplication, privacy, and architectural convergence. It is **not** a full runtime proof because the review bundle excluded large data assets.

## Executive judgement

RDP now looks like a **finishing-phase project**, not an exploration-phase project.

The repo does **not** mainly look blocked by missing capabilities. It looks blocked by:

- incomplete convergence of ownership and contracts
- duplicated output / hashing / path / JSONL policy
- benchmark and community infrastructure still living as script-style glue
- too many local defaults and copied config dict patterns
- a missing first-class **core config runner / RunSpec**
- a missing single **artifact/output/privacy policy owner**
- a still-split story across core runtime, campaign tooling, fixtures/problem sources, and tutorials

That is good news. It means the path to v1 is mostly **hardening, simplification, debloating, and proving**, not broad new invention.

## High-level recommendation

Build toward this target:

1. **One first-class core config runner**
   - strict serialisable `RunSpec`
   - one canonical solve entrypoint
   - suitable for tutorials, LP solved pages, API use, GUI/web front ends, and campaign jobs

2. **One outer experiment/campaign system**
   - probably under `campaigns/`, not `tools/benchmarks/`
   - wraps the core `RunSpec` rather than inventing a second solve-description system
   - supports WLI and no-WLI as the same outer run/job model with different inner policies

3. **One artifact/output/privacy policy**
   - canonical JSON
   - JSONL
   - hashing
   - path redaction
   - identity redaction
   - telemetry dump placement
   - run-root ownership
   - console / screen-output contract

4. **Strict in core, forgiving at the boundary**
   - enums in core
   - strings and loose serialised forms only at the boundary
   - live guardrail tests to stop drift

5. **Typed summary reports layered over telemetry**
   - keep `ScorerReport`
   - likely add a narrow `SolverReport`
   - do not replace telemetry with reports
   - use reports as stable downstream summary objects

---

## Findings register

Severity meanings used below:

- **Must-fix**: should be fixed before a serious v1 release branch is declared ready
- **Should-fix**: high-value convergence / simplification work for v1 if possible
- **Later**: desirable, but not required to start v1 hardening

| ID | Priority | Area | Finding | Why it matters | Recommended direction |
|---|---|---|---|---|---|
| F01 | Must-fix | Output / benchmark | `run_config.json` is written twice in no-WLI before and after payload mutation | Partial-write and ownership ambiguity in release-facing benchmark path | Build payload fully, then write once |
| F02 | Must-fix | Campaign bridge | Community single-job helper infers output run-dir by before/after directory diff and latest-dir fallback | Brittle run ownership; easy to mis-bind results | Make run identity explicit and returned by the called run |
| F03 | Must-fix | Privacy / paths | `WORD_NGRAM_REPORT_SQLITE_PATH` can persist as raw path in run config | Path leakage and inconsistent redaction policy | Route through one artifact/path policy |
| F04 | Must-fix | Defaults / reproducibility | Word-ngram asset auto-discovery chooses newest file by mtime and auto-enables feature | Silent behaviour drift between working copies | Require explicit asset selection in release-facing runs |
| F05 | Must-fix | Release surface | Docs/CI/repo refer to `tools/ci/install_smoke.py`, but it is missing from reviewed GitHub branch ZIP | Real install/release break on that branch | Restore file or remove references before release |
| F06 | Must-fix | Output / privacy | JSONL event stream still records absolute trace paths; privacy stronger in META/logging than in events | Inconsistent data-protection contract | Redact all persisted paths through one policy owner |
| F07 | Must-fix | Output / privacy | `redact_identity` exists in core logging but boundary normaliser drops it | Public contract not truthful; risk of identity leakage | Pass through and test boundary-to-core logging config |
| F08 | Must-fix | Anti-drift tests | Some guardrail tests have their key assertions commented out | Policy exists on paper but not in enforcement | Make guardrail tests genuinely live or delete them |
| F09 | Must-fix | Core dependency direction | `RunConfig` default seed depends on `data.cipher_tests.baseline_registry` | Core runtime depends on fixture/test material | Move default seed to core-owned settings, split fixtures out of core |
| F10 | Must-fix | Campaign schema | Community campaign schema excludes `no_wli` by schema even though broader benchmark code knows about it | Structural mismatch blocks unified campaign model | Generalise campaign job model beyond two WLI order variants |
| F11 | Should-fix | Core API | No single serialisable public `RunSpec`; top-level run story split across `RunAPI`, `RunConfig`, pipeline seam | Missing front door; blocks config runner, GUI, tutorial coherence | Introduce first-class strict `RunSpec` and config runner |
| F12 | Should-fix | Scoring contract | Core scoring contract still transitional: legacy string objective handling mixed with newer spec-driven path | Incomplete convergence; more room for drift | Keep forgiving parsing at boundary, strict objective spec in core |
| F13 | Should-fix | Base scorer | `BaseScorer` defines `telemetry()` twice | Telling base-layer drift; review noise | Remove duplicate and clean base interface |
| F14 | Should-fix | Scoring reports | `word_ngram_report` depends on mutable scorer state (`last_stats()`) after scoring | Weaker pass-through contract; less robust report semantics | Return explicit report/result object from scorer path |
| F15 | Should-fix | Scoring role design | Benchmark-specific scorer roles are expressed through copied config dicts and widening `ScoringConfig` | Core config becoming a policy sink | Introduce explicit scorer role specs at campaign/run boundary |
| F16 | Should-fix | Reports / telemetry | `ScorerReport` is real but not yet one fully canonical downstream reporting contract | Good abstraction not fully converged | Keep `ScorerReport`; standardise where it is emitted/embedded |
| F17 | Should-fix | Reports / telemetry | No compact canonical solve-summary object; stop reasons/progress spread across telemetry, solver-local strings, community mapping | Harder to reason about outcomes, APIs, campaigns | Add narrow `SolverReport` built from result + final telemetry |
| F18 | Should-fix | Artifact policy | Multiple active canonical-JSON / hashing / JSONL / path-redaction implementations exist | Hidden drift, duplicated effort, inconsistent privacy | Create one shared artifact/output policy module |
| F19 | Should-fix | Telemetry ownership | Telemetry ownership split across `telemetry/`, `core/telemetry.py`, utils helpers, deprecated shims | Blurred ownership, harder refactor path | Converge on one telemetry owner, keep shims short-lived |
| F20 | Should-fix | Console output | Benchmark/runtime console behaviour still heavily `print(...)` driven | No clear screen-output policy; hard for agents and tools to follow | Add console/report policy and reduce ad hoc prints |
| F21 | Should-fix | Repo shape | `tools/benchmarks` behaves like first-class campaign infrastructure, not auxiliary tools | Naming and ownership drift | Promote to top-level `campaigns/` or equivalent |
| F22 | Should-fix | no-WLI package | no-WLI split was justified, but current flat slicing is over-fragmented | Navigation and maintenance cost | Keep decomposition, but regroup into clearer subpackages |
| F23 | Should-fix | Duplicate helpers | `stage_engine_trace.py` duplicated verbatim across runner flavours; tests duplicated too | Easy bloat and drift target | Move to shared helper |
| F24 | Should-fix | Bridge architecture | Runners still rely heavily on `state=globals()` choreography | Missing typed runner state; harder config-runner path | Introduce typed runner-state / run-context object |
| F25 | Should-fix | Registry / extension | Cipher registration still more string/alias/wrapper driven than key-op registry | Uneven extension story | Make policy difference explicit and simplify cipher registry path |
| F26 | Should-fix | Dev naming drift | Active ciphers depend on `ciphers/dev/base_keyed_cipher.py` | `dev/` not truthful; ownership noise | Move active base class to non-dev location |
| F27 | Should-fix | Import side effects | `api/specs.py` mutates cipher registry at import time for generic map support | Weak architectural seam | Register via explicit registry setup, not import side effect |
| F28 | Should-fix | Data / fixtures | `data` package currently mixes assets, LP/problem sources, and cipher test fixtures | Wrong boundaries and dependency leaks | Split into assets/resources, problem sources, and fixtures |
| F29 | Should-fix | Tutorials/examples | Tutorials/examples/solving surface split across package-local examples, top-level tutorials, scripts | Incoherent outer user story | Align around config runner and clearer top-level surfaces |
| F30 | Should-fix | Tool scripts | Widespread `sys.path.insert(...)` bootstrap in tools/campaign code | Script-shaped repo outer surface | Thin wrappers only; push reusable logic into library/campaign packages |
| F31 | Should-fix | Logging adapter | Preferred module-logger path does not match current run logger API | Documentation/implementation drift | Either fix adapter or remove misleading path |
| F32 | Later | Repo cleanup | `core/config.py` and similar shims carry legacy commented bodies | Review clutter, but low direct risk | Remove dead commented legacy bodies |
| F33 | Later | Utility cleanup | A few duplicated small helper definitions exist (e.g. duplicate `rune_to_latin`) | Small hygiene issue | Clean during debloat phase |
| F34 | Later | `no_wli/old/` placement | Historical snapshots remain inside active package space | Search/review noise | Move historical snapshots out of active source tree |
| F35 | Later | Packaging tidy | `src/README.md` and surrounding docs still leak build/output assumptions into source tree | Outer-surface clarity issue | Tidy after core/campaign convergence |
| F36 | Later | Build/install review | Full packaging/release process still needs one final pass on the eventual release branch with all intended files present | Needed for final sign-off, but not a code-architecture blocker | Re-run outer-surface release checklist on candidate v1 branch |

---

## Must-fix before a serious v1 release attempt

These are the items I would personally block on:

1. **One-write run config**
   - fix double-write of `run_config.json`

2. **Explicit run identity**
   - stop inferring output ownership by folder diff

3. **No raw persisted sensitive paths**
   - especially word-ngram SQLite path
   - unify path redaction

4. **Deterministic explicit feature assets**
   - remove mtime-based default asset choice for release-facing runs

5. **Truthful privacy contract**
   - propagate `redact_identity`
   - redact JSONL trace paths too

6. **Live anti-drift guardrails**
   - un-comment or restore important guardrail assertions

7. **Correct dependency direction**
   - remove core default dependence on test/fixture baseline registry

8. **Release-branch install surface complete**
   - restore or remove missing install-smoke references on the actual release branch

9. **Campaign schema no longer structurally excludes no-WLI**
   - even if the first v1 campaign only uses a subset, the architecture should no longer hard-code only the two WLI order variants

---

## Should-fix for v1 convergence

These are the high-value convergence tasks that make the repo much cleaner and safer:

### A. Core front door
- introduce strict serialisable `RunSpec`
- make a first-class core config runner
- define one canonical solve-result contract

### B. Scoring and reporting
- keep `ScorerReport`
- likely add `SolverReport`
- move benchmark-local scorer intent out of core `ScoringConfig`
- introduce scorer role specs at the boundary
- clean legacy string/objective handling out of core runtime path

### C. Artifact / output / privacy
- create one artifact/output policy owner
- unify JSON / JSONL / hashing / path redaction / identity redaction / telemetry dump placement
- add console/report policy

### D. Campaign / benchmark / no-WLI
- promote benchmark/community system to first-class `campaigns/` surface
- generalise campaign job model so WLI and no-WLI share one outer run model
- replace globals choreography with typed runner state
- keep no-WLI decomposition but regroup into meaningful subpackages
- collapse exact duplicates like `stage_engine_trace.py`

### E. Repo boundaries
- split `data` into assets/problem-sources/fixtures
- move active shared cipher base out of `ciphers/dev`
- align tutorials/examples/problem-source story
- reduce `sys.path` bootstrap wrappers and direct `print(...)`

---

## Later / after v1 hardening starts

- tidy remaining shim files and commented legacy blocks
- move `no_wli/old/` out of active package space
- small utility deduplication
- secondary repo-shape cleanup after campaigns/config-runner shape settles
- a fuller packaging/release pass on the real candidate release branch

---

## Target architecture map

## 1. Core library (`src/rune_decrypter_prime/`)
Owns:
- types and enums
- cipher and key-op registries
- canonical `RunSpec`
- config runner
- solve pipeline
- engine
- solver interfaces
- scoring runtime
- telemetry event model
- typed summary reports (`ScorerReport`, likely `SolverReport`)
- artifact/output policy primitives
- problem-source interfaces (not the large problem corpora themselves)

Core policy:
- strict types
- no magic strings in core storage
- no fixture/test dependencies for defaults
- no branch-local benchmark assumptions

## 2. Campaign system (`campaigns/` preferred)
Owns:
- distributed experiment orchestration
- job manifests
- fixture assignment
- shard/job identity
- result aggregation
- campaign-only sweeps and comparison workflows
- campaign wrappers over core `RunSpec`

Campaign policy:
- serialisable at the boundary
- typed internally
- same outer job model for WLI and no-WLI
- benchmark-local scorer roles compiled into core scorer configs

## 3. Problem sources / fixtures
Owns:
- LP locators and corpus-backed sources
- solved-page fixtures
- test/tutorial fixture material
- other reusable named input sources

Policy:
- separate reusable problem-source logic from large assets and from test-only fixtures

## 4. Tutorials
Owns:
- human-facing examples
- walkthrough solves
- worked solved-page examples
- example campaign configurations

Policy:
- should use the same config-runner/front-door model as real runs

## 5. Tools
Owns only:
- genuinely auxiliary helper scripts
- repo-maintenance conveniences
- personal/dev helper surfaces that are not part of product contract

---

## Recommended internal policies to make explicit

These should become written and tested internal rules:

1. **Strict in core, forgiving at the boundary**
2. **Enums only in core storage**
3. **No raw absolute paths in persisted outputs**
4. **No writing outside the active run root without explicit artifact policy**
5. **No self-initialising logger/output owners**
6. **No module-global runner state for first-class run paths**
7. **No benchmark-only policy tokens stored as raw core config shape when they can live as boundary role specs**
8. **Every important anti-drift rule gets a live guardrail test**
9. **One owner for JSON / JSONL / hashing / path redaction / identity redaction**
10. **Scripts are thin wrappers; reusable logic lives in core or campaigns**

---

## Ordered v1 hardening programme

## Phase 1 — Release blockers and safety
- fix double-write run config
- explicit run identity from runs
- unify path redaction on persisted config/artifacts
- remove mtime-driven default asset selection for release-facing runs
- propagate `redact_identity`
- redact JSONL trace paths
- restore live guardrail tests
- restore or remove broken install-smoke references on the actual release branch

## Phase 2 — Converge ownership
- introduce shared artifact/output/privacy policy
- converge telemetry owner and remove misleading logging adapter paths
- split `data` into clearer owners
- move active cipher base out of `dev/`
- clean import-side-effect registration seam

## Phase 3 — Config runner / run model
- define strict serialisable `RunSpec`
- implement first-class core config runner
- define one canonical solve-result contract
- add narrow `SolverReport`
- formalise scorer role specs at the boundary

## Phase 4 — Campaign convergence
- move benchmark/community infrastructure toward top-level `campaigns/`
- generalise campaign schema beyond two WLI flavours
- replace bridge/globals choreography with typed runner state
- integrate no-WLI under same outer job model with differing internal policy

## Phase 5 — Debloat and simplification
- collapse exact duplicates
- regroup no-WLI into subpackages
- reduce sys.path wrappers and direct print usage
- move historical snapshots out of active package space
- clean shims and commented legacy bodies

## Phase 6 — Tuning, proving, release candidate
- parameter tuning and hard-problem campaigns
- explicit reproducibility checks
- final packaging/install/release pass on the actual candidate branch
- final review of docs/tutorials against the converged config-runner model

---

## My current architecture view in one sentence

**RDP should converge on one strict core solve system, one first-class config runner, one campaign system above it, one artifact/privacy policy, and a small set of typed reports layered over telemetry.**

---

## Questions to review together before implementation

1. Do you want the top-level experiment surface named `campaigns/`, `benchmarks/`, or something else?
2. Do you want `RunSpec` to be JSON-first, Python-dataclass-first, or both with one canonical serialisation?
3. Should `SolverReport` be part of the first config-runner slice, or added just after?
4. How much no-WLI runner policy should become shared with WLI in v1, versus just sharing the outer job model first?
5. Do you want to move LP solved pages under tutorials, problem sources, or keep both views?
6. Which release branch will be the real packaging/install review surface once the missing root files are restored?

