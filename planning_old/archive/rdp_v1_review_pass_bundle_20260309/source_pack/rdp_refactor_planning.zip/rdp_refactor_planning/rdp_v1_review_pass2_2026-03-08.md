# RDP v1 review – pass 2 (benchmark campaign + cross-cutting I/O)

Date: 2026-03-08
Branch surface: `experimental/merge` from `repo_links.csv`
Review mode: evidence-led, v1 hardening, no feature push

## Scope of this pass

This pass went deeper into:
- community benchmark campaign flow
- cross-cutting result/output writing
- no-WLI runner structure
- test coverage around these areas

Primary files inspected locally from surfaced raw links:
- `tools/benchmarks/community/_campaign_common.py`
- `tools/benchmarks/community/_run_single_job.py`
- `tools/benchmarks/community/run_shard.py`
- `tools/benchmarks/community/combine_results.py`
- `tools/benchmarks/community/aggregate_results.py`
- `tools/benchmarks/periodic_sub_trans/common/io_reports.py`
- `tools/benchmarks/periodic_sub_trans/common/trace_writer.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
- `tests/community/test_run_single_job_config_v1_1.py`
- `tests/community/test_campaign_schemas_v1_1.py`
- `tests/tools/test_no_wli_runner_defaults_word_ngram.py`
- `tests/tools/test_no_wli_path_privacy.py`

---

## Main findings

### F4. JSON/file-writing policy is fragmented across the benchmark stack

Severity: High
Type: consolidation + implicit bug risk

There are at least four distinct JSON-writing policies in the surfaced benchmark code:

1. `tools/benchmarks/community/_campaign_common.py`
   - `write_json(...)` writes `indent=2`, `sort_keys=True`, `ensure_ascii=True`, and adds a trailing newline.
   - `write_jsonl(...)` writes compact sorted JSON with `ensure_ascii=True`, `allow_nan=False`.
   - Lines: 62-85.

2. `tools/benchmarks/periodic_sub_trans/common/io_reports.py`
   - `write_json(...)` writes `indent=2` only.
   - No `sort_keys`, no `ensure_ascii`, no trailing newline.
   - Lines: 9-11.

3. `tools/benchmarks/periodic_sub_trans/common/trace_writer.py`
   - `StageTraceWriter.append(...)` writes compact sorted JSON with `ensure_ascii=False`.
   - It does **not** pass `allow_nan=False`, so Python’s default JSON behaviour still allows NaN/Infinity spellings.
   - Lines: 19-31.

4. `tools/benchmarks/community/run_shard.py`
   - `_write_result_row(...)` writes compact sorted JSON with `ensure_ascii=True`, `allow_nan=False`.
   - Lines: 182-186.

Why this matters:
- this is exactly the kind of repeated local policy drift that becomes a maintenance trap before v1
- it weakens “output layout is part of the telemetry contract” thinking by letting serialisation rules vary by module
- invalid JSON values (`NaN`) can slip into trace output unless every caller pre-sanitises
- differences in key ordering / escaping / newline policy make tooling and review more awkward than they need to be

Recommendation:
- create one shared benchmark-output serialisation policy module with named helpers:
  - `write_json_pretty(...)`
  - `write_jsonl_rows(...)`
  - `append_jsonl_row(...)`
  - `append_trace_event(...)` (if trace must differ, make that difference explicit)
- require explicit `allow_nan=False` everywhere unless there is a documented exception
- decide one repo-wide policy for `ensure_ascii` and newline behaviour

Suggested test additions:
- a focused test that all benchmark JSON/JSONL helpers reject NaN/Infinity
- a focused test that all benchmark result/report writers use canonical key ordering where expected
- a single golden-output test for benchmark file emission

---

### F5. `_run_single_job.py` still uses a brittle “latest run dir” ownership rule

Severity: High
Type: implicit bug risk

`_pick_run_dir(...)` works like this:
- take the set difference of flavour run dirs before and after the run
- if a new directory appears, choose the lexicographically last one
- otherwise choose the lexicographically last directory from all post-run directories
- lines 147-153

Then `run_single_job(...)`:
- records `pre_dirs`
- calls `pipeline_module.main()`
- records `post_dirs`
- picks a run dir with `_pick_run_dir(...)`
- lines 313-320

Why this matters:
- if the runner writes into an existing directory, this helper may attach the job to the wrong run directory
- if multiple directories appear, the choice is by name ordering, not by explicit job identity
- if stale output is already present, the fallback path is especially fragile

This may be acceptable for a local helper during development, but it is weak for a v1 benchmark pipeline.

Recommendation:
- prefer an explicit run identifier returned by the pipeline layer, or a deterministic manifest file written by the runner itself
- if that is not possible yet, tighten the fallback rule to match on files written after the job start timestamp and verify expected per-job artefacts

Suggested test additions:
- test where `post_dirs == pre_dirs` but the intended job updated an existing run dir
- test where two new dirs appear and only one contains the current job’s artefacts
- test that stale neighbouring run dirs do not get selected

Coverage note:
- current surfaced test file `tests/community/test_run_single_job_config_v1_1.py` does check repo-relative output paths and campaign-run configuration forwarding
- I did **not** find surfaced tests that lock `_pick_run_dir(...)` behaviour directly

---

### F6. Community benchmark pipeline is well structured for validation, but there is still duplicated row-shape logic

Severity: Medium
Type: consolidation opportunity

The community campaign path has several good v1 traits already:
- manifest schema validation
- result schema validation
- row-identity checks against scheduled jobs
- per-row integrity chain
- resume verification of prior results
- deterministic collision rules during combine

Evidence in local files:
- `run_shard.py` lines 424-488 and 591-617
- `combine_results.py` lines 35-51 and 71-81
- `_campaign_common.py` lines 97-201

That said, result-row shape is still built in more than one place:
- `_default_error_row(...)` in `run_shard.py` lines 226-252
- `_build_result_row(...)` in `_run_single_job.py` lines 236-280

These are not identical by accident; they are two representations of the same result contract from different paths.

Why this matters:
- result-schema evolution becomes more expensive
- one path can drift from the other
- stop-reason/status normalisation is harder to keep consistent

Recommendation:
- lift result-row construction into one shared builder module with:
  - `build_success_result_row(...)`
  - `build_error_result_row(...)`
  - shared status / stop-reason normalisation helpers
- keep `run_shard.py` responsible for validation and integrity, not bespoke row-shape assembly

Suggested test additions:
- one shared result-row contract test used by both helper and error paths
- one test that checks both builders still satisfy `result_schema_v1_1.json`

---

### F7. `no_wli/runner.py` has crossed into orchestration bloat

Severity: Medium-High
Type: structural bloat / maintainability risk

From the surfaced inventory:
- `tools/benchmarks/periodic_sub_trans/no_wli/` contains 98 surfaced files, including an `old/` directory with 8 files.

From local inspection of `no_wli/runner.py`:
- the runner imports 23 sibling `no_wli` modules directly
- it then wires many of them back together through `globals()` state and wrapper entrypoints
- lines 1-327 overall

This is not necessarily wrong; it clearly reflects an attempt to make responsibilities testable and separable. But for v1, it now looks like the pendulum may have swung too far toward file-splitting and orchestration seams.

Why this matters:
- understanding one run path requires jumping through many tiny modules
- review cost is high
- change cost is high when behaviour spans many glue files
- global-state orchestration makes control flow harder to reason about than a typed runtime object would

Recommendation:
- keep the modular split where it protects real domain boundaries
- collapse thin glue modules where they only forward state and one helper call
- consider one explicit typed runtime/config object instead of repeated `state=globals()` wiring
- move `old/` out of the active tree if it is no longer part of the v1 story

Suggested follow-up review pass:
- build a file-by-file no-WLI simplification matrix: keep / merge / delete / move

---

### F8. Good release-facing traits already present in the community benchmark path

Severity: Positive finding
Type: keep and preserve

Several parts of the community benchmark system already look like good v1-grade engineering and should be preserved during clean-up:

- `run_shard.py` validates both manifest and result rows against schemas before trusting them
- resume mode verifies the existing integrity chain before continuing
- helper output is checked against scheduled job identity before being accepted
- `combine_results.py` applies deterministic winner selection rules
- organiser docs make validation and deterministic dedupe rules explicit

These are worth protecting while simplifying surrounding code.

---

## Test-gap summary from this pass

Highest-value missing or under-specified tests from what I inspected:

1. Direct tests for `_pick_run_dir(...)` edge cases.
2. Shared serialisation-policy tests across benchmark JSON/JSONL writers.
3. A contract test that both success and error result rows stay aligned with the schema.
4. A no-WLI structure review to identify thin wrapper modules that can be merged without losing test coverage.

---

## Recommended order of work after this pass

1. Add tests for `_pick_run_dir(...)` and serialisation policy.
2. Introduce one shared benchmark output/serialisation helper module.
3. Introduce one shared result-row builder for community benchmark outputs.
4. Run a no-WLI simplification pass with explicit keep/merge/delete decisions.
5. After behaviour is locked, clean the repo layout (including treatment of `old/`).

---

## Bottom line

The benchmark side is already showing good release discipline in schema validation, integrity chaining, and deterministic bundle combine rules.

The main v1 clean-up opportunity is now **consolidation**:
- fewer local output-writing rules
- fewer duplicated result-row builders
- less orchestration sprawl in the no-WLI tree
- stronger explicit ownership of run directories
