# RDP v1 Review – Pass 24 (2026-03-09)

## Focus of this pass

This pass stays on the holistic seam the user pointed out:
- logging
- screen output
- file writing
- telemetry dumping
- privacy / redaction
- the shape of a future "agent-safe" output contract

This is still a static engineering review against the local `src/test/bench` bundle.

---

## Main conclusion

The repo is now close enough to a coherent output system that v1 should **stop tolerating local output habits**.

The codebase needs one enforced contract for:
- where files may be written
- what gets written to stdout
- how JSON / JSONL is emitted
- how paths are normalised / redacted
- which layer owns trace files and telemetry sidecars
- how privacy flags are carried from API input to persisted artifacts

At the moment, the code still has **split ownership and some real behavioural gaps**, not just style drift.

---

## New concrete findings

### 1) `redact_identity` exists in core, but the user-facing normaliser silently drops it

File:
- `src/rune_decrypter_prime/api/logging_utils.py`

`normalize_logging_cfg(...)` filters the incoming logging dict through an allow-list, but that allow-list does **not** include `redact_identity`, even though `LoggingConfig` in core supports it.

So today:
- core logging supports identity redaction
- user-facing dict config cannot turn it on
- there is no surfaced test for this path

This is a real contract bug, not just incomplete docs.

### 2) `module_logger(...)` does not actually match the current `run_logger` API

Files:
- `src/rune_decrypter_prime/io/logging_adapter.py`
- `src/rune_decrypter_prime/io/run_logger.py`

`module_logger(...)` first tries:
- `run_logger.get_logger(name)`
- then `run_logger.RunLogger(name)`

But the actual implementations are:
- `get_logger()` takes **no** name argument
- `RunLogger(...)` only accepts keyword args like `out_dir` and `echo`

So the "prefer run_logger" path is not really live in the current code shape. In practice, the adapter falls through to stdlib logging.

That means:
- the code comments are misleading
- the I/O layer is less unified than it looks
- callers may believe they are getting project run logging when they are not

This is a good example of the kind of drift that should be cleared before v1.

### 3) `RunLogger` still records absolute trace paths into the JSONL event stream

File:
- `src/rune_decrypter_prime/io/run_logger.py`

`log_trace(...)` writes the trace file under the run directory, then logs an event:
- `{"type": "trace_written", "func": func, "path": str(path)}`

That `path` is absolute because `path` has already been resolved.

So although:
- `META.json` and `config/logging.json` are already written with repo-local paths,

`logs/app.jsonl` can still contain absolute machine paths.

That means the current privacy contract is inconsistent across output artifacts.

### 4) there are surfaced path-privacy tests, but they only cover part of the output surface

Files:
- `tests/test_logging_paths.py`
- `src/rune_decrypter_prime/core/config/logging_config.py`

The current tests check:
- `META.json`
- `config/logging.json`

They do **not** check:
- `logs/app.jsonl`
- trace events written by `RunLogger`
- telemetry dumps written via `telemetry/pipeline.py`

So one of the most important release-hardening seams still has only partial coverage.

### 5) telemetry dumping still has a second default destination outside the run-dir policy

File:
- `src/rune_decrypter_prime/telemetry/pipeline.py`

`dump_telemetry(...)` still defaults to:
- `output/telemetry/logs`

rather than the current active run directory.

That means the repo still has two output ownership stories:
- run-dir logging/config artifacts
- telemetry mirror dumping

For v1, that should be one policy.

### 6) benchmark and tooling stdout is still heavily `print(...)`-driven

Static counts from the local bundle:
- `tools/benchmarks/periodic_sub_trans/no_wli`: about **273** direct `print(...)` calls
- `tools/benchmarks/periodic_sub_trans` overall: about **421** direct `print(...)` calls
- `tools/benchmarks` overall: about **523** direct `print(...)` calls
- `src/rune_decrypter_prime` overall: about **69** direct `print(...)` calls

Not all of these are wrong. Many are build/report scripts where plain stdout is fine.

But the count is still useful because it shows stdout behaviour is not yet governed by one small, explicit contract.

That matters for:
- reproducibility
- quiet / non-interactive runs
- GUI/web wrappers
- agent-driven execution
- privacy / information exposure

### 7) there are no surfaced tests for `redact_identity`

I did not find surfaced tests that exercise `redact_identity` at all.

Given the current split ownership, this matters because the repo could easily regress on privacy behaviour without a failing test.

---

## Strongest architectural recommendation from this pass

Introduce two explicit owners:

### A) `ArtifactPolicy` / `ArtifactIO`

This should own:
- JSON writing
- JSONL writing
- canonical JSON for hashing
- repo-relative path rewriting
- redaction of filesystem paths and identity fields
- trace file placement
- telemetry dump placement
- hash / integrity sidecars if enabled

Rule of thumb:
- no module should write JSON or JSONL directly unless it is part of this layer
- no module should persist absolute paths unless the contract explicitly allows it

### B) `ConsolePolicy`

This should own:
- whether stdout is allowed
- what categories may print directly
- how progress lines are emitted
- how verbose / quiet / machine-friendly modes work
- how benchmark tools distinguish script-style console output from run telemetry

Rule of thumb:
- solver and benchmark runtime code should not casually call `print(...)`
- scripts may print, but through a tiny shared policy or helper

---

## What this means for a future agent-safe contract

The contract you want for AI agents should be short and enforceable, something like:

1. Write only under the active run root unless an explicit export target is provided.
2. Never persist absolute machine paths in result artifacts.
3. Never persist usernames, hostnames, or other identity fields unless the config explicitly allows it.
4. Route JSON / JSONL / trace writing through the shared artifact layer.
5. Route runtime console output through the shared console policy.
6. Treat telemetry as best-effort and non-throwing, but still subject to the same privacy rules.
7. Add tests for any new persisted path or identity field.

That is short enough to guide humans and agents, but concrete enough to stop drift.

---

## Priority from this pass

### Must-fix before v1
- pass `redact_identity` through `normalize_logging_cfg(...)`
- stop `RunLogger.log_trace(...)` from writing absolute paths into JSONL events
- unify telemetry dump placement with the main run-dir artifact policy
- add tests that cover privacy in JSONL/event outputs, not just `META.json`

### Should-fix
- repair `module_logger(...)` so it matches the real run logger API, or simplify it and document the truth
- decide what runtime code is allowed to print directly
- introduce one shared console/output helper for benchmark runtime

### Later
- fuller tidy of script-style reporting tools that are intentionally stdout-heavy
- optional machine-readable console modes for future GUI/web/agent wrappers

---

## Final judgement from this pass

The repo does not mainly need more logging features.
It needs **one truthful and enforceable logging/output/privacy contract**.

Right now the pieces exist, but they do not yet line up cleanly:
- core logging config knows about redaction
- user-facing logging normalisation drops it
- run-dir metadata uses relative paths
- JSONL trace events can still record absolute paths
- telemetry dumping still has a second default location
- runtime stdout behaviour is still mostly local habit

That is exactly the kind of convergence work that fits the current v1 stage.
