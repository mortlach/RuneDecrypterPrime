# RDP v1 review pass 30 — final sweep before first collation: duplicate helpers, shim debt, cleanup-safe targets

Date: 2026-03-09
Reviewer: ChatGPT
Scope: local static review of the uploaded `src_test_bench_nobloat` bundle (`src`, `tests`, benchmark/campaign subtrees).

---

## Purpose of this pass

This pass is the last broad gathering sweep before first collation.

The goal here is not to invent new architecture, but to pin down:
- duplicate helpers that are now clearly safe to collapse
- shim / compatibility debt that is still live in the repo
- cleanup targets that look low-risk and high-value for v1
- any remaining repo-shape signals that support the campaign / config-runner direction

This pass sits on top of the earlier findings about:
- scorer/report wiring
- output/privacy policy drift
- campaign vs benchmark naming drift
- no-WLI package fragmentation
- core/boundary policy enforcement

---

## Strongest new conclusions

### 1) There is now a clear class of **safe cleanup targets**

At this stage, some cleanup items are no longer speculative. They look safe enough to treat as near-certain v1 tidy work:

- collapse exact duplicate `stage_engine_trace.py` into one common helper
- move `tools/benchmarks/periodic_sub_trans/no_wli/old/` out of the active source tree
- remove large commented legacy bodies from shim modules once imports are updated
- remove obviously stale commented-out public API debris
- fix duplicate definitions like `BaseScorer.telemetry()` and `utils.runeglish.rune_to_latin()`
- re-enable or replace disabled guardrail assertions that are meant to enforce anti-drift rules

This is useful because it means the cleanup programme already has a low-risk first tranche, not just architectural work.

---

### 2) Shim / compatibility debt is still too visible in active paths

A quick repo sweep shows multiple active compatibility surfaces still shaping the codebase:

- `core/config.py` is still a temporary shim and still carries a large commented legacy body
- `core/solver_engine.py` is explicitly a compatibility shim
- `core/factory.py` is marked deprecated but still present in active source
- `core/logging_config.py` is a back-compat shim
- `io/telemetry_utils.py` is a back-compat shim and tests still import via that route
- `api/api.py` still looks mostly like commented-out compatibility debris
- several core and benchmark modules still carry older alias exports or older naming compatibility comments

The repo is not broken because of this, but the compatibility layer is still too exposed for a project moving toward v1 hardening.

My view now is:
- compatibility shims are acceptable
- but they should be **thin, truthful, and boring**
- they should not also act as places where old commented code continues to live

---

### 3) Script-style bootstrap behaviour is still widespread in campaign/scoring code

A local sweep found a large amount of script-style path bootstrapping in benchmark/campaign code.

Observed pattern:
- many scripts still do `sys.path.insert(...)` for repo root and `src/`
- this is especially common in scoring and periodic benchmark scripts

This is not surprising for one-off tooling, but it reinforces the earlier repo-shape conclusion:
- if campaign infrastructure becomes first-class, the reusable library parts should stop depending on script-style bootstrap patterns
- wrapper scripts can remain thin entrypoints, but reusable owners should live behind import-stable library modules

This matches the idea that `tools/` should shrink back to genuinely auxiliary helpers while `campaigns/` becomes a first-class area.

---

### 4) Console-output behaviour is still far too local and inconsistent

A quick sweep found a lot of direct `print(...)` use across active benchmark code, not just historical scripts.

The biggest live clusters are still in:
- `tools/benchmarks/periodic_sub_trans/col_then_sub/runner.py`
- `tools/benchmarks/periodic_sub_trans/sub_then_col/runner.py`
- `tools/benchmarks/periodic_sub_trans/common/bench_solve_periodic_columnar_kaeding.py`
- parts of active `no_wli`
- `io/run_logger.py` itself

This strongly supports the earlier output/privacy conclusion:
- RDP still lacks one truthful console/report policy
- stdout behaviour is still partly “whatever this script prints” rather than a governed contract

For v1 this matters because users, agents, and campaign automation all need predictable console behaviour, not just predictable files.

---

### 5) The repo is carrying historical runner bulk in active tree space

The `no_wli/old/` subtree alone contains about 17k lines of Python in the local bundle.

Even if it is not imported in active paths, keeping that much historical runner code inside the active benchmark package creates:
- review noise
- search noise
- grepping confusion
- mistaken duplication pressure
- a weaker sense of what is actually live

My recommendation remains:
- move it out of active source/package space
- keep it in an archive/history/planning area if you want it preserved
- do not leave it next to active runner code for v1

---

### 6) There is still evidence of placeholder abstractions

A few parts of the tree still feel like “abstraction laid down ahead of true convergence” rather than shared infrastructure that has now fully earned its place.

Examples from prior and current sweeps:
- `solvers/progress/` looks lighter than the amount of live local progress logic around it
- some compatibility wrappers still exist mostly as forwarding layers
- some bridge modules in benchmark land look closer to orchestration staging than enduring ownership boundaries

This does **not** mean the abstractions were wrong.
It means the repo is now at the point where it should re-evaluate which abstractions have become true owners and which were transitional scaffolding.

---

## Concrete cleanup-safe targets

These look like strong early wins before any heavier refactor:

### A. Exact duplicate removal
- unify `stage_engine_trace.py` across `no_wli`, `col_then_sub`, `sub_then_col`

### B. Duplicate-definition cleanup
- remove duplicate `BaseScorer.telemetry()` definition
- remove duplicate `utils.runeglish.rune_to_latin()` definition

### C. Historical bulk relocation
- move `tools/benchmarks/periodic_sub_trans/no_wli/old/` out of active package space

### D. Compatibility truthfulness cleanup
- trim commented legacy body from `core/config.py`
- clean or remove stale commented public API debris in `api/api.py`
- keep shims, but make them truly thin

### E. Guardrail repair
- re-enable or replace the key assertion in `tests/guardrails/test_only_scoring_can_say_fwd_rev.py`
- add missing tests for JSONL path privacy and identity redaction pass-through

### F. Console/output hygiene
- stop `RunLogger` from being a place that also prints ad hoc payloads
- centralise console/status messaging policy for benchmark/campaign entrypoints

---

## Broader architecture judgement after this pass

The repo continues to point toward the same final direction:

- one **core config runner / RunSpec** in RDP
- one **campaign system** above that
- one **artifact/output policy** owner
- one **strict core, forgiving boundary** policy
- typed summary reports (`ScorerReport`, probably `SolverReport`) built from telemetry and result state
- fewer bridge scripts and fewer local one-off writer/console patterns

This pass increases my confidence that the project is close to the right architecture already. The main remaining work is convergence, cleanup, and explicit ownership.

---

## Review completeness assessment after this pass

After this sweep, my estimate is:

- about **85–90%** of the useful static engineering review is now done
- about **10–15%** remains before first collation should begin

The remaining high-value work is now narrow:
1. one last boundary/examples/config-runner-readiness pass
2. one final packaging/build/install caveat pass (within the limits of the uploaded bundle)
3. then stop gathering and switch to collation

I do **not** think another many-pass open-ended scan would add proportionate value before collation.

---

## Bottom line

This pass strengthens the idea that v1 is now mostly about:
- cleanup-safe wins
- ownership convergence
- output/privacy policy unification
- campaign promotion to first-class status
- core config-runner introduction
- removal of compatibility noise that no longer helps

That is a good place to be.

The codebase does **not** look like it needs a new exploratory phase.
It looks like it needs a deliberate finishing phase.

