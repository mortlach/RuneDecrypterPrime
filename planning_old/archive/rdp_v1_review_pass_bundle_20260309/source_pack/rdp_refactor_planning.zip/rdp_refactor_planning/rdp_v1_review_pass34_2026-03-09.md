# RDP v1 review pass 34 (2026-03-09)

## Scope of this pass

This pass covers the previously missing **root/build/install/CI surface** using the full GitHub-downloaded repo ZIP (minus large data). It is the missing outer-surface check after the earlier static review passes over `src/`, `tests/`, and benchmark/campaign code.

## New high-value findings

### 1) The install-smoke contract is currently broken at the repo surface

This is the strongest new outer-surface finding.

The repo repeatedly tells users and CI to run:

- `python tools/ci/install_smoke.py`

That command is referenced in:

- root `README.md`
- `docs/setup/installation.md`
- `docs/setup/install_validation.md`
- `tools/benchmarks/community/README.md`
- `CONTRIBUTING.md`
- `.github/workflows/install-smoke.yml`

But the downloaded repo ZIP does **not** contain `tools/ci/install_smoke.py` at all.

That is a real release-surface break, not just doc lag.

### 2) The install entrypoint is still benchmark-coupled, not core-package-centred

`install.py` is very small, but it imports and delegates directly to:

- `tools.benchmarks.community.bootstrap.main`

So the top-level install story is still structurally coupled to the community benchmark bootstrap path.

That reinforces the repo-shape conclusion from earlier passes:

- first-class campaign/community infrastructure should not continue to live under a generic `tools/` identity
- the install surface is still aligned to “community benchmark first” rather than a clearer layered model such as:
  - core package/library
  - campaign system
  - auxiliary tools

### 3) Packaging is cleaner than expected, but still not a full distributable-product story

Good signs:

- `pyproject.toml` exists and is straightforward
- build backend is normal (`setuptools.build_meta`)
- Python floor is explicit (`>=3.11`)
- base dependencies are small and clear
- optional dependency groups are present (`community-runner`, `community-organiser`, `dev`, `test`)

But there are still important limitations:

- the normal install flow is still repo-root bootstrap + editable install, not a clean package-first install story
- there are no project entry points / console scripts in `pyproject.toml`
- the bootstrap flow depends on repo-relative scripts and repo layout assumptions
- the package/install story is still really about “working clone setup” rather than “clean distributable product surface”

That is not necessarily wrong for v1, but it should be stated honestly.

### 4) Requirements targets are clearer than much of the rest of the repo

`requirements/targets/` is actually one of the cleaner converged parts of the repo.

It has:

- `base.txt`
- `runner.txt`
- `organiser.txt`
- `dev.txt`
- `ci-smoke.txt`

The target inheritance is simple and readable. This is a positive example of the kind of explicit policy the rest of the repo could imitate.

### 5) The docs still describe `tools/benchmarks` as stable first-class install/runtime structure

The root `README.md`, installation docs, and bootstrap flow all treat `tools/benchmarks/community/...` as the canonical runtime/operator path.

That means the repo has already socially promoted this area to first-class status, even if the directory naming still says “tools”.

So the earlier repo-shape recommendation is strengthened:

- this area should eventually be promoted out of `tools/`
- the install/bootstrap story should then follow that new ownership model

### 6) The repo still has an inconsistent outer story for solve/tutorial/example surfaces

At repo root we now have all of these:

- `solve/` (legacy shim)
- `solving/` (active puzzle-specific/local work)
- `tutorials/`
- docs that reference package-local examples in some places

This confirms the earlier inside/outside split:

- the internal library shape is getting clearer
- the outer human-facing surface is still historically layered and wants a proper tidy-up before v1

## Updated judgement after seeing the full repo ZIP

The full ZIP does **not** change the main engineering conclusion from earlier passes.

It strengthens it.

RDP now looks like:

- a fairly mature internal codebase with convergence debt
- a benchmark/campaign system that has outgrown `tools/`
- a packaging/install surface that is better than feared, but still not fully aligned to the intended product shape
- an outer repo surface that still carries historical naming and bootstrap drift

## Most important additional v1 actions revealed by the full ZIP

### Must-fix

1. Restore or replace the missing `tools/ci/install_smoke.py` path, or remove all references immediately.
2. Make sure CI and docs point to a command that actually exists in the checked-out repo.

### Should-fix

3. Decide whether v1 is officially:
   - a repo-clone bootstrap product, or
   - a package-first install product
   and write docs to match.
4. Reduce install/bootstrap coupling to `tools/benchmarks/community/...` by moving toward a clearer first-class campaign path.
5. Add a cleaner public entrypoint story (eventually via the core config runner / run spec).

### Later but important

6. Unify the outer “solve / solving / tutorials / examples” surface.
7. Promote campaign infrastructure out of `tools/`.
8. Revisit console-script entry points once the config-runner contract is ready.

## Review status after this pass

This pass fills the biggest missing surface from the earlier review.

My updated assessment is now:

- the useful **static engineering review is effectively complete**
- the main remaining work should now be:
  - collate findings
  - group into must-fix / should-fix / later
  - compare against intended architecture and original spec drift
  - define the v1 hardening and convergence programme

I do not think another long raw-finding pass is the best use of effort now.
