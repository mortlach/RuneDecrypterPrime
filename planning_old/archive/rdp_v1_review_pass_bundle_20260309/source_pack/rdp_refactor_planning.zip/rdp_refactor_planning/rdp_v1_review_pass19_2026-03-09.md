# RDP v1 review — pass 19 (data package, assets, loaders, extension seams)

## Scope of this pass

This pass focuses on the parts you just called out:

- whether the current `data` package still belongs where it is
- how asset paths, LP fixtures, and test baselines are currently mixed together
- whether that mix is leaking into core runtime code
- the remaining cipher / key-op extension seams that still look architecturally untidy

This is still a **static engineering review** over the uploaded local bundle, not a runtime verdict.

---

## Main conclusion

I agree with you: the current `data` package wants to be **split and renamed**.

The problem is not just that it is “outside core” in some vague sense. The sharper issue is that the current `data` namespace appears to carry **three different responsibilities at once**:

1. **runtime asset-location policy**
   - asset path resolution helpers
   - default packaged locations for language-model, hamming, LP transcript, and wordlists

2. **problem / fixture sources**
   - Liber Primus transcript, adapters, routes, registries, sections, partitions

3. **test / tutorial baselines**
   - cipher test plaintexts
   - baseline registry defaults

Those are not one thing.

That is why the current package feels wrong: it is mixing “where packaged assets live”, “how to load a concrete problem source”, and “test fixtures / defaults for examples” under one broad `data` label.

---

## Strongest new concrete findings

### 1. Core runtime still depends on test-baseline data

`src/rune_decrypter_prime/core/config/run.py` imports `BASELINE` from
`rune_decrypter_prime.data.cipher_tests.baseline_registry` and uses that to set the default run seed.

That is the clearest wrong dependency direction I have seen so far in core runtime code.

A core run-config default should not depend on a test / tutorial baseline package.

### 2. Generic API helpers are still LP-specific in practice

`src/rune_decrypter_prime/api/data_helpers.py` is a generic-looking API helper surface, but it is almost entirely a Liber Primus loader / adapter façade:

- section loading
- master transcript loading
- payload extraction from locators / partition entries

That points to a missing boundary.

This does not want to live as a generic “data helpers” concept in the API layer. It wants to sit behind a more explicit **problem source / fixture source** boundary.

### 3. Asset-path policy is currently coupled to the `data` namespace

`src/rune_decrypter_prime/scoring/hamming/loader.py` and
`src/rune_decrypter_prime/scoring/language_model/paths.py` both import path-resolution helpers from `rune_decrypter_prime.data.asset_paths`.

That suggests the current `data` package is also acting as the owner of packaged-asset location policy.

That is better than scattering path logic everywhere, but the ownership label is wrong. This is not really “data”; it is **asset / resource location policy**.

### 4. Tests already encode a packaged-assets contract

`tests/guardrails/test_data_defaults_use_assets.py` asserts that the default LM root, hamming root, wordlists root, and LP master transcript all resolve under `assets/`.

That is good. It means the repo already has a release-facing contract around packaged defaults.

It also means any split or rename must preserve that contract explicitly.

### 5. The active cipher extension path still uses import-time side effects

`src/rune_decrypter_prime/api/specs.py` still imports `rune_decrypter_prime.ciphers.generic_map_cipher` just for side-effect registration.

That is workable, but it is not the cleanest v1 extension story.

### 6. “dev” is still partly active, not really experimental

From the current code surface, active ciphers still depend on `ciphers/dev/base_keyed_cipher`, and some dev-labelled cipher/key-op modules are still registered.

So the current `dev` naming is misleading.

That is not just cosmetic. It makes the architecture harder to explain.

---

## What I think the package split should become

I would not do a huge rewrite here. I would do a **small, explicit ownership split**.

### A. Asset / resource policy

Owns:
- repository-relative packaged asset discovery
- asset root resolution
- path display / redaction for errors and logs

This should be something like:
- `rune_decrypter_prime.assets`
- or `rune_decrypter_prime.resources`

Personally I think `assets` is the clearer name because the tests already speak in those terms.

### B. Problem sources / corpus-backed fixtures

Owns:
- Liber Primus transcript loading
- LP locators, routes, partitions, adapters
- future problem-source loaders beyond LP

This wants to sit under something like:
- `rune_decrypter_prime.problem_sources`
- or `rune_decrypter_prime.fixtures`

I would favour `problem_sources` for runtime-facing loaders and `fixtures` only for explicit test/tutorial material.

### C. Test baselines and tutorial fixtures

Owns:
- `cipher_tests`
- sample plaintexts
- example baseline defaults used by tests/tutorials only

This should not be a runtime dependency. It should live under a clearly test/example-facing namespace.

---

## My preferred final shape

If I had to pick the cleanest long-term shape now, it would be this:

- `rune_decrypter_prime.assets`
  - asset path resolution
  - packaged default roots

- `rune_decrypter_prime.problem_sources`
  - `liber_primus/...`
  - typed locators / partition extraction
  - later other corpus/problem loaders

- `tests/_fixtures` or `rune_decrypter_prime.examples` / `tutorials` helpers
  - plaintext baselines
  - test-only default seeds
  - demo/example payloads

That would remove the current ambiguity where “data” can mean assets, LP corpus access, or test baselines depending on which file you are reading.

---

## Important caution

This split should **not** change the packaged-assets contract.

The current guardrail tests already assert that built-in defaults resolve under `assets/`. That is good and should stay true.

So the change is mostly about:
- ownership
- naming
- dependency direction
- keeping test/example material out of core runtime defaults

not about changing where the actual big files live.

---

## Determinism / release implications

This split is mostly architectural, but there are still determinism-sensitive edges.

### Determinism risk 1: default asset resolution

If you move asset helpers, make sure the default packaged roots still resolve identically.

**Test to add / keep:**
- built-in LM / hamming / wordlists / LP defaults still resolve under `assets/`

### Determinism risk 2: default run seed

If `RunConfig.seed` stops importing from the test baseline registry, the replacement default must be explicit and stable.

**Test to add:**
- core `RunConfig()` default seed comes from a core constant, not from test/tutorial data

### Determinism risk 3: LP problem loading boundary

If LP loaders move behind a new `ProblemSource` or `problem_sources` package, payload extraction must stay byte-for-byte equivalent for the same locator input.

**Test to add:**
- locator → `(ct_idx, wli)` payload stays unchanged after the move

---

## Cipher / key-op extension comments from this pass

I still think the extension story wants one more cleanup step before v1:

### Cipher registration

Current state:
- string / alias driven
- decorator registration
- some import-time side effects
- “dev” naming still partly active

This is usable, but a bit informal.

### Key-ops registration

Current state:
- much cleaner enum/family-led story
- registry ownership clearer
- better fit with the rest of the typed core direction

### My recommendation

Do **not** force the cipher registry to become identical to key-ops if that adds churn.

But do make the ownership story explicit:
- ciphers are name/alias-routed runtime implementations
- key-ops are family-typed core behaviours

Then tidy the obvious confusing parts:
- stop relying on generic-map side-effect registration from `api/specs.py`
- rename or relocate active `dev` components that are no longer really experimental

---

## What I would do next for this area

### Must-fix before v1

1. remove `RunConfig` dependency on `data.cipher_tests.baseline_registry`
2. stop treating test/example baselines as core runtime defaults
3. fix misleading active `dev` naming where components are truly part of the runtime

### Should-fix before v1

4. split `data` into clearer ownership buckets
5. move LP-specific API helpers behind an explicit problem-source boundary
6. move asset-path helpers under a clearer `assets` / `resources` owner
7. document the extension story for ciphers vs key-ops more clearly

### Can wait until just after v1 if needed

8. broader problem-source generalisation beyond LP
9. nicer higher-level fixture abstractions for tutorials and examples

---

## Overall judgement after this pass

Your instinct is right.

The `data` package is not just “a bit messy”; it is one of the clearer examples of the repo having reached the point where **historical convenience now conflicts with clean ownership**.

That is good news in one sense, because it is a tractable v1 cleanup problem:
- split ownership
- fix one bad dependency direction
- keep the existing asset/default behaviour stable
- and make LP/problem-source loading a first-class concept instead of a generic “data helper”.

That is the kind of change that makes the repo easier to explain, easier to extend, and safer to build a core config runner on top of.
