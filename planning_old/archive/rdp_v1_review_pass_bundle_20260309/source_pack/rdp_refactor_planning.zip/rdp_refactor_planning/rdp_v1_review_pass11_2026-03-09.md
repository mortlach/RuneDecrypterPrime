# RDP v1 engineering review - pass 11 (findings register + ordered cleanup programme)

Date: 2026-03-09
Surface: local `src/tests/tools/benchmarks` bundle (`src_test_bench_nobloat__20260309T161023Z.zip`)
Mode: static engineering review only; no full runtime verdict because large data assets are intentionally excluded.

## 1) Adjustment based on user feedback

The earlier note that the active `no_wli` tree was "over-sliced" needs a more careful framing.

The split away from a ~5,000-line file was the right move. It made the system thinkable and reviewable. The current problem is **not** that the code was sliced. The current problem is that the slice pattern has not yet converged into a stable, low-friction package shape.

So the v1 recommendation is **not** "merge it back".
It is:

- keep the conceptual decomposition,
- reduce accidental fragmentation,
- collapse exact duplicates,
- move from one flat folder of many bridge files to a smaller number of grouped subpackages,
- and tighten the contracts around scorer roles, outputs, and path/privacy policy.

That keeps the gains from the split without going back to a monolith.

## 2) Executive judgement

The repo now looks much closer to a **convergence / hardening** phase than a feature-discovery phase.

Main v1 risks are no longer "missing capability". They are:

1. implicit defaults,
2. duplicated output / hashing / privacy logic,
3. benchmark-side scorer plumbing that is present but still too implicit,
4. a few brittle release-facing persistence choices,
5. a flat benchmark package shape that makes it harder than necessary to reason about the system.

This is good news. It means the right path to v1 is mainly disciplined clean-up and stronger contract tests, not another big feature wave.

## 3) Findings register (prioritised)

### Must-fix before v1

#### F1. Double-write of `run_config.json`
**Area:** no-WLI benchmark persistence  
**Files:** `tools/benchmarks/periodic_sub_trans/no_wli/run_config_io.py`  
**Finding:** `persist_run_config_with_locks(...)` writes `run_config.json`, computes lock hashes, mutates the payload, then writes the file again.  
**Risk:** brittle persistence contract; partial-write window; harder reasoning during audit/debug.  
**Recommendation:** build final payload in memory, then perform a single write.  
**Test to add:** focused test that asserts one write call and final payload completeness.

#### F2. Run-directory ownership is inferred, not explicit
**Area:** community benchmark runner  
**Files:** `tools/benchmarks/community/_run_single_job.py`  
**Finding:** the helper picks the run directory by diffing pre/post directory sets, then falls back to the lexicographically latest existing directory.  
**Risk:** wrong directory binding if multiple runs exist or if no new directory is created in the expected way.  
**Recommendation:** return an explicit run identifier / run path from the pipeline side, or persist a marker file tied to the launched job.  
**Test to add:** a test where no new directory appears but another unrelated later directory exists, asserting the helper does not bind to the wrong run.

#### F3. Word-ngram SQLite path can leak as raw persisted path
**Area:** no-WLI run config output / privacy  
**Files:** `tools/benchmarks/periodic_sub_trans/no_wli/run_config_builder.py`  
**Finding:** `word_ngram_report.sqlite_path` is persisted with `str(state.get("WORD_NGRAM_REPORT_SQLITE_PATH") or "")` instead of going through repo-relative / redaction handling.  
**Risk:** absolute host paths can leak into release artifacts.  
**Recommendation:** apply the same repo-relative / `<external>` redaction policy already used elsewhere.  
**Test to add:** privacy test for `WORD_NGRAM_REPORT_SQLITE_PATH` covering in-repo and out-of-repo paths.

#### F4. Default word-ngram asset selection is mtime-driven
**Area:** no-WLI defaults / determinism / release behaviour  
**Files:** `tools/benchmarks/periodic_sub_trans/no_wli/runner_defaults.py`  
**Finding:** candidate SQLite assets are auto-discovered and the newest file by modification time is selected; `WORD_NGRAM_REPORT_ENABLED` is then auto-enabled if any candidate is found.  
**Risk:** two working copies can silently get different defaults.  
**Recommendation:** make default asset selection explicit and stable. Good options:
- pinned canonical repo path only,
- or explicit environment/config override with no auto-enable,
- or deterministic precedence order with no mtime rule.
  
**Test to add:** test with multiple candidate files asserting stable precedence independent of modification time.

### Should-fix for v1 if possible

#### F5. `word_ngram_report` reads mutable scorer state rather than returned report/stats
**Area:** report plumbing / scorer contract  
**Files:** `tools/benchmarks/periodic_sub_trans/no_wli/word_ngram_report.py`, tests in `tests/tools/test_no_wli_word_ngram_report.py`  
**Finding:** the helper scores one plaintext, ignores returned `_stats`, then re-reads `last_stats()` from scorer state; tests currently lock that behaviour.  
**Risk:** the contract is less explicit than it should be, and the report path depends on scorer mutable state rather than the immediate return value.  
**Recommendation:** either:
- return a structured per-call report/stats object from the scorer path and consume that directly, or
- explicitly document `last_stats()` as the supported report channel and standardise around it.
  
**Test to add:** a contract test that proves the chosen report channel and forbids divergence between returned stats and `last_stats()`.

#### F6. `word_ngram_report` scorer role is not isolated cleanly enough
**Area:** no-WLI scorer construction  
**Files:** `tools/benchmarks/periodic_sub_trans/no_wli/iteration_runtime.py`, `scoring_experiment_config.py`  
**Finding:** the word-ngram report scorer config is built by copying the broader basin-judge config and then adding `word_ngram_judge_*` fields.  
**Risk:** scorer roles are harder to reason about; report-only logic inherits unrelated stage-3 judge configuration.  
**Recommendation:** introduce a narrow role-specific builder for report scorers. Keep shared fields intentional, not copied by convenience.  
**Test to add:** role-contract test that proves exactly which scorer fields the report scorer is allowed to inherit.

#### F7. Multiple active canonical-JSON / hashing policies
**Area:** benchmark artifact integrity  
**Files:**
- `tools/benchmarks/community/_campaign_common.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py`
- `tools/benchmarks/scoring/span_hamming_nose/schema.py`

**Finding:** there are several active canonicalisation/hashing implementations with different float and sanitisation semantics.  
**Risk:** hidden drift in artifact hashes, lock payloads, and audit rows; harder long-term maintenance.  
**Recommendation:** create one shared benchmark artifact policy module with explicit variants only where genuinely required.  
**Test to add:** cross-module parity tests for representative payloads, especially floats, NaN handling, Path values, numpy values, and ordering.

#### F8. `BaseScorer` contract has not fully converged
**Area:** core scoring  
**Files:** `src/rune_decrypter_prime/scoring/base_scorer.py`  
**Finding:** legacy string-objective helpers still coexist with newer objective-spec style logic; `telemetry()` is defined twice in the same class body.  
**Risk:** transitional ambiguity in the core scorer surface.  
**Recommendation:** remove accidental duplication now; keep compatibility only where still needed; make the internal objective contract clearly single-shape.  
**Test to add:** a focused telemetry contract test and a single objective-normalisation test that captures the intended compatibility boundary.

#### F9. `scorer_report` is real, but not yet the clearly dominant benchmark report contract
**Area:** scorer reporting / benchmark outputs  
**Files:**
- `src/rune_decrypter_prime/scoring/scorer_report.py`
- `src/rune_decrypter_prime/scoring/scorer_report_builder.py`
- `tools/benchmarks/periodic_sub_trans/common/scorer_sidecar.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/word_ngram_report.py`

**Finding:** scorer reports exist and are used, but benchmark reporting is still split between sidecar JSONL rows and nested local payloads.  
**Risk:** reporting surface stays harder to query and standardise than necessary.  
**Recommendation:** decide whether `ScorerReport` is the canonical benchmark scorer-report artifact. If yes, make benchmark sidecars and nested payloads both clearly derived from that one contract.  
**Test to add:** one end-to-end report-shape test from scorer call to persisted benchmark sidecar row.

### Good clean-up wins

#### F10. Exact duplicate helper: `stage_engine_trace.py`
**Area:** benchmark common helpers  
**Files:** duplicated verbatim across:
- `no_wli/stage_engine_trace.py`
- `col_then_sub/stage_engine_trace.py`
- `sub_then_col/stage_engine_trace.py`

**Recommendation:** move to one common module immediately.

#### F11. Near-duplicate iteration bridges between `sub_then_col` and `col_then_sub`
**Area:** benchmark orchestration  
**Files:** `sub_then_col/stage_engine_iteration_bridge.py`, `col_then_sub/stage_engine_iteration_bridge.py`  
**Finding:** about 89% line similarity; main differences are stage labels and policy IDs.  
**Recommendation:** lift the shared engine and keep flavour-specific stage maps small.

#### F12. Historical runner snapshots still live under active source tree
**Area:** repository shape / bloat  
**Files:** `tools/benchmarks/periodic_sub_trans/no_wli/old/*`  
**Finding:** historical snapshots remain inside the active tree even though `README` describes them as archival history.  
**Recommendation:** move them out of the active package tree for v1 (archive folder, release bundle exclusion, or separate planning history location).

## 4) Keep / merge / delete view for `no_wli`

This is the important nuance.

### Keep as distinct concepts
These represent real domain steps and should stay separate, even if file placement changes:

- `stage1_substitution.py`
- `stage2_search.py`
- `stage2_promotion.py`
- `stage3_two_phase.py`
- `stage3_single_phase.py`
- `stage3_runtime_calls.py`
- `scoring_experiment_config.py`
- `scoring_policy.py`
- `word_ngram_report.py`
- `oracle_*` policy/guard code
- `verify_*` audit/final artifact checks

### Merge or tighten
These currently feel more fragmented than conceptually necessary:

- `setup_logging.py` + `setup_logging_payload.py`
- `runner_state_defaults.py` + `runner_state_init.py`
- `runtime_mode_info.py` + `runtime_mode_overrides.py` + `runtime_mode_presets.py`
- `run_manifest.py` + `run_manifest_setup.py`
- `oracle_floor_guard.py` + `oracle_floor_guard_flow.py`
- `run_completion.py` + `run_progress.py` (possibly keep separate if they diverge later, but likely can be one run-status module)

### Move into subpackages rather than leave flat
The current flat directory makes the system harder to scan than necessary.

Recommended shape:

- `no_wli/config/`
  - runner defaults
  - runtime defaults/config/modes
  - profile defaults
  - campaign config apply
  - run config builder / io

- `no_wli/run/`
  - startup, environment, main orchestration, sweep, summary, manifests, completion/progress

- `no_wli/iteration/`
  - iteration runtime, pre-stage3, post-stage3, matrix builder/flow, outcome, commit/payload

- `no_wli/stage3/`
  - band policy, policy, seeding, progress, metrics, span summary, phase restarts, runtime calls, single/two-phase

- `no_wli/fixture_matrix/`
  - all `fixture_matrix_*`

- `no_wli/scoring_support/`
  - scoring experiment config, scoring policy, word-ngram report, span AB harness

- `no_wli/audit/`
  - path hashing, oracle audit, verify iteration chain, verify final artifacts

This keeps the conceptual split but reduces the visual sprawl of one large flat folder.

## 5) Ordered v1 cleanup programme

### Stage A - safety and release hygiene
1. Fix `run_config.json` double-write.
2. Fix raw `WORD_NGRAM_REPORT_SQLITE_PATH` persistence.
3. Replace run-directory inference with explicit run identity.
4. Replace mtime-driven word-ngram asset selection with explicit/stable selection.

### Stage B - reporting and artifact-policy convergence
5. Decide the canonical benchmark report contract:
   - is `ScorerReport` the single scorer-report shape or not?
6. Unify JSON/JSONL/hash/path-redaction policy into one shared benchmark artifact module.
7. Add parity tests across old helper call sites before switching them over.

### Stage C - scorer contract clarity
8. Decide whether `word_ngram_report` should consume explicit returned stats or standardised `last_stats()`.
9. Give the report scorer a narrow role-specific config builder.
10. Remove obvious accidental duplication in `BaseScorer`, especially duplicate `telemetry()`.

### Stage D - structural simplification
11. Collapse exact duplicates like `stage_engine_trace.py`.
12. Lift shared logic out of near-duplicate iteration bridges.
13. Repackage `no_wli` into grouped subpackages without changing the conceptual stages.
14. Move `old/` runner snapshots out of the active package tree.

### Stage E - after that, parameter tuning and speed work
15. Only after the contracts are clearer should you do serious tuning of span-hamming, word-ngram coverage thresholds, and search/judge schedule parameters.
16. Speed work should come after contract simplification, otherwise you risk optimising around accidental wiring.

## 6) What I would not do yet

- I would **not** recombine the no-WLI path into one giant file.
- I would **not** try to finalise the perfect long-term scorer architecture before the report and output contracts are made more explicit.
- I would **not** do major speed optimisation before the asset/default/report wiring is cleaned up.

## 7) Best current view of the no-WLI path

The no-WLI split was a success as a thinking tool.

For v1, the right next step is not reversal. It is **convergence**:

- preserve the stage-based mental model,
- make scorer roles explicit,
- standardise artifact/output policy,
- group related files into clearer subpackages,
- and remove the few remaining brittle defaults and persistence edges.

That should give you a much cleaner foundation for both hard no-WLI work and later WLI carry-over, without throwing away the newer scorer capabilities.
