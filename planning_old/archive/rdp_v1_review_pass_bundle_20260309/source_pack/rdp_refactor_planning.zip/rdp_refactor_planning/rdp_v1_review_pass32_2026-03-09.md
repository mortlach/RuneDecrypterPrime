# RDP v1 review pass 32 — packaging/build/install caveats and outer-surface finish

Date: 2026-03-09
Basis: local static review of the uploaded no-bloat code bundle (`src`, `tests`, benchmark subtrees).

## Scope of this pass

This pass is the last narrow gathering sweep before collation.

Focus:
- packaging/build/install shape that is still visible from the uploaded surface
- outer-surface drift between package docs, tutorials, scripts, and the intended public front door
- what can and cannot be concluded without the root packaging files

## Main conclusions

### 1) The repo’s outer surface is still more script-shaped than product-shaped

The inside of the codebase is getting close to a coherent library/core/API shape, but the outer surface still looks fragmented:
- library-style API usage in `api/run.py` / `RunAPI`
- top-level tutorial expectations in `tests/tutorials/...`
- many script-style entry wrappers under `tools/...`
- package README text that still describes tutorials as living under package-local `rune_decrypter_prime/examples/`

That is not catastrophic, but it means the public story is still split between:
- reusable library
- tutorial/demo scripts
- benchmark/campaign scripts

This keeps reinforcing the case for a first-class core config runner plus a cleaner top-level repo shape.

### 2) Packaging/build/install review is still necessarily partial

The uploaded no-bloat bundle does **not** include root packaging/build files such as:
- `pyproject.toml`
- `setup.py`
- `setup.cfg`
- `install.py`
- `requirements/...`
- root CI/workflow config

So I can now say this clearly:

- the static code review of the main Python surface is nearly complete
- the **full** build/install/release review is **not** complete yet, because the necessary root packaging surface is absent from this bundle

That is not a blocker for the code review findings gathered so far, but it does mean any final v1 release plan should include one explicit follow-up pass on the real packaging/install surface.

### 3) `src/` still carries build-output language in a way that suggests boundary drift

`src/README.md` still documents build outputs under `src/` itself:
- `src/build_tmp_fastlm/`
- `src/build_lib_fastlm/`

That is a small but telling sign that build/output boundaries are not yet cleanly separated from source ownership.

For v1, the ideal is:
- source tree says what the code is
- build/release docs say how it is built
- generated build artefacts do not become part of the source-tree mental model

### 4) Script bootstrap remains widespread enough to be a design smell, not just a few exceptions

In the uploaded surface:
- `tools/**/*.py` still contains many `sys.path.insert(...)` bootstraps
- `tools/**/*.py` still contains a very large amount of direct `print(...)`

That means the repo still lacks a clean enough divide between:
- importable, owned library surfaces
- thin top-level scripts that just parse args/config and call the library

This is especially relevant if the project wants:
- a core config runner
- GUI/web front ends later
- campaign orchestration that is not fragile script glue

### 5) The tutorial / examples story still wants one canonical home

Current drift visible from the uploaded surface:
- `src/rune_decrypter_prime/README.md` says tutorials live in `rune_decrypter_prime/examples/`
- tutorial tests expect top-level `tutorials/v1/...`

This is exactly the sort of outer-surface mismatch that makes a repo feel more experimental than it really is.

For v1, there should be one canonical answer to:
- where tutorials live
- what counts as a tutorial vs an example vs a solve fixture
- which entry surface is the blessed one for end users

## Updated judgement after this pass

The static engineering review is now effectively at the point where more raw gathering will have diminishing returns.

My best assessment now:
- **about 95%** of the useful static code/architecture review is complete
- the remaining **5%** is mostly collation work plus one later packaging/install pass when the root repo surface is available

## What remains before collation

Only two things now feel worth doing before switching to collation:

1. one final small sweep for any last high-signal duplicate/shim/cleanup targets in the local bundle
2. then stop gathering and produce the first collated review set:
   - findings register
   - must-fix / should-fix / later
   - target repo shape
   - target contracts/policies
   - proposed v1 hardening programme

## Strongest repo-level conclusion at this point

The repo now looks like a project that has **outgrown its current outer framing**.

The core is moving toward a real product/library shape.
The outer surfaces still look too much like accumulated scripts, helper paths, and historical layout.

That is why the most important v1 work now looks like:
- convergence
- contract tightening
- policy enforcement
- repo-shape cleanup
- campaign/config-runner unification

—not broad new feature exploration.

## Recommended next move

Do one last tiny cleanup-target sweep from the local bundle, then stop gathering and start collating.
