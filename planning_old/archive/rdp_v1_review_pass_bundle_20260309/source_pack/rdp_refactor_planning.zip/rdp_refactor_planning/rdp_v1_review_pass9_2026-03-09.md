# RDP v1 engineering review — pass 9 (repo-shape and consolidation map)

Date: 2026-03-09
Surface: local bundle `src_test_bench_nobloat__20260309T161023Z.zip` (static review only)

## Scope of this pass

This pass focuses on whole-repo structure and consolidation candidates rather than only single-path bugs.

Main questions:
- where are we still expressing the same behaviour in too many local ways?
- where has refactor work produced too many thin files for the value they provide?
- which abstractions should be made common before v1?
- which areas are better left alone until after v1?

---

## High-confidence findings

### 1) The active no-WLI tree is now over-sliced for v1 maintenance

The active `no_wli` surface contains **89 active Python files** excluding the `old/` snapshots, with a median file size of about **140 lines**. Around **66 of those 89 files are under 200 lines**, including several very small bridge/orchestrator modules.

This is not automatically wrong, but in practice it now means that understanding one benchmark flow requires hopping across a very large number of local modules. That is a maintenance cost in its own right.

Examples of very small active modules that mostly act as local glue:
- `tools/benchmarks/periodic_sub_trans/no_wli/run_mode_entrypoint.py` (29 lines)
- `tools/benchmarks/periodic_sub_trans/no_wli/run_config_io.py` (41 lines)
- `tools/benchmarks/periodic_sub_trans/no_wli/order_dispatch.py` (45 lines)
- `tools/benchmarks/periodic_sub_trans/no_wli/runner_state_init.py` (45 lines)
- `tools/benchmarks/periodic_sub_trans/no_wli/stage_engine_trace.py` (28 lines)

This suggests the refactor has passed the point where extra seams always help. For v1, some of these should be merged into clearer domain modules rather than kept as many tiny wrappers.

### 2) Historical runner snapshots are still shipped inside the active benchmark tree

`tools/benchmarks/periodic_sub_trans/no_wli/README.md` explicitly says historical runner snapshots are kept under `tools/benchmarks/periodic_sub_trans/no_wli/old/` and that the active surface is the top-level `no_wli/*.py` modules only (`README.md`, lines 22–24).

In this local bundle, the `old/` subtree still includes multiple very large runner snapshots:
- `old/runner.py`
- `old/runner_copy_legacy.py`
- `old/runner_backup_pre_runtime_config_refactor_20260304.py`

Those three files alone account for roughly **16.6k lines** of inactive historical code in the surfaced benchmark tree. I found no active imports of the `old/` code in the review surface. For v1, this is strong evidence that the old snapshots should be moved out of the active source tree or archived elsewhere.

### 3) Stage-engine trace emission is duplicated verbatim across three flavours

These three files are byte-for-byte identical in the local bundle:
- `tools/benchmarks/periodic_sub_trans/no_wli/stage_engine_trace.py`
- `tools/benchmarks/periodic_sub_trans/col_then_sub/stage_engine_trace.py`
- `tools/benchmarks/periodic_sub_trans/sub_then_col/stage_engine_trace.py`

Each defines the same `make_stage_engine_trace_emitter(...)` wrapper over the common `StageTraceWriter`.

This is a straightforward pre-v1 consolidation target: keep one shared helper in the common layer and stop carrying three copies plus three nearly identical tests.

### 4) The stage-engine iteration bridge is near-duplicate across `sub_then_col` and `col_then_sub`

`tools/benchmarks/periodic_sub_trans/sub_then_col/stage_engine_iteration_bridge.py` and
`tools/benchmarks/periodic_sub_trans/col_then_sub/stage_engine_iteration_bridge.py`
are very close structurally.

The local diff shows that most of the file is the same and that the main differences are:
- dataclass names
- policy id string
- stage id labels
- error text

This is a good candidate for one common generic bridge parametrised by stage ids and callbacks, with thin flavour-specific wiring only where the stage names differ.

### 5) There are multiple active canonical-JSON / hashing policies, not one

Active surfaced code currently contains at least these separate canonicalisation or hashing implementations:
- `tools/benchmarks/community/_campaign_common.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/path_hash_utils.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/verify_iteration_audit_chain.py`
- `tools/benchmarks/scoring/span_hamming_nose/schema.py`

Important detail: these are not all semantically identical.

Examples:
- community canonical JSON normalises floats to **12 significant digits before hashing** (`_campaign_common.py`, lines 21–47)
- no-WLI path hashing uses a different sanitiser and keeps ordinary finite floats as-is (`path_hash_utils.py`, lines 90–125)
- no-WLI audit-chain verification defines its own `_sanitize(...)` and `_canonical_json(...)` again (`verify_iteration_audit_chain.py`, lines 49–66)

This means the repo does **not** currently have one shared definition of “canonical JSON” for benchmark artifacts. Even if these are used on different artifact families today, it is still a release risk because the names sound interchangeable while the rules differ.

### 6) The no-WLI run config still risks leaking absolute word-ngram asset paths

There is already path-redaction support for some benchmark outputs:
- `to_repo_rel_path(...)` in `path_hash_utils.py`, lines 23–35
- `scorer_cfg_for_output(...)` only rewrites `span_hamming_assets_dir`, lines 37–44
- `scoring_meta_for_output(...)` only rewrites `span_assets_dir`, lines 47–51

But in `run_config_builder.py`, the persisted Stage-3 word-ngram report block writes:
- `sqlite_path=str(state.get("WORD_NGRAM_REPORT_SQLITE_PATH") or "")`

That means an absolute override path would be written directly into `run_config.json`, unlike the redacted span asset paths.

I did not find surfaced tests locking privacy behaviour for this word-ngram SQLite path in the run config. Current tests cover:
- `to_repo_rel_path(...)` for general path privacy
- default enable/disable behaviour for word-ngram asset discovery

So this looks like a real release-hardening gap.

### 7) The current tests are preserving some duplication rather than exposing it

The review surface includes separate, near-identical tests for stage-engine trace writing in:
- `tests/tools/test_no_wli_stage_engine_trace.py`
- `tests/tools/test_col_then_sub_stage_engine_trace.py`
- `tests/tools/test_sub_then_col_stage_engine_trace.py`

That is not wrong, but it shows the current structure is making tests mirror duplication rather than pushing shared behaviour into one common implementation plus one contract test.

---

## What I would change before v1

### Must-fix

1. **Stop leaking raw absolute `WORD_NGRAM_REPORT_SQLITE_PATH` into persisted run config**
- route it through the same repo-relative redaction policy used for other benchmark asset paths
- add a focused privacy test for the word-ngram report config block

2. **Replace the double-write `run_config.json` flow**
- build the full payload first, then write once
- keep the post-write file hash if needed, but do not persist a half-built file first

3. **Stop mtime-based default word-ngram asset selection for release-facing defaults**
- require explicit path selection, or use one pinned deterministic location only

### Should-fix

4. **Create one shared benchmark artifact/output policy module**
- canonical JSON
- JSON / JSONL writing
- hashing helpers
- repo-relative path redaction
- file hashing

5. **Move `stage_engine_trace` to the common layer and delete the duplicate flavour copies**

6. **Merge the two flavour-specific iteration bridge files into one common bridge pattern**

7. **Do a keep/merge/delete pass over the active no-WLI tree**
- combine very small glue files where doing so reduces hops without hiding meaning
- keep larger domain modules separate where they really own one concept

### Later / post-v1

8. **Move historical snapshots out of the active source tree entirely**
- archive bundle, tag, or planning/history folder
- keep them accessible, but not inside the active benchmark package path

---

## What I would leave alone for now

I would **not** do a giant repo-wide rewrite before v1.

The right move is smaller and safer:
- unify output/hashing/path policy
- fix the most brittle no-WLI defaults and persistence contracts
- collapse the obvious exact duplicates
- trim the worst over-splitting in no-WLI
- keep deeper architectural rewrites for after the release surface is stable

---

## Current judgement

The repo is no longer in a “missing features” state. It is in a **consolidation and convergence** state.

The biggest v1 risks I now see are not missing algorithms. They are:
- implicit defaults
- multiple local serialization/hash policies
- small pass-through/privacy mistakes
- duplicated benchmark glue
- too many tiny files in the no-WLI tree for the value they add

That is good news in one sense: these are fixable with disciplined cleanup, not a redesign of the core system.
