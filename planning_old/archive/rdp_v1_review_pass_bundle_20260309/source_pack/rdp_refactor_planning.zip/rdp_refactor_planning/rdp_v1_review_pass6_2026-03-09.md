# RDP v1 engineering review – pass 6 (scorer wiring, sidechannels, and report plumbing)

Date: 2026-03-09
Branch under review: `experimental/merge`
Scope in this pass:
- scorer/report plumbing around the newer scoring work
- no-WLI runtime wiring for span-hamming and word n-gram sidechannels
- strength of current test coverage for scorer/config pass-through paths

---

## Summary

This pass confirms that your concern is well-founded: the repo does have **real scorer/config pass-through risk**, especially in the no-WLI benchmark path.

The good news is that the newer pieces are **present**:
- span-hamming experiment profiles exist
- word n-gram report plumbing exists
- scorer-report objects and JSON serialisation exist
- there is at least smoke/helper coverage around those paths

The bad news is that the wiring is not yet as intuitive or as isolated as it should be for v1. The main pattern I found is:

- newer scoring features are being threaded through the system,
- but several of them are still piggybacking on broader scorer configs,
- and some tests prove string-level guardrails rather than full runtime behaviour.

That is exactly the kind of setup where “the feature exists” can still coexist with “we are not actually using it the way we think we are”.

---

## Finding 1 — the word-ngram report runtime is not isolated from the span-hamming / basin-judge scorer

### Evidence

In `tools/benchmarks/periodic_sub_trans/no_wli/iteration_runtime.py`, the word-ngram report scorer is built like this:

- build `scorer_basin_judge` from the stage-3 experiment profile
- then call `build_word_ngram_report_cfg_fn(base_cfg=dict(scorer_basin_judge), ...)`
- then build `scorer_word_ngram_report_runtime` from that derived config

This means the word-ngram report runtime inherits the broader basin-judge scorer config, rather than being built from a small dedicated “word-ngram-report-only” config.

Relevant code path (from raw file read during review):
- `scorer_basin_judge = build_stage3_experiment_cfg_fn(...)`
- `scorer_word_ngram_report_cfg = build_word_ngram_report_cfg_fn(base_cfg=dict(scorer_basin_judge), ...)`
- `scorer_word_ngram_report_runtime = build_scorer(...)`

The config builder confirms what gets inherited.

In `tools/benchmarks/periodic_sub_trans/no_wli/scoring_experiment_config.py`:
- `build_stage3_experiment_cfg(...)` enables calibrated span-hamming for `b_min` / `c_min_late` at lines 77–98 and 199–215
- `build_word_ngram_report_cfg(...)` simply copies `base_cfg` and adds `word_ngram_judge_*` fields at lines 120–129

So under the default no-WLI scoring-experiment path, the word-ngram report runtime is **not just a word-ngram judge**. It is a scorer built from:
- the basin-judge stage-3 config,
- plus word-ngram judge options.

### Why this matters

This is confusing at best and misleading at worst.

A report called `word_ngram_report` sounds like it should come from a scorer whose role is “evaluate the word-ngram sidechannel”. But the current runtime is a broader scorer config with extra word-ngram options attached.

That has three practical consequences:

1. The reported score can be semantically ambiguous.
2. Runtime cost may include more than the word-ngram judge.
3. It becomes harder to reason about whether the benchmark is really isolating the effect of the new word-ngram scorer work.

### Severity

**High should-fix** for v1.

This is probably not corrupting the main solver decisions if the path is report-only, but it is a serious benchmarking clarity problem.

---

## Finding 2 — the word-ngram report helper ignores returned stats and relies on mutable `last_stats()` state

### Evidence

In `tools/benchmarks/periodic_sub_trans/no_wli/word_ngram_report.py`:
- lines 120–126 call `score_plaintexts_chunked(...)` and receive `score_arr, _stats`
- lines 127–135 discard `_stats`
- then they query `scorer_runtime.last_stats()` and derive the report payload from that

So the helper explicitly scores a plaintext, gets stats back, then ignores the returned stats object and instead reads mutable scorer state.

This is also reflected in tests. In `tests/tools/test_no_wli_word_ngram_report.py`:
- lines 54–92 explicitly lock the current behaviour as “uses `last_stats()`”
- the fake scoring function returns `(np.asarray([2.5]), {})`
- the trust/report fields are then taken from `_FakeScorer.last_stats()`

### Why this matters

This is a fragile contract.

It can work if:
- the scorer implementation always updates `last_stats()` correctly,
- nothing else touches that scorer between score and report extraction,
- and the batch wrapper always behaves as expected.

But for v1, it is weaker than it needs to be.

The helper already has the immediate scoring result in hand. Ignoring that and re-reading mutable state creates a stale-data / mismatched-data risk, especially as scorer internals evolve.

### Severity

**High should-fix** for v1.

I would strongly prefer the report helper to consume the stats returned by the scoring call whenever available, and only fall back to `last_stats()` when the scorer API gives no better option.

---

## Finding 3 — scorer-report integration exists, but the strongest proof is still smoke/helper level rather than full-path benchmark proof

### Evidence

There is genuine scorer-report integration work in place:

- `src/rune_decrypter_prime/scoring/scorer_report.py` defines a structured report object and JSON-safe serialisation (lines 58–95)
- `src/rune_decrypter_prime/scoring/scorer_report_builder.py` derives `ObjectiveSpec`, telemetry, metrics, and details sections (lines 134–174)
- `tools/benchmarks/periodic_sub_trans/no_wli/word_ngram_report.py` builds a scorer report and attaches it into the report payload at lines 141–151
- `tools/benchmarks/periodic_sub_trans/no_wli/iteration_finalize.py` persists word-ngram report payloads into the per-instance artifact payload at lines 107–185

There is also benchmark-side smoke coverage:
- `tests/tools/test_benchmark_scorer_report_sidecar_smoke.py` proves a JSONL sidecar row is written for the Gate-0 preflight path, and checks the objective spec and context fields at lines 62–92

However, the current evidence is still patchy in terms of **end-to-end benchmark-path proof**.

The strongest scorer-report benchmark test I found is still a preflight smoke test with fake scorers. I did not yet find a surfaced full-path test that proves, end-to-end, that the main no-WLI benchmark run writes the expected scorer-report payloads for the newer scorer combinations.

### Why this matters

So the answer to “did we integrate scorer-report properly?” is:

**Partly yes, but not yet proven strongly enough for v1.**

The building blocks exist. Some wiring exists. The benchmark sidecar exists. But the current surfaced proof looks stronger at the helper/smoke level than at the fully integrated runner level.

### Severity

**Should-fix** for v1 release confidence.

---

## Finding 4 — span-hamming is not the main stage-3 search scorer in the no-WLI path; it is an experiment / judge channel around it

### Evidence

In `tools/benchmarks/periodic_sub_trans/no_wli/scoring_experiment_config.py`:
- `stage3_char4_avg_fulltext_search_cfg(...)` explicitly sets:
  - `avg_window_policy="full_text"`
  - `span_hamming_enabled=False`
  - `span_hamming_mode="off"`
  at lines 27–39

The no-WLI runner tests explicitly lock that contract.

In `tests/tools/test_periodic_sub_trans_runner_scorer_impl.py`:
- lines 506–510 assert that `_stage3_char4_avg_fulltext_search_cfg(...)` uses an `avg.*` objective with `full_text` policy and `span_hamming_enabled == False`
- lines 532–538 then assert the runtime/bridge path still includes the separate span-judge machinery (`phaseA_basins_judged_by_span`, `span_judge_time_s`, and related wiring)

### Why this matters

This makes the current architecture more understandable:

- stage-3 search objective: avg full-text char4
- span-hamming: used in the experiment / judge path around stage 3
- word-ngram report: report-side sidechannel at finalisation time

That separation may be intentional, but it is **not intuitive**, and it helps explain why it can feel as if span-hamming is “not really integrated properly” even though the repo contains a lot of span-hamming code.

The codebase is not using span-hamming as a straightforward “main stage-3 scorer replacement”. It is using it as a more conditional auxiliary channel.

### Severity

Not a bug by itself.

But it is a **major clarity and tuning issue**. For v1, this needs to be made much more explicit in code structure and benchmark outputs.

---

## Finding 5 — many scorer-wiring tests are source-guard tests rather than strong execution tests

### Evidence

`tests/tools/test_periodic_sub_trans_runner_scorer_impl.py` contains a mix of good runtime/config assertions and a noticeable number of source-text guard tests.

Examples:
- lines 456–485 build one large string from several source files and assert that key substrings are present
- lines 488–504 do the same for the two-phase gate / span-judge path
- lines 512–540 do the same for the stage-3 search contract wiring text
- lines 947–958 and 968–986 also verify source text rather than executing the relevant end-to-end behaviour

These tests do have value. They help stop accidental deletion of important wiring concepts.

But they are weak against several kinds of mistakes you are worried about:
- wrong value passed through to the runtime
- stale wrapper code still mentioning the old concept in text
- actual execution path drifting while the source still contains the expected string
- config built correctly in one place but unused in practice

### Why this matters

This is a likely reason why the repo can feel “full of options” while still leaving you unsure whether the new scorer parts are being applied as intended.

The current test mix proves some architecture intent, but it does not always prove runtime truth.

### Severity

**High should-fix** for v1 confidence.

I would not throw these tests away, but I would add more focused execution tests around the scorer-runtime construction and emitted report payloads.

---

## Positive findings from this pass

There are also some genuinely good signs:

1. **ScorerReport / builder structure is sensible**
   - `ScorerReport` is typed, JSON-safe, and rejects non-finite floats
   - `build_scorer_report(...)` handles `ObjectiveSpec`, telemetry, metrics, and nested detail sections in a sensible way

2. **Word-ngram report is currently report-side, not inner-loop**
   - `runner_defaults.py` labels it explicitly as “Report-only word-ngram side-channel” at lines 64–70
   - `iteration_finalize.py` attaches it at finalisation time rather than inside the core search loop

3. **The repo is trying to keep stage-3 roles separate**
   - search scorer
   - basin judge scorer
   - word-ngram report scorer

   The problem is not absence of structure. The problem is that the structure is not yet as clear and isolated as it needs to be.

---

## What I would change before v1

### Must do

1. **Make scorer roles explicit in code and names**
   - `stage3_search_runtime`
   - `stage3_basin_judge_runtime`
   - `word_ngram_report_runtime`

   Each should be built from a config whose purpose matches its name.

2. **Stop building the word-ngram report runtime from the basin-judge config wholesale**
   - create a dedicated builder for the report scorer
   - copy only the fields genuinely intended for that role

3. **Use returned scoring stats where available**
   - in `word_ngram_report.py`, consume the stats returned by `score_plaintexts_chunked(...)`
   - use `last_stats()` only as fallback

4. **Remove blanket exception swallowing around scorer-report creation**
   - at minimum, record an explicit failure field in the payload
   - better: fail the focused test path loudly and keep benchmark runtime tolerant only where necessary

### Strongly recommended

5. **Add real execution tests for scorer-runtime construction**
   - build the no-WLI iteration runtime
   - assert which config each scorer runtime was built from
   - assert whether span-hamming is on/off for each role
   - assert whether word-ngram runtime inherits only intended fields

6. **Add one end-to-end report payload test for the no-WLI benchmark path**
   - not just helper tests
   - not just preflight sidecar
   - a real per-iteration artifact payload check with the newer scorer pieces active

7. **Tighten benchmark output semantics**
   - make it explicit in the output which score came from:
     - stage-3 search
     - stage-3 basin judge
     - word-ngram report runtime
     - scorer-report object

---

## Current judgement after this pass

The new scoring pieces are **not absent**.
They are **not obviously dead**.
But they are also **not yet wired in the cleanest or most trustable way** for a v1 release.

So your intuition was right.

The current repo state looks like:
- feature-complete enough to stop broad experimentation,
- but still carrying enough scorer/report/config ambiguity that a serious v1 cleanup is justified.

The next pass should turn this into a concrete **cleanup programme for scorer/runtime/report roles**, with a keep / merge / split recommendation for the no-WLI scoring tree.
