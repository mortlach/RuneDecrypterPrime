# RDP v1 review – pass 16 (core run contract, engine seams, registries, paths)

Date: 2026-03-09
Review surface: local `src` / `tests` / `tools` bundle supplied in chat
Mode: static engineering review only (no full runtime verdict)

## Why this pass

This pass moves away from benchmark-local issues and looks at the broader core seams that a first-class config runner would need to stand on:

- top-level solve contract
- core run/config ownership
- engine/builder seams
- cipher and key-op extension paths
- logging / path / privacy behaviour

The main question underneath all of this is simple:

**Is the repo close to supporting one clean, serialisable core run spec, or is that still blocked by contract drift in the lower layers?**

My answer after this pass is:

**Yes, it is close — but a few core contracts still need convergence first.**

---

## New findings

### F16-1. The top-level solve contract is close, but still split across two slightly different models

Evidence:
- `src/rune_decrypter_prime/api/run.py:33-118`
- `src/rune_decrypter_prime/api/pipeline.py:16-131`
- `src/rune_decrypter_prime/core/config/run.py:22-95`

`RunAPI.run(...)` already looks like a front-door solve API. It takes typed specs, normalises inputs, builds `ScoringConfig` and `SolverConfig`, and calls `execute_run(...)`.

But the public solve contract is still split in an awkward way:

- `RunAPI.run(...)` exposes `scorer: str = "rune"` as a top-level choice.
- `RunConfig` also carries `scorer_name` as a first-class field.
- Yet the main execution path builds the scorer from `ScoringConfig`, not from `scorer_name`.
- In `api/pipeline.py`, `scorer_name` is forwarded into `maybe_known_key_fastpath(...)`, but is not used in the ordinary path that materialises `ProblemInstance` and builds the scorer.

That does **not** mean the current API is broken. It does mean the core solve surface has not fully decided what the canonical scorer-selection contract is.

For a core config runner, this matters a lot. A serialisable run spec should not have two overlapping ways to select the scorer role unless both are truly needed.

My current recommendation is:

- keep the rich scorer behaviour in `ScoringConfig`
- but make scorer **role selection** explicit above it
- do not keep `scorer_name` as a half-live decorative field in the long term

At the moment, `scorer_name` looks more like historical UI/front-door residue than a stable runtime contract.

Severity: **medium**

---

### F16-2. `RunConfig` still depends on a test-data baseline registry for its default seed

Evidence:
- `src/rune_decrypter_prime/core/config/run.py:14`
- `src/rune_decrypter_prime/core/config/run.py:32`

`RunConfig` imports `BASELINE` from `rune_decrypter_prime.data.cipher_tests.baseline_registry` and uses `BASELINE["seed"]` as its default `seed`.

That is a poor core dependency for v1.

Why this matters:

- a core runtime config object should not depend on a test-data package
- it makes packaging and partial-bundle use harder
- it blurs the line between runtime defaults and test harness defaults
- it is one reason static review is easier than runtime review in stripped bundles

I would move this to one of these instead:

1. a literal core default (`0` is already the effective engine default elsewhere), or
2. a small core defaults module that does **not** import test data

This is a good example of the repo still carrying some “research harness” wiring inside core runtime code.

Severity: **medium-high**

---

### F16-3. `api/specs.py` still does import-time registry mutation

Evidence:
- `src/rune_decrypter_prime/api/specs.py:12-21`
- `src/rune_decrypter_prime/api/specs.py:54`

`api/specs.py` imports `rune_decrypter_prime.ciphers.generic_map_cipher` purely for side-effect registration of `user_map2`, `user_map3`, and `lookup`.

That works, but it means a front-door spec module is mutating the cipher registry at import time.

On its own, that is not a bug. But it is a structural smell for v1 because it makes the extension story less obvious:

- some capabilities become available because you imported the spec layer
- others become available because package `__init__` imported the concrete cipher module
- others exist in the tree but are not imported by default

A core config runner would be cleaner if registry population were owned in one predictable place.

I would treat this as a convergence clean-up item, not an urgent correctness bug.

Severity: **medium**

---

### F16-4. The `ciphers/dev` package is not really “dev”; active runtime ciphers depend on it

Evidence:
- `src/rune_decrypter_prime/ciphers/vigenere_cipher.py:9-19`
- `src/rune_decrypter_prime/ciphers/columnar_transposition_cipher.py:8-14`
- `src/rune_decrypter_prime/ciphers/periodic_substitution_cipher.py:8-11`
- `src/rune_decrypter_prime/ciphers/dev/base_keyed_cipher.py`
- `src/rune_decrypter_prime/ciphers/base_keyed_cipher.py`

Several active, first-class ciphers import `KeyedCipherBase` from `rune_decrypter_prime.ciphers.dev.base_keyed_cipher`, not from the non-`dev` base module.

So the current state is:

- `ciphers/dev/` sounds optional or experimental
- but part of it is actually on the active runtime path
- and there is also a non-`dev` `base_keyed_cipher.py` beside it

That is confusing repo structure for v1.

I do **not** read this as “merge everything back”. I read it as:

- the `dev` label has drifted from reality
- runtime-owned base classes should live in a clearly runtime-owned location
- genuinely experimental ciphers can still live in a separate area, but the base class used by active ciphers should not

This is a repo-shape and ownership issue more than a code bug.

Severity: **medium-high**

---

### F16-5. Cipher and key-op registry policies are intentionally different, but that difference is not very visible at the architecture level

Evidence:
- `src/rune_decrypter_prime/ciphers/registry.py:20-27`
- `src/rune_decrypter_prime/keyops/registry.py:14-21`
- `tests/keyops/test_custom_registration.py:15-49`

The registry behaviour is not uniform:

- cipher registration forbids duplicate names and raises on collision
- key-op registration allows silent overwrite, and there is an explicit test blessing override-and-restore behaviour

That may be the right choice. In fact, I can see why it is useful:

- ciphers behave more like stable named capabilities
- key-ops behave more like swappable strategy implementations for research and tests

But it is still an architectural drift point.

For a first-class config runner and extension story, the public docs should make this difference explicit. Otherwise users will assume the registry systems work the same way when they do not.

Severity: **low-medium**

---

### F16-6. Capability discovery is still a bit uneven: some cipher code exists in-tree without becoming part of the normal registry surface

Evidence:
- `src/rune_decrypter_prime/ciphers/__init__.py:10-17`
- `src/rune_decrypter_prime/ciphers/dev/hill_cipher.py:55`
- `tests/tutorials/test_future_presets.py:22`
- `tests/tutorials/test_crib_drag_api.py:136`

The package `ciphers/__init__.py` imports a fixed set of concrete ciphers so their `@register_cipher(...)` decorators run.

But `hill` is registered in `ciphers/dev/hill_cipher.py`, and that module is not imported by `ciphers/__init__.py`. The tutorial tests explicitly guard on `cipher_registry.has("hill")`, which shows that the registry presence of `hill` is conditional rather than a guaranteed part of the default package surface.

This is not necessarily wrong. But it does mean the extension/discovery story is still uneven:

- some ciphers are guaranteed visible
- some are present in-tree but not part of the normal imported surface

For v1, that should become more explicit. Either:

- make the default supported registry surface fully deterministic, or
- formalise “optional capability packs” and expose them clearly

Severity: **medium**

---

### F16-7. Logging/path privacy is still weaker in the event stream than in the metadata snapshot

Evidence:
- `src/rune_decrypter_prime/io/run_logger.py:95-109`
- `tests/test_logging_paths.py:17-47`

This reinforces an earlier finding rather than replacing it.

The current tests check that `META.json` and `config/logging.json` use repo-local or relative path forms.

But `RunLogger.log_trace(...)` still records the fully resolved absolute path into the JSONL event stream via:

- `path = (self._run_dir / "trace" / fname).resolve()`
- `self.log_event({"type": "trace_written", "func": func, "path": str(path)})`

So the release story is currently:

- metadata snapshot redaction is fairly disciplined
- event-stream path redaction is not yet held to the same standard

This is a straightforward v1 hardening task.

Severity: **medium-high**

---

## Current judgement after this pass

The repo is still moving in the right direction.

The big picture remains:

- alpha exploration looks mostly complete
- the remaining work is convergence, hardening, cleanup, and tuning
- the codebase is close to supporting a proper core config runner
- but a few lower-layer ownership and contract issues still need tidying first

The encouraging part is that these are **not** mostly “missing feature” problems.
They are mostly:

- ownership drift
- half-live compatibility fields
- weakly standardised extension and output policies
- repo-shape confusion around what is active versus experimental

That is exactly the sort of thing that should be cleaned up now, before v1.

---

## Updated recommendation set

### Before or alongside a core config runner

1. **Choose one canonical run contract**
   - a typed core `RunSpec`
   - one clear scorer-selection story
   - no half-live `scorer_name` field unless it truly drives runtime behaviour

2. **Decouple core runtime config from test-data defaults**
   - remove `baseline_registry` from `core/config/run.py`

3. **Make runtime-owned packages look runtime-owned**
   - move the actively used `KeyedCipherBase` out of `ciphers/dev/`
   - keep real experimental code separate, but stop mixing the labels

4. **Make registry policy explicit**
   - ciphers = stable named capability registry
   - key-ops = swappable strategy registry
   - document this difference clearly

5. **Harden logging/event redaction**
   - extend path-redaction discipline from metadata snapshots into JSONL events
   - add a focused test for `trace_written` events

### Likely useful tests to add

- a test proving whether `scorer_name` actually changes the ordinary run path or not
- a test that `RunConfig` can be imported and instantiated without the test baseline package
- a test that `RunLogger.log_trace(...)` emits repo-local or relative paths, not absolute ones
- a test that the supported default cipher registry surface is exactly what the project claims it is

---

## Net effect on the larger v1 plan

This pass strengthens, rather than changes, the earlier conclusion:

**The best remaining major feature is a first-class core config runner.**

But it should be built on top of a cleaner ownership split:

- core run spec
- explicit scorer roles
- standard artifact/output policy
- clearer extension/registry story
- less ambiguity about what is “dev”, what is “legacy”, and what is part of the real runtime surface

That would make tutorials, solved-page experiments, campaign jobs, and future GUIs all sit on the same foundation.
