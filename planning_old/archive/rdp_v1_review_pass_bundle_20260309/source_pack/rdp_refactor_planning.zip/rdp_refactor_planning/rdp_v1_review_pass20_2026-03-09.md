# RDP v1 review — pass 20 (components drift and convergence map)

Date: 2026-03-09
Surface: local `src/tests/tools-benchmarks` bundle supplied by user (`src_test_bench_nobloat__20260309T161023Z.zip`)
Mode: static engineering review only

## Scope of this pass

This pass focuses on component drift against the likely intended architecture:

- top-level API / run surface
- core runtime config ownership
- cipher and key-op extension seams
- data / LP loading boundaries
- telemetry / logging / artifact-output placement
- signs of stale shim or compatibility debris that now slows convergence

This is less about one more isolated bug and more about whether the main packages are arranged in a way that will support a stable v1.

---

## Executive summary

My current view is that the repo is **closer to a coherent v1 architecture than it may feel**, but several package boundaries are still slightly wrong:

1. **API and runtime contracts are close but not unified**
   - `RunAPI`, `RunConfig`, and the pipeline are clearly converging toward one solve contract.
   - They are not there yet.

2. **The `data` area is still doing too many jobs**
   - LP/problem loading, baseline/test fixtures, and asset-location defaults are conceptually different things.
   - Core runtime still depends on one of those test/data surfaces.

3. **Cipher extension is workable but architecturally messy**
   - Cipher registration is string-driven and wrapper-heavy.
   - Key-op registration is more canonical and enum-based.
   - Active ciphers still depend on `ciphers/dev/*`, which makes the package layout misleading.

4. **Telemetry / logging / output policy still has multiple owners**
   - Core logging has a run-dir lifecycle.
   - `io/run_logger.py` has its own practical file-writing behaviour.
   - `telemetry/pipeline.py` still has a separate default dump location.
   - This is convergence work waiting to happen.

5. **There is visible shim / debris drag in the core packages**
   - Some modules are clearly transitional but still active enough to confuse future work.

None of this argues for a rewrite.

It argues for a package-boundary cleanup and a small number of stronger canonical owners before more features are added.

---

## Findings

### F20-01 — `RunConfig` still depends on test-baseline data for its default seed

File:
- `src/rune_decrypter_prime/core/config/run.py`

`RunConfig` imports `rune_decrypter_prime.data.cipher_tests.baseline_registry.BASELINE` and uses `BASELINE["seed"]` as the default seed.

Why this matters:
- this is the wrong dependency direction for core runtime config
- core runtime should not depend on test-baseline material
- it makes the current `data` split problem more acute, because one of the wrong edges is already in the main run config

Judgement:
- **should-fix before v1**

Recommendation:
- move the default seed to a core constant or explicit `None -> 0` policy
- keep baseline seeds in tests/tutorial fixtures only

---

### F20-02 — API now exports LP/data helpers directly, which is convenient but weakens the boundary

Files:
- `src/rune_decrypter_prime/api/data_helpers.py`
- `src/rune_decrypter_prime/api/__init__.py`

The API package exports direct LP convenience helpers such as:
- `load_lp_section`
- `load_lp_master_transcript`
- `load_lp_payload_from_locator`

Why this matters:
- it is convenient for current usage
- but it bakes LP/data-specific loading directly into the top-level API surface
- that makes it harder to introduce a cleaner generic `ProblemSource` or fixture/locator abstraction later

Judgement:
- **not a bug**
- but it is architectural drift

Recommendation:
- keep convenience helpers for now if needed
- but reframe them as adapters over a future `problem_sources` package
- do not let LP-specific loaders become the permanent generic API story

---

### F20-03 — `api/specs.py` still registers generic-map ciphers by import side effect

File:
- `src/rune_decrypter_prime/api/specs.py`

`api/specs.py` imports `rune_decrypter_prime.ciphers.generic_map_cipher` purely to force registration side effects.

Why this matters:
- it works, but it is a hidden registration policy inside the user-facing spec layer
- it makes import order part of behaviour
- it blurs ownership between “declaring a spec” and “activating runtime extension points”

Judgement:
- **should-fix**

Recommendation:
- move registry bootstrap to an explicit runtime registration module, or make `build_cipher` own core registration bootstrap
- keep the spec layer declarative

---

### F20-04 — active ciphers still depend on `ciphers/dev/base_keyed_cipher.py`

Files:
- `src/rune_decrypter_prime/ciphers/vigenere_cipher.py`
- `src/rune_decrypter_prime/ciphers/autokey_cipher.py`
- `src/rune_decrypter_prime/ciphers/periodic_substitution_cipher.py`
- `src/rune_decrypter_prime/ciphers/periodic_columnar_cipher.py`
- `src/rune_decrypter_prime/ciphers/columnar_transposition_cipher.py`
- `src/rune_decrypter_prime/ciphers/dev/base_keyed_cipher.py`
- `src/rune_decrypter_prime/ciphers/base_keyed_cipher.py`

The active ciphers import `KeyedCipherBase` from `ciphers/dev/base_keyed_cipher.py`, not from the canonical-looking `ciphers/base_keyed_cipher.py`.

Why this matters:
- `dev/` is not really development-only if active ciphers depend on it
- there are now two versions of the same base class
- the non-dev version is the cleaner enum-based one, but the active code path still points at the dev copy

Judgement:
- **strong should-fix**

Recommendation:
- decide which `KeyedCipherBase` is canonical
- move it to one stable non-`dev` path
- update active ciphers to use that one path
- reserve `dev/` for genuinely experimental ciphers only

---

### F20-05 — cipher registry and key-op registry have intentionally different styles, but the difference is not made clear enough

Files:
- `src/rune_decrypter_prime/ciphers/registry.py`
- `src/rune_decrypter_prime/keyops/registry.py`

The key-op registry is:
- enum-backed
- normalised via `ensure_keyops_family`
- explicit about family canonicalisation and alias kwargs

The cipher registry is:
- simple string registry
- lowercases names
- lightweight decorator only

This can be fine, but the repo does not yet make the reason for the asymmetry very clear.

Why this matters:
- extension systems are easier to use when the architectural story is explicit
- otherwise users read it as inconsistency rather than deliberate policy

Judgement:
- **documentation / architecture clarification needed**

Recommendation:
- explicitly state:
  - key-ops are core type families and deserve enum-backed canonical registration
  - ciphers are named runtime implementations and can remain string-registered
- then remove unnecessary wrapper/shim confusion around ciphers where possible

---

### F20-06 — `api/api.py` is effectively dead commented-out compatibility debris

File:
- `src/rune_decrypter_prime/api/api.py`

This file is almost entirely commented out.

Why this matters:
- it creates review drag
- it makes package intent less clear
- it encourages “maybe this still matters” hesitation during refactor work

Judgement:
- **safe cleanup candidate**

Recommendation:
- either delete it
- or replace it with a short explicit redirect note and no large commented body

---

### F20-07 — top-level run execution still hardcodes behaviour that should probably be contract-owned

File:
- `src/rune_decrypter_prime/api/pipeline.py`

`execute_run(...)` still:
- hardcodes `EngineConfig(verbose=True)`
- treats missing seed as `0`
- appears to thread `scorer_name` mainly as a compatibility concept while real behaviour comes from `ScoringConfig`

Why this matters:
- this is exactly the seam that wants to become the core config-runner boundary
- hardcoded values here will make the future run spec feel less trustworthy if not made explicit

Judgement:
- **should-fix during config-runner work**

Recommendation:
- make the core run contract own these defaults clearly
- decide whether `scorer_name` remains meaningful or is retired in favour of scorer-role/config-only selection

---

### F20-08 — telemetry and logging still have overlapping but not identical output ownership

Files:
- `src/rune_decrypter_prime/core/config/logging_config.py`
- `src/rune_decrypter_prime/io/run_logger.py`
- `src/rune_decrypter_prime/telemetry/pipeline.py`
- `src/rune_decrypter_prime/api/logging_utils.py`

Observations:
- `LoggingConfig` already has a sensible run-dir lifecycle and a `redact_identity` flag
- `api/logging_utils.py` does not pass `redact_identity` through from user dicts
- `io/run_logger.py` still writes absolute trace paths into JSONL events
- `telemetry/pipeline.dump_telemetry(...)` has a separate default destination (`output/telemetry/logs`) rather than clearly living under the normal run-dir policy

Why this matters:
- the repo already has most of a canonical artifact/output owner
- but there are still parallel local defaults
- path privacy is stronger in some artifacts than others

Judgement:
- **before-v1 convergence work**

Recommendation:
- unify these under one artifact/output policy owner
- ensure path redaction is consistent across `META`, logging snapshots, JSONL events, trace records, and telemetry dumps

---

### F20-09 — top-level API is close to a clean run-spec front door, but a few pieces still feel transitional

Files:
- `src/rune_decrypter_prime/api/run.py`
- `src/rune_decrypter_prime/api/pipeline.py`
- `src/rune_decrypter_prime/api/specs.py`
- `src/rune_decrypter_prime/core/config/run.py`

Current state:
- `RunAPI.run(...)` is clearly intended to be the main front door
- specs are reasonably typed
- pipeline execution is already the central solve seam
- `RunConfig` still looks more like an internal config object than a stable serialisable user contract

Judgement:
- **good base for the config runner**

Recommendation:
- do not invent a second solve-description system in campaign code
- instead introduce a serialisable `RunSpec` above the current pieces
- then compile that into the pipeline/runtime configs

---

## Design implications from this pass

### 1. The `data` split should happen, but by role rather than by file size

Recommended conceptual split:

- `problem_sources/`
  - LP transcript / locators / partitions / corpus-backed problem extraction
- `assets/` or `resources/`
  - packaged asset-location policy and small metadata helpers
- `fixtures/`
  - tutorial/test/example fixtures and baselines

Important: this is a package-ownership split, not a demand to move large binary assets into the wheel.

### 2. `dev/` folders should become genuinely non-canonical again

Right now `ciphers/dev/` is partly active infrastructure.

Better shape:
- canonical base classes live outside `dev/`
- stable active ciphers live outside `dev/`
- `dev/` contains only experimental or not-yet-stabilised implementations

### 3. The config runner should become the centre of convergence

This pass strengthens the earlier conclusion:
- one serialisable core run spec
- one pipeline owner
- one artifact/output policy owner
- one event telemetry stream
- typed summary reports (`ScorerReport`, probably `SolverReport`)
- campaign layer above that, not beside it

### 4. A little compatibility debris now costs more than it helps

Files like `api/api.py` and duplicated base classes are small individually, but they slow review and make the architecture harder to read.

v1 is a good point to clear them.

---

## Priority from this pass

### Must-fix / very strong should-fix
- remove core runtime dependency on `data.cipher_tests.baseline_registry`
- stop active ciphers depending on `ciphers/dev/base_keyed_cipher.py`
- unify telemetry/logging/artifact output ownership and path-redaction rules

### Should-fix
- remove import-side-effect registration from `api/specs.py`
- decide whether `scorer_name` is still a real contract input
- clean out dead commented compatibility modules like `api/api.py`

### Later / can align with config-runner work
- move LP/data helpers behind a clearer `ProblemSource` abstraction
- document the intended difference between cipher and key-op registries

---

## Bottom line

This pass makes me more confident, not less.

The repo does **not** mainly look like a system missing a lot more architecture.
It looks like a system that already has most of the right pieces, but still needs:

- cleaner ownership,
- fewer misleading package names,
- fewer side-effect seams,
- and one clearer centre of control.

That is good news for v1.

It means the next stage is likely **convergence and cleanup**, not a disruptive redesign.
