# RDP v1 engineering review — pass 18 (data/loading, telemetry, run-boundary convergence)

Date: 2026-03-09
Scope in this pass:
- core data / asset loading seams
- top-level run boundary and config-runner readiness
- telemetry / report / artifact boundary
- remaining holistic design choices suggested by current code shape

This pass is based on the local no-bloat review bundle (`src`, `tests`, and benchmark subtrees). It is still a static engineering review, not a full runtime verdict.

---

## 1) Main judgement from this pass

The repo is now close enough to a coherent v1 shape that the next big step should be **boundary convergence**, not more local feature growth.

The clearest boundary problems now are:
1. **core runtime code still depends on the `data` package for infrastructure**, not just for actual datasets
2. **the top-level run contract is still split across several partially-overlapping fronts**
3. **telemetry and artifact emission still have more than one owner and more than one default path policy**
4. **LP-specific loading currently lives in a generic API surface rather than behind a cleaner problem-source boundary**

This does not look like “missing capability”. It looks like the project has enough capability, but the ownership lines are still blurry.

---

## 2) Strong new findings

### F18-1 — Core scoring path helpers currently depend on the `data` package for infrastructure

Observed shape:
- `scoring/language_model/paths.py` imports `rune_decrypter_prime.data.asset_paths`
- `scoring/hamming/loader.py` also imports `rune_decrypter_prime.data.asset_paths`
- `core/config/run.py` imports `rune_decrypter_prime.data.cipher_tests.baseline_registry` for its default seed

Why this matters:
- `data` should ideally be a content/package layer, not the home of core path-resolution infrastructure
- this is the wrong dependency direction for a future first-class core config runner
- it makes the `data` package feel mandatory even when a caller only wants core runtime behaviour

My view:
- move generic asset/path infrastructure out of `data` into a neutral core support layer
- stop using baseline test data as the source of truth for a core runtime default seed

Severity: **high design debt**, low immediate correctness risk

---

### F18-2 — The top-level run contract still has split ownership

Observed shape:
- `RunAPI.run(...)` is the practical top-level entrypoint
- `RunConfig` exists, but the main API path does not simply accept one serialisable `RunConfig` and run it end-to-end
- `execute_run(...)` still takes a long parameter list rather than one canonical solve-spec/runtime object
- `scorer_name` is passed through to `execute_run(...)`, but in the main engine path the real scorer choice is mostly driven by `ScoringConfig.impl`

Why this matters:
- this is exactly the seam where a first-class config runner should land
- the repo is close, but not yet “one solve spec in, one solve result out”
- partial duplication between `RunAPI`, `RunConfig`, and pipeline execution makes the public story harder to explain

Concrete code smell:
- `execute_run(...)` hardcodes `EngineConfig(verbose=True)` instead of deriving that from one coherent run/logging contract

My view:
- the next major v1 feature should indeed be a **core config runner**
- but it should be built by converging these existing fronts, not by adding a third independent one

Severity: **high**

---

### F18-3 — Telemetry dumping still has a second output policy outside the run-dir policy

Observed shape:
- `telemetry/pipeline.dump_telemetry(...)` writes to `output/telemetry/logs/` by default when no `base_dir` is given
- this is a separate default from the main run-dir lifecycle in `core/config/logging_config.py`
- `io/run_logger.py` writes JSONL under the active run directory instead

Why this matters:
- this splits telemetry/artifact ownership again
- it weakens the “one run -> one artifact bundle” story
- it risks bypassing any future central path-redaction / privacy / retention policy

My view:
- telemetry dumps should, by default, resolve through the **same artifact/run policy** as the rest of the run outputs
- there should not be one default sink for run logging and another default sink for telemetry dumping

Severity: **high design debt**

---

### F18-4 — Telemetry shaping is currently happening in several layers

Observed shape:
- `telemetry/events.attach_telemetry_to_meta(...)`
- `telemetry/pipeline.finalize_run_meta(...)`
- `scoring/scorer_report_builder.py` derives detail sections from scorer telemetry

Why this matters:
- the code is doing the right kind of work, but the shaping boundary is still not fully settled
- scorer telemetry, solver telemetry, run telemetry, and final solution metadata are all being normalised in slightly different places

My current architectural read:
- **telemetry** should remain the detailed event/counter bag
- **ScorerReport** should remain a compact typed scorer summary
- a future **SolverReport** would be sensible as a typed solver summary
- the final `Solution` should carry run-level metadata and references to the summary reports, rather than re-normalising everything in several steps

Severity: **medium-high**

---

### F18-5 — LP-specific loading is currently sitting inside a generic API helper surface

Observed shape:
- `api/data_helpers.py` is essentially a Liber Primus loader/helper module
- it exposes `load_lp_*` functions directly under the generic API package
- multiple helpers call into LP master transcript loading at call time

Why this matters:
- LP is clearly important, but a future config runner should not bake LP-specific concepts directly into the generic run front door
- the cleaner shape is a **problem-source / fixture-source layer** with LP as one implementation

My view:
- keep LP first-class, but move towards:
  - `ProblemSourceSpec`
  - `FixtureLocator`
  - `LPProblemSource`
- then tutorials, solved-page checks, and campaign jobs can all use the same run contract without making the generic API look LP-specific

Severity: **medium-high**

---

### F18-6 — There is a latent default-direction mismatch risk

Observed shape:
- `RunAPI.run(...)` defaults `encoding_dir` to `Direction.RTL`
- `telemetry/pipeline.make_pipeline_block(...)` defaults missing direction to `Direction.LTR`

Why this matters:
- most tested paths pass a direction explicitly, so this may not bite often today
- but it is still the kind of subtle fallback mismatch that creates hard-to-see telemetry drift later

My view:
- direction defaults should come from one canonical owner only
- helper layers should not invent their own fallback direction if the run contract already has one

Severity: **medium**

---

## 3) Holistic design choice I would make now

If I step back and look at all the moving parts together, the cleanest next architecture for v1 looks like this:

### Core RDP should own:
- one **serialisable RunSpec** / config runner contract
- one **ProblemSource** abstraction
- one **ArtifactPolicy** abstraction
- one **telemetry event model**
- one **SolveResult** plus a small set of typed summary reports

### Campaign tooling should own:
- job matrices / sweeps
- shard and fixture bookkeeping
- aggregation / validation / comparison
- campaign-level metadata and provenance

### Scoring should own:
- scorer runtime
- scorer telemetry
- `ScorerReport`

### Solvers should own:
- solver runtime
- solver telemetry
- a future narrow `SolverReport`

That is the best way I can currently see to make:
- tutorials
- solved-page checks
- LP fixture runs
- community campaign runs
- future GUIs / web front ends

all use the same centre of gravity.

---

## 4) New concrete recommendations from this pass

### R18-1 — Introduce a `ProblemSource` boundary

Instead of generic API helpers directly exposing LP functions, move towards a typed problem-source layer.

Illustrative shape only:
- `ProblemSourceSpec(kind=..., locator=..., options=...)`
- `ProblemSourceRuntime.load() -> ProblemPayload`

Likely implementations:
- direct text / direct indices
- LP page / section / locator
- future crib/problem fixtures
- benchmark fixture bundles

This would make the future config runner much cleaner.

---

### R18-2 — Introduce an `ArtifactPolicy` / `ArtifactIO` owner

This should become the one place that owns:
- run-root resolution
- JSON writing
- JSONL append
- canonical JSON for hashing
- path redaction / repo-relative conversion
- telemetry dump placement
- report-sidecar placement

That would absorb a lot of the remaining drift across logging, benchmark reporting, telemetry dumping, and no-WLI auditing.

---

### R18-3 — Make the core config runner the next major feature, but as convergence work

I still think this is the best new feature to add before v1.

But the correct delivery path is:
1. converge the current run contract
2. define one serialisable `RunSpec`
3. provide JSON/YAML loaders on top
4. let campaign tooling wrap that

Not:
- add a separate campaign config format first
- or add a huge free-form bag of internal knobs

---

### R18-4 — Add `SolverReport`, but keep it narrow

I agree with the direction you floated.

My current recommendation:
- keep `ScorerReport`
- add `SolverReport`
- keep both as typed compact summaries
- do not turn them into the telemetry system itself

That preserves:
- rich telemetry for debugging
- stable small summary objects for APIs, campaigns, and GUIs

---

## 5) Priority impact on the broader v1 plan

This pass strengthens these earlier conclusions:

### Must converge before v1
- run contract ownership
- artifact/output policy ownership
- data/asset infrastructure ownership
- scorer/solver/report boundaries

### Good new features still worth adding before v1
- core config runner
- problem-source abstraction
- solver report

### Deprioritise
- more local benchmark-only config dict growth
- more feature-specific helper modules without clearer ownership convergence

---

## 6) Current final view after this pass

I agree with your broad direction.

If I had to compress the current review position into one sentence, it would be:

**RDP is no longer primarily missing features; it is missing a cleaner centre of ownership.**

The good news is that the code now looks close enough that this can be solved by convergence and hardening, not by a rewrite.

---

## 7) Best next review slice

Next I should continue with:
1. the remaining cipher/key-op extension seams
2. the file-saving / path / loader policy across the rest of core and tools
3. then a full “components vs intended architecture” review against the original direction

That should let us finish the broad code review and then circle back to the full component review with a clearer architectural baseline.
