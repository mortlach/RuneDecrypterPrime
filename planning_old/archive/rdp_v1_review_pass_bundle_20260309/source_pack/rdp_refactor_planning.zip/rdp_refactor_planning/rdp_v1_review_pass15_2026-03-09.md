# RDP v1 review pass 15 — core components, telemetry, registries, paths

## Scope for this pass

This pass stays on the local static bundle (`src`, `tests`, and benchmark trees). It is a code-and-contract review, not a runtime verdict.

One important limitation remains: this bundle does **not** include the full packaging / install surface (`pyproject.toml`, `setup.py`, requirements targets, installer scripts, and the full `data/` tree), so the build/install judgement is still partial.

## Main conclusions

The repo is getting closer to a coherent v1 shape, but the remaining drift is now very concentrated in a few cross-cutting areas:

1. the top-level **run/config story** is almost there, but not yet one clean serialisable contract;
2. **telemetry ownership** is still split across several layers;
3. **logging/privacy** policy is not fully threaded through the user-facing API;
4. **registry contracts** are not consistent across ciphers and key-ops;
5. there is still some obvious **shim/debris debt** in core modules.

This is good news overall. These are convergence problems, not signs that the architecture is fundamentally wrong.

---

## Findings

### F15-01 — The repo is ready for a core config runner, but it does not yet have one clean serialisable top-level run contract

Relevant files:
- `src/rune_decrypter_prime/api/run.py`
- `src/rune_decrypter_prime/api/specs.py`
- `src/rune_decrypter_prime/api/pipeline.py`
- `src/rune_decrypter_prime/core/config/run.py`

What I found:
- `RunAPI.run(...)` already behaves like a front door for a solve: it normalises inputs, builds `ScoringConfig` / `SolverConfig`, and delegates into the pipeline.
- `api/specs.py` already has the user-facing `CipherSpec`, `KeySpec`, and `SolverSpec` pieces.
- `core/config/run.py` already has a `RunConfig`, but it is a lower-level config wrapper rather than a true top-level solve spec.
- `RunConfig.asdict()` still clears `optimizer_name` and `optimizer_params` back to `None`, which is a sign that the type is carrying transitional legacy baggage rather than being the single clear contract we would want for a config runner.

Judgement:
- This is the strongest evidence so far that the next major feature should be a **core config runner** built on top of the existing API pieces, not a second independent campaign-only run description.
- The cleaner shape is:
  - core typed run spec for one solve;
  - campaign job spec that wraps it with fixture/shard/sweep/output metadata.

Why it matters:
- tutorials, solved-page fixtures, manual runs, API users, and community jobs could all share one solve description;
- this would reduce pass-through/config drift across the project;
- it would also make GUI/web front ends much easier later.

Recommended direction:
- introduce one serialisable core `RunSpec` / `SolveSpec` above `RunAPI`;
- keep campaign-specific metadata out of that core spec;
- compile the spec into existing `RunAPI` / pipeline machinery rather than inventing a second execution stack.

### F15-02 — Telemetry ownership is still too split

Relevant files:
- `src/rune_decrypter_prime/telemetry/*`
- `src/rune_decrypter_prime/core/telemetry.py`
- `src/rune_decrypter_prime/utils/telemetry.py`
- `src/rune_decrypter_prime/utils/telemetry_utils.py`
- `src/rune_decrypter_prime/io/telemetry_utils.py`
- `tests/telemetry/test_pipeline_block_direction_canonical.py`
- `tests/api_contract/test_pipeline_block_direction_canonical.py`

What I found:
- there is now a proper `rune_decrypter_prime.telemetry` package with bag/events/pipeline/schema helpers;
- but the repo still also carries:
  - `core/telemetry.py` for `_Timer` and an older `Telemetry` dataclass,
  - `utils/telemetry.py` for no-throw dict helpers,
  - `utils/telemetry_utils.py` for pretty/flatten/canonicalisation helpers,
  - `io/telemetry_utils.py` as a deprecated shim.
- tests still import `make_pipeline_block` through the deprecated `io.telemetry_utils` shim, which means that shim is still part of the practical contract.

Judgement:
- Telemetry is not just “a bit duplicated”; ownership is still genuinely split.
- The repo has converged on a canonical telemetry package, but the old helper layers have not yet been reduced to one stable compatibility boundary.

Why it matters:
- telemetry is part of your release evidence story;
- split ownership makes future reporting/schema changes riskier;
- it also makes it harder to know where new telemetry behaviour should live.

Recommended direction:
- keep `rune_decrypter_prime.telemetry` as the only write-side owner;
- keep at most one read-only convenience layer for pretty/access helpers;
- move tests off `io.telemetry_utils` and onto `telemetry.pipeline`;
- after that, shrink or remove the shim layer.

### F15-03 — Privacy/redaction does not currently flow cleanly from the API into logging, and event JSONL can still leak absolute paths

Relevant files:
- `src/rune_decrypter_prime/core/config/logging_config.py`
- `src/rune_decrypter_prime/api/logging_utils.py`
- `src/rune_decrypter_prime/io/run_logger.py`
- `tests/test_logging_paths.py`

What I found:
- core `LoggingConfig` has a `redact_identity` flag;
- `api/logging_utils.normalize_logging_cfg(...)` filters user logging dicts through an allow-list that does **not** include `redact_identity`;
- `io/run_logger.py` logs `trace_written` events containing `path: str(path)`, where `path` is a resolved absolute path;
- current path-hygiene tests check `META.json` and `config/logging.json`, but I did not find a surfaced test that checks `logs/app.jsonl` for path leakage.

Judgement:
- This is a real release-hardening gap.
- The core supports identity redaction, but the user-facing API path does not expose it properly, and the JSONL event stream can still emit absolute filesystem paths.

Why it matters:
- community runs and shared bundles should not accidentally leak machine-specific paths;
- this is exactly the kind of subtle hygiene issue that is easy to miss until release.

Recommended direction:
- allow `redact_identity` through `api/logging_utils.normalize_logging_cfg(...)`;
- stop logging absolute trace paths in `RunLogger.log_trace()`; log a repo/run-relative path token instead;
- add a focused test that reads `logs/app.jsonl` and asserts no absolute machine paths are emitted.

### F15-04 — Registry contracts are not aligned across ciphers and key-ops

Relevant files:
- `src/rune_decrypter_prime/keyops/registry.py`
- `src/rune_decrypter_prime/ciphers/registry.py`
- `src/rune_decrypter_prime/api/wrappers/registry.py`
- `src/rune_decrypter_prime/core/types.py`
- `tests/keyops/test_registry_aliases.py`

What I found:
- key-ops registration is now fairly strict and core-shaped: enum-backed family names, alias normalisation, canonical constructor kwargs, and a tested public `create(...)` path;
- cipher registration is still plain string-based, with aliases handled by multiple decorator registrations on classes/functions;
- wrapper dispatch adds a third layer with its own supported wrapper-core table.

Judgement:
- This is not broken, but it is inconsistent.
- The extension story for key-ops is cleaner than the extension story for ciphers.

Why it matters:
- you specifically mentioned extensible ciphers and registries as part of the holistic review;
- a future config runner will want one predictable way to refer to cipher/key families and implementations.

Recommended direction:
- do **not** necessarily force ciphers into the exact same registry code as key-ops;
- but do align the contract style:
  - one canonical identifier layer;
  - explicit alias handling;
  - one public factory/resolve surface;
  - clear docs on what belongs in wrapper dispatch vs core cipher registry.

### F15-05 — There is still visible shim/debris debt in core files

Relevant files:
- `src/rune_decrypter_prime/core/config.py`
- `src/rune_decrypter_prime/core/logging_config.py`
- `src/rune_decrypter_prime/api/api.py`

What I found:
- `core/config.py` is presented as a temporary re-export shim, but it still contains a very large commented-out legacy implementation after the active shim header;
- `core/logging_config.py` is a genuinely thin re-export shim;
- `api/api.py` appears to be a fully commented-out old public API module.

Judgement:
- This is low risk for correctness but high cost for readability and review friction.
- It is exactly the kind of source-tree debris that should be cleaned before or during v1 hardening.

Recommended direction:
- strip `core/config.py` down to a real thin shim only;
- delete or archive the fully commented `api/api.py` file if nothing imports it;
- keep only the shims that are truly needed for compatibility, and make them obviously thin.

### F15-06 — Data-loading and asset resolution are moving in the right direction, but the core problem-source story is still too implicit

Relevant files:
- `src/rune_decrypter_prime/api/data_helpers.py`
- `src/rune_decrypter_prime/scoring/language_model/paths.py`
- `src/rune_decrypter_prime/scoring/hamming/loader.py`
- `src/rune_decrypter_prime/scoring/span_hamming/calibrated_assets.py`

What I found:
- language-model and hamming loaders already use explicit asset-path helpers and try to emit repo-relative display paths rather than machine paths;
- `api/data_helpers.py` directly imports LP data modules and returns solver-ready payloads;
- the bundle does not include the full `data/` package, so the full source-of-truth story for problem data and packaged assets is only partially visible here.

Judgement:
- The path-resolution direction is good.
- But for a first-class config runner, direct helper imports are not yet the right top-level abstraction.

Recommended direction:
- move towards typed **problem sources** in the future config runner (raw ciphertext, solved fixture, LP locator, benchmark fixture, etc.);
- let those sources resolve into concrete solver payloads at one boundary;
- keep file/path resolution policy central rather than scattered across helpers.

### F15-07 — Build/install review is still incomplete because the relevant files are not in this bundle

What is missing from the review surface:
- `pyproject.toml` / `setup.py`
- requirements targets
- installer/bootstrap scripts
- package data declarations
- full `data/` tree

Judgement:
- I can review the code architecture and contracts seriously from this bundle, but not give a full build/install hardening verdict yet.

Why it matters:
- you explicitly said the overall build and installation story still needs attention;
- that is true, but it is not fully reviewable from the current no-bloat bundle.

Recommended next input if you want that covered:
- a small packaging/install bundle with just the packaging metadata, installer/bootstrap scripts, and any package-data declarations.

---

## Updated whole-project view

The overall picture has not really changed, but it is sharper now.

RDP does **not** mainly look like a project that needs many more big features.
It looks like a project that needs:
- one proper top-level solve/config contract;
- one clearer telemetry ownership model;
- one canonical artifact/logging/privacy policy;
- better convergence around registries and problem sources;
- and a moderate cleanup of shim/debris files.

That is exactly the kind of work that makes a v1 smaller, clearer, and easier to trust.

---

## Suggested next pass

The next useful review pass should go deeper into:

1. **core engine / builder seams**
   - `core/engine/*`
   - `core/problem/*`
   - scorer/cipher builder ownership

2. **cipher extension path**
   - how wrapper ciphers, generic-map ciphers, and registry ciphers relate
   - whether there is one clear “how to add a cipher” story

3. **artifact/output convergence**
   - core logger / telemetry JSONL vs benchmark JSON/JSONL writers
   - whether one shared artifact policy can serve both RDP and campaign code
