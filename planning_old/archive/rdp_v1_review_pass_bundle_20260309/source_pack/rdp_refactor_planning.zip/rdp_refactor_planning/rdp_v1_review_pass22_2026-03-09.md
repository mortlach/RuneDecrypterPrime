# RDP v1 engineering review — pass 22 (2026-03-09)

This pass continues the static engineering review using the local `src` / `tests` / `tools/benchmarks` bundle.

## Theme of this pass

This slice focuses on the question raised in chat:

- can `no_wli` be treated as the same *outer* experiment problem with different inner options?
- what code paths still block that?
- what other architecture seams are still shaping behaviour through historical defaults or local helper patterns?

## Main conclusions

### 1) `no_wli` still lives outside the community campaign **by schema**, not just by missing glue

The current community manifest schema still restricts `flavor` to:

- `col_then_sub`
- `sub_then_col`

So the exclusion of `no_wli` is currently contractual, not accidental. At the same time, `import_community_bundle.py` already accepts `no_wli` as a valid flavour. That mismatch is a strong sign that the campaign layer is part way through a wider transition but has not yet converged.

### 2) The codebase is already hinting at the right abstraction: one outer run/job model, multiple runner policies

The current community layer still chooses a runner from a small hard-coded flavour map and then bridges into that runner by importing the module and calling `main()`. That is not yet a general run model.

But the shape of the repo strongly suggests the better target:

- one **outer run/job contract**
- one **core solve/run contract** underneath it
- runner policy chosen from typed problem/strategy fields
- WLI / no-WLI differences expressed as options and role bindings, not as separate campaign worlds

That is the cleanest route if the project wants `no_wli` to become a first-class campaign participant without turning the campaign system into a pile of special cases.

### 3) The current community bridge still proves the need for a proper config runner

`_run_single_job.py` still does all of these:

- pick a runner from a hard-coded flavour table
- import the runner module by name
- call its `main()`
- infer the output run directory from pre/post directory diffs
- scrape files afterwards to reconstruct the result row

That is good evidence that the missing abstraction is now a **typed run spec / config runner**, not more ad hoc wrapper glue.

### 4) Logging / telemetry privacy policy is still split in a way that matters for v1

A few seams still point in different directions:

- `api/logging_utils.py` resolves configured paths to absolute paths
- `io/run_logger.py` resolves the run dir and trace paths to absolute filesystem paths
- `telemetry/pipeline.py` still has its own default mirror destination at `output/telemetry/logs/`

So path/privacy policy is still not owned by one canonical artifact/output layer.

### 5) Top-level run execution still hardcodes engine behaviour in a way a config runner should own instead

Both `api/pipeline.py` and `api/fastpaths.py` still build `EngineConfig(..., verbose=True, ...)` directly.

That is a small but revealing design smell:

- top-level user-facing entrypoints are still injecting runtime policy directly
- the eventual config runner wants to own that policy instead
- the current stack is therefore close to, but not yet fully ready for, a single serialisable run contract

### 6) The repo still has a few “historical shape leaks” that should be cleaned up before the config-runner push

The clearest examples in this pass are:

- `RunConfig` default seed still sourced from `data.cipher_tests.baseline_registry`
- active ciphers still depending on `ciphers/dev/base_keyed_cipher.py`
- API/data helpers still exposing LP-specific loading through a generic helper module
- wrapper/registry layers still relying on import-time registration and side effects in places

None of these blocks progress, but together they make the system harder to explain and harder to expose cleanly through a public config-runner interface.

## Updated architectural judgement

I now think the right direction is even clearer than before:

### Core RDP should gain a first-class **config runner**

But it should be built around a strict typed run model:

- `ProblemSource` / problem payload selector
- cipher spec
- key spec
- solver spec
- scorer-role specs
- logging / artifact policy
- optional expectations / fixture metadata

### Campaign should sit one layer above that

Campaign should add:

- job identity
- shard identity
- sweep metadata
- fixture selection / matrix metadata
- output aggregation metadata
- reproducibility pins

That gives one closed system while keeping campaign bookkeeping out of the core solve contract.

## Specific recommendations from this pass

### Must-fix or must-decide before the config-runner work

1. Generalise the community manifest/job schema beyond the two current flavour enums.
2. Replace the `_run_single_job.py` bridge model with a typed run invocation boundary.
3. Unify path/privacy/output ownership before more public config is added.
4. Move runtime defaults out of data/test packages.

### Strong should-fix next

5. Stop hardcoding `verbose=True` in top-level entry paths.
6. Pull LP loading behind a clearer `ProblemSource` boundary.
7. Clean up active imports from `ciphers/dev/*` and other historical folders whose names no longer match their role.

## Keep / merge / regroup note

This pass strengthens the earlier no-WLI conclusion:

- do **not** merge the no-WLI split back into one huge file
- do **not** keep treating it as a structurally separate campaign world forever
- instead, keep the stage decomposition but move toward one outer run model with different internal policies

That is the best route I can currently see to:

- keep solving fidelity
- support hard no-WLI work
- bring no-WLI under the same distributed experiment umbrella
- and make the system more coherent for tutorials, APIs, GUIs, and community runs

## Current overall position

The repo still looks like a **convergence project** much more than a missing-features project.

The one major new feature that still looks clearly worth adding is the **core config runner**.

But even that should be treated mainly as convergence work:

- make the run contract explicit
- make the problem-source boundary explicit
- make scorer roles explicit
- make artifact/output policy singular
- then let campaign and future front ends reuse that same system
