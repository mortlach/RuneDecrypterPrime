# RDP v1 review – pass 33 (final tiny sweep before collation)

Date: 2026-03-09
Surface: local no-bloat review bundle (`src`, `tests`, benchmark subtrees)
Mode: static engineering review

## Purpose of this pass

This pass is the last narrow raw-gathering sweep before collation. The goal was to look for any remaining high-signal anti-drift or cleanup-safe issues that are easy to miss in a long review.

## New findings

### 1) Periodic benchmark runners still depend heavily on `globals()` choreography

The runner split was the right move, but the active periodic benchmark flavours still rely on module-global state passing as a real control mechanism rather than just simple top-level constants.

Observed active usages in surfaced code:
- `tools/benchmarks/periodic_sub_trans/no_wli/runner.py`
- `tools/benchmarks/periodic_sub_trans/col_then_sub/runner.py`
- `tools/benchmarks/periodic_sub_trans/sub_then_col/runner.py`
- `tools/benchmarks/periodic_sub_trans/no_wli/run_fixture_matrix.py`

This is one of the clearest remaining architectural smells in the benchmark/campaign system. The missing abstraction is still a typed run/job spec plus an explicit runner state object, not more helper functions around module globals.

Judgement:
- medium severity for v1
- not necessarily a correctness bug today
- high maintenance and anti-drift risk

Recommendation:
- replace `state=globals()` flow with an explicit runner-state dataclass or typed config object when the config-runner work starts
- do not try to "clean" this piecemeal without that higher-level runner contract

### 2) Several anti-drift guardrail tests are present but not actually enforcing the rule

The repo has good anti-drift instincts, but there are still guardrail tests whose key assertions are commented out.

Examples found in surfaced tests:
- `tests/guardrails/test_only_scoring_can_say_fwd_rev.py`
- `tests/guardrails/test_pipeline_block_direction_canonical.py`
- a weaker pattern also appears in `tests/telemetry/test_schema_contract.py`

This matters because these tests look like policy enforcement, but in their current state they are partly documentary rather than active.

Judgement:
- low severity for immediate runtime correctness
- medium severity for long-term drift prevention

Recommendation:
- review every `tests/guardrails/*` file and classify each as:
  - keep and enforce now
  - revise and enforce later
  - retire because policy changed
- avoid leaving "pretend guardrails" in the tree

### 3) Compatibility/shim debt is still visible enough to blur ownership

This pass also confirmed that some deprecation/shim surfaces are still visible in active package space:
- `src/rune_decrypter_prime/core/config.py` still presents itself as a compatibility layer and carries historical clutter
- `src/rune_decrypter_prime/io/telemetry_utils.py` is a deprecated shim, while tests and surrounding code still reflect the older split ownership story

This reinforces earlier findings: the repo is close to convergence, but old owners are still visible enough to make the final architecture harder to read than it should be.

Judgement:
- low immediate correctness risk
- medium repo-clarity and maintenance cost

Recommendation:
- when collation starts, create a dedicated "safe cleanup / shim retirement" bucket separate from more invasive architecture changes

## Updated overall judgement after this pass

This pass did not reveal a new major subsystem risk. It mostly confirmed the existing picture:
- the repo is in a finishing/convergence phase
- the biggest needs are explicit contracts, stronger anti-drift enforcement, and clearer ownership
- the core missing abstraction is still a first-class config runner / run spec
- the benchmark/campaign side still wants a typed state model instead of module-global choreography

## Readiness to switch from gathering to collation

After this pass I think raw static gathering is effectively complete for the uploaded bundle.

My honest assessment now:
- ~97–98% of the useful static engineering review is done
- the remaining value is now mainly in collation, prioritisation, and architecture cross-check

So the next best move is no longer "keep hunting for more small issues".
The next best move is:
1. collate findings
2. group into must-fix / should-fix / later
3. map to target architecture and repo shape
4. turn into a v1 hardening programme

