# RDP v1 review — pass 31 (boundary/examples/config-runner readiness + packaging caveats)

Date: 2026-03-09
Scope: final narrow sweep over boundary/examples/tutorials/config-runner readiness, script-vs-library drift, and packaging/build caveats within the uploaded no-bloat surface.

---

## 1) Current judgement

This pass strengthens a now-consistent overall view:

- the **library/API side is close to the right shape** for a first-class core config runner;
- the **tutorial/campaign/script side is still more script-oriented than it should be**;
- the **main missing convergence step is one serialisable run-spec boundary**, not more local helpers;
- the uploaded bundle is **good enough for a strong static engineering review**, but **not enough to fully review packaging/install**, because key repo-root files are not present.

In other words, the core is close, but the outer shell still behaves more like “useful scripts around a library” than “one coherent product surface”.

---

## 2) Config-runner readiness: stronger than it first looked

The good news is that the repo is already **partly living in the future design**:

- `api/README.txt` already describes `RunAPI` as the canonical front door.
- `CipherSpec`, `KeySpec`, and `SolverSpec` already give the repo a declarative solve vocabulary.
- tutorial tests already solve through `RunAPI.run(...)` / `run(...)` rather than directly constructing low-level engines.
- the benchmark/community side is already forcing more serialisable config and result contracts.

That means a **core config runner is not a speculative new subsystem**. It is mainly a convergence step over machinery that already exists.

### New refinement from this pass

The best target now looks like:

- **Core `RunSpec` / config runner** for one solve
- **Campaign job spec** wrapping that for distributed execution
- **Tutorial examples** migrated onto the same core run-spec surface

This is better than keeping tutorials as one API style, campaign as a second style, and script runners as a third style.

---

## 3) Boundary drift: tutorials and examples are still split between library use and script/process use

A concrete sign of this split:

- tutorial tests mostly call `RunAPI.run(...)` or `run(...)` directly;
- but other tutorial tests still execute top-level scripts from `tutorials/v1/...` by filesystem path;
- meanwhile `src/rune_decrypter_prime/README.md` still says tutorials live under `rune_decrypter_prime/examples/`.

So the repo is currently carrying **three tutorial stories at once**:

1. tutorial as library call;
2. tutorial as top-level script;
3. tutorial as package-local example path (documented, but not matching the tested tree).

That is exactly the kind of low-level drift that a core config runner would clean up.

### Recommendation

For v1:

- keep tutorials as top-level human-facing material;
- stop treating them as a second-class package-local examples system;
- migrate tutorial execution to a shared config-runner path, even if the scripts remain as thin wrappers.

That gives you **one truthful solve story** for tutorials, API usage, and later GUI/web use.

---

## 4) Tutorial/tests still pull on fixture-style data in ways that strengthen the earlier `data` split recommendation

This pass also reinforces the earlier point that `data/` wants splitting.

Example:

- `tests/tutorials/test_mono_substitution.py` imports tutorial plaintext from `rune_decrypter_prime.data.cipher_tests.plaintext`.

That means tutorial-level example material is still tied to the same broad `data` package that is also being used for other infrastructure-adjacent purposes.

### Recommendation

Keep separating:

- packaged asset-location policy;
- reusable problem-source definitions;
- test/tutorial fixture text.

That will make the future config runner easier to reason about because “problem source” and “example/test fixture” stop being conflated.

---

## 5) `RunAPI` is close, but still not fully serialisable as a public long-term solve contract

A closer look at `api/run.py` strengthens an earlier concern.

`RunAPI.run(...)` still exposes several surfaces as loose bags:

- `scorer: str`
- `scorer_params: Optional[Dict[str, Any]]`
- `logging: Optional[Dict[str, Any]]`
- various optional interruptor dict-like surfaces

This is fine for a forgiving boundary, but it is **not yet the end-state** for a first-class serialisable run contract.

### Recommendation

The config-runner work should not just wrap `RunAPI.run(...)` as-is.
It should:

- preserve boundary forgiveness for hand-written Python calls;
- but introduce one **typed serialisable run-spec schema** that compiles into the current pipeline.

That keeps the API friendly while finally giving the repo a single durable solve contract.

---

## 6) Script-vs-library drift is still heavy in the tool/campaign layer

This pass found more evidence that the outer layer is still too script-shaped.

Observed in the uploaded surface:

- `sys.path.insert(...)` use is still widespread in `tools/`.
- direct `print(...)` use remains high in benchmark/campaign code.
- community docs still orient contributors around invoking top-level Python scripts and repo bootstraps.

Measured in the local review surface:

- `tools/**/*.py` currently contains **77** `sys.path.insert(...)` calls across **45** files;
- `tools/**/*.py` currently contains **522** `print(...)` calls across **59** files;
- even after ignoring the legacy `no_wli/old/` runner snapshots, the active benchmark tree still uses direct console printing heavily.

This does not mean scripts are bad. It means the **library boundary is not yet strong enough**, so scripts are still compensating locally.

### Recommendation

For v1:

- keep thin top-level scripts where useful;
- but make them wrappers over library owners rather than local bootstrap/assembly points;
- reduce `sys.path.insert(...)` and local path guessing in active first-class surfaces.

That would also make AI-agent adherence easier, because there would be fewer “special shell paths” and more explicit callable owners.

---

## 7) Packaging/build/install caveat: review is necessarily partial here

This pass confirms an important limitation.

The uploaded no-bloat bundle does **not** contain:

- `pyproject.toml`
- `setup.py`
- `setup.cfg`
- `MANIFEST.in`
- root-level `requirements/`
- `install.py`

So I can review **how code assumes installation works**, but not the full packaging/build truth itself.

What *is* visible still tells a useful story:

- community docs treat `python install.py` as the setup front door;
- community bootstrap code references `requirements/targets/*.txt` and `install.py` outside the uploaded surface;
- `src/README.md` explicitly mentions build outputs under `src/build_tmp_fastlm/` and `src/build_lib_fastlm/`.

### Judgement

Within the visible surface, the build/install story still looks **tooling-driven and repo-local**, not yet like one clean product installation contract.

That is not a blocker for this static review, but it does mean the final v1 programme should include a **separate packaging/install review** against the full repo root.

---

## 8) One concrete repo-shape smell from this pass: source tree still mentions build outputs as source-adjacent

`src/README.md` currently documents:

- `src/build_tmp_fastlm/`
- `src/build_lib_fastlm/`

as “build artifacts”.

Even as documentation, this is a small but telling sign that build outputs are still conceptually too close to the source tree.

### Recommendation

For v1, I would prefer:

- source tree describes source;
- build outputs and generated artifacts live under a clearly separate build/output owner;
- no build-temp naming should feel like part of the long-term package shape.

This matches the broader repo-shape direction already emerging elsewhere.

---

## 9) What this pass changes in the overall review

This pass does **not** change the core direction.
It strengthens it.

### Stronger than before

- first-class core config runner is the right late feature;
- tutorials should converge onto that surface;
- `tools/benchmarks` really does want to become a first-class campaign area;
- the `data` split remains necessary;
- script/bootstrap behaviour is still too prominent in active first-class surfaces;
- packaging/install needs its own final review against the full root.

### New sharper wording

The repo now looks like this:

> **The inside is closer to product shape than the outside.**
>
> Core solve concepts, specs, and scoring are approaching a converged centre.
> The surrounding tutorial/campaign/script/build shell still needs to be made truthful.

That is actually good news, because it means the hardening phase is mainly about making the **outer contract** match the **inner architecture**.

---

## 10) Remaining review before collation

After this pass, the remaining useful gathering work looks very small.

I would estimate:

- **90–95%** of the useful static engineering review is now done;
- **5–10%** remains.

The remaining worthwhile slices are now only:

1. one final packaging/build/install caveat note (explicitly marked partial);
2. one last safe-cleanup and shim-debt sweep if needed;
3. then stop gathering and switch to collation.

At this point, continuing to collect lots of new findings is likely to have diminishing returns compared with organising the review into:

- must-fix;
- should-fix;
- later;
- architectural direction;
- repo-shape proposal;
- config-runner proposal;
- anti-drift policy set.

---

## 11) Current overall recommendation after pass 31

If I compress the whole review so far into one sentence:

> **RDP should now converge on one core run-spec/config-runner, one artifact/output policy, one campaign framework, and stricter internal anti-drift enforcement — while moving first-class campaign code out of `tools/` and splitting `data/` into clearer owners.**

That still looks like the strongest route to v1.
