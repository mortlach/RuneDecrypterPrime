# RDP v1 review pass 17 — report objects, telemetry shape, and holistic runner design

## Scope

This pass reviews the current shape of:
- `ScorerReport`
- scorer telemetry collection and sidecar writing
- solver telemetry and whether a `SolverReport` object would help
- how these pieces should relate to a future first-class core config runner

Review surface used in this pass:
- `src/rune_decrypter_prime/scoring/scorer_report.py`
- `src/rune_decrypter_prime/scoring/scorer_report_builder.py`
- `tools/benchmarks/periodic_sub_trans/common/scorer_sidecar.py`
- `src/rune_decrypter_prime/solvers/solver_base.py`
- `src/rune_decrypter_prime/telemetry/events.py`
- `src/rune_decrypter_prime/telemetry/pipeline.py`
- `src/rune_decrypter_prime/api/run.py`
- `src/rune_decrypter_prime/api/pipeline.py`
- `src/rune_decrypter_prime/api/pipeline_helpers.py`
- `tests/scoring/test_scorer_report_builder.py`
- `tests/scoring/test_scorer_report_json_safe.py`

## Main conclusion

The repo is now at the point where it needs a **clear report model hierarchy**.

My current recommendation is:

1. **Keep `ScorerReport`** as a typed, scorer-local artifact.
2. **Do add a `SolverReport`**, but only as a typed summary of solver execution, not as a second telemetry system.
3. **Do not replace telemetry with report objects.**
4. Instead, make telemetry the event stream / evidence trail, and make report objects the compact structured summaries derived from that work.

In plain English:

- telemetry = detailed event bag, spans, counters, timestamps, diagnostic details
- report objects = stable summaries for downstream use, sidecars, APIs, and GUIs

That gives a cleaner long-term shape than trying to make `meta["telemetry"]` do every job.

## What is good in the current `ScorerReport` design

The existing `ScorerReport` is one of the cleaner new abstractions in the repo.

Good properties:
- typed dataclass
- explicit objective string and objective spec
- explicit score / raw score / cost
- telemetry separated from numeric metrics
- JSON-safe normalisation built in
- non-finite values rejected at serialisation time

The builder also already extracts higher-level detail sections from scorer telemetry, including:
- span-hamming
- word-ngram judge data
- span language-model data
- hamming dictionary policy diagnostics

That means the repo already has the start of a sensible pattern:
- runtime scorer state stays in the scorer
- report builder extracts a stable snapshot
- downstream benchmark code writes that snapshot to JSONL

## Current weakness in the scorer-report seam

The current pattern is useful, but not fully clean yet.

### 1. Builder still depends on live scorer object shape

`build_scorer_report(...)` reads both:
- `scorer.telemetry()`
- `scorer.last_stats()`

That is convenient, but it means the report contract is still coupled to mutable runtime scorer APIs.

For v1, I would prefer this direction:
- keep the current builder for compatibility
- but gradually move towards building reports from an explicit scorer-result snapshot
- not from ad hoc reads of mutable scorer methods after the fact

This is especially relevant because some current benchmark code already relies on `last_stats()` behaviour in ways that look more transitional than final.

### 2. Benchmark writing is still local-sidecar style, not one canonical report lane

`append_scorer_report_jsonl(...)` is clean enough, but it lives in benchmark code and currently writes rows of the form:
- `{"report": ..., "context": ...}`

That is fine for now, but it still means the repo does not yet have one canonical answer to:

> where do report objects live, and who owns their file contract?

This should probably converge alongside the broader JSON / JSONL / hash / path-policy clean-up already identified in earlier passes.

## Should there be a `SolverReport`?

Yes — but with a narrower scope than your first idea suggests.

I do **not** think solver telemetry should become just another big free-form report object. The current solver telemetry system already has useful semantics:
- `solver_start`
- `solver_progress`
- `solver_end`
- run start/end
- solver spans
- progress lists
- pipeline blocks

That is event-oriented telemetry, and it is the right basic shape for runtime tracing.

What is missing is a compact, typed summary that downstream code can rely on without parsing the whole telemetry bag.

So I would add a `SolverReport` with fields roughly in this family:
- solver name
- seed
- device
- direction / pipeline block summary
- candidate counts / token counts / score calls / decrypt calls
- elapsed time / scorer time / decrypt time
- stop reason
- best score
- accepted key summary or best-key summary
- optional progress summary
- optional solver-specific details block

That report should be built **from the final result + telemetry**, not become a second source of truth.

## Best holistic design choice from the current repo state

From what is in the code now, I think the cleanest final model is a **three-layer structure**.

### Layer 1: runtime telemetry (event bag)

Owned by the telemetry helpers and runtime objects.

Purpose:
- best-effort detailed evidence
- spans, counters, progress, stage timings
- debugging and diagnostics
- rich but not necessarily minimal

Examples already present:
- `telemetry/events.py`
- `telemetry/pipeline.py`
- `problem.telemetry`
- solver span helpers in `solver_base.py`

### Layer 2: typed reports

Owned by dedicated report builders.

Purpose:
- stable compact summaries
- JSON-safe downstream artifacts
- benchmark sidecars
- API return attachments
- GUI/web consumption

This layer should include at least:
- `ScorerReport`
- future `SolverReport`
- possibly later `RunReport` or `SolveReport`

### Layer 3: artifact/output policy

Owned by one shared artifact writer policy.

Purpose:
- where reports go
- JSON/JSONL contract
- hashing and integrity
- path redaction
- context envelope shape

Right now this ownership is still split across benchmark-local code.

## What I would *not* do

### 1. Do not make every subsystem invent its own report class immediately

A large family of tiny report dataclasses could become another form of repo bloat.

I would only add new report objects where they buy real clarity.

At the moment I think the justified ones are:
- `ScorerReport` (already present)
- `SolverReport` (likely worth adding)

I would hold off on more until those two settle.

### 2. Do not turn telemetry into the only public downstream contract

The telemetry bag is useful, but it is not clean enough to be the whole downstream interface forever.

It is too easy for telemetry to grow organically and carry implementation-specific detail.

That is why typed reports are useful.

### 3. Do not make report objects replace proper `Solution` / `RunResult` objects

Reports are summaries, not the primary runtime truth.

The core run result still needs to carry plaintext, key, meta, direction, WLI, pipeline info, and so on.

## How this fits a future first-class core config runner

A future core config runner makes this design more useful, not less.

Best shape I can currently see:

- **RunSpec** (serialisable input contract)
- **RunResult / Solution** (full solve output)
- **ScorerReport** (scoring summary)
- **SolverReport** (solver summary)
- optional **RunReport** as the top-level summary envelope if needed

The config runner would execute one run and return a structured result. It could then optionally emit:
- telemetry event stream
- scorer report sidecar
- solver report sidecar
- summary manifest row

This is much cleaner than forcing GUIs or campaign code to scrape large mutable telemetry bags directly.

## Concrete recommendation for v1

### Keep
- current `ScorerReport`
- current builder pattern
- current telemetry event helpers

### Add
- a narrow `SolverReport`
- one shared report/artifact writer for report JSONL emission
- one explicit place on the final run result for attached reports

### Refine
- move report building away from post hoc mutable scorer reads over time
- keep telemetry detailed, but make reports the preferred downstream summary contract
- define exactly what is guaranteed to be stable in reports vs telemetry

## Strongest design judgement from this pass

If I step back and look at the whole repo state, I think the best long-term shape is:

**RDP core should expose one serialisable run contract, one full solve result, one event-style telemetry stream, and a small set of typed summary reports.**

That is the most coherent route I can see from the current codebase to:
- core API use
- tutorials/examples
- campaign jobs
- LP page experiments
- GUI/web front ends
- reproducible community sweeps

without letting the system drift into either:
- one giant mutable telemetry blob, or
- a forest of duplicated local report formats.
