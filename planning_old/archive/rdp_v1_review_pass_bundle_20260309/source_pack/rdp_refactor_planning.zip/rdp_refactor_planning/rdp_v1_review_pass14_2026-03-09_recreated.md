# RDP v1 review - pass 14 (recreated)

## Focus of this pass

This pass addresses the question of whether RDP itself should gain a first-class config runner, how that should relate to campaign workflows, and what other late-stage feature work is still worth considering before a v1 push.

The conclusion of this pass is that a **core config runner** is one of the very few major new features still worth adding before v1, because it is a convergence feature rather than more exploratory surface area.

## Main conclusion

The cleanest v1 direction is:

- **one first-class core config runner in RDP**
- **campaign tooling layered above it**
- **one shared solve-description system**, not two unrelated ones

In other words:

- RDP should own the config model for “run one solve”
- campaign tooling should own the config model for “run many jobs, organise sweeps, and collect results”
- campaign jobs should call into the same core solve runner rather than bypassing it with a parallel solve-description path

That gives tutorials, examples, solved-page fixtures, campaign jobs, and future GUIs one coherent front door.

## Why this fits the repo better

The repo already looks closer to this shape than it may seem.

- The API package is explicitly described as the external entry point.
- `RunAPI` is already framed as the canonical solve entrypoint.
- The main pipeline already does most of the right kinds of work: normalising inputs, building configs, materialising problems, and running engines.

So the missing piece is not a brand new paradigm. It is a cleaner, serialisable, first-class configuration boundary above machinery that already exists.

## Recommended layering

### 1. Core run spec

A core run spec should describe **one solve**.

Suggested responsibility:

- problem source
- ciphertext source / locator
- cipher family / mode
- key plan / key-op plan
- solver family and options
- scorer-role definitions
- telemetry / reporting options
- optional expectations or assertions

This should be the thing tutorials, examples, solved LP fixtures, and simple scripted solves all use.

### 2. Campaign job spec

A campaign job spec should describe **one campaign job** that wraps a core run spec.

Suggested responsibility:

- fixture identity
- campaign identity
- shard/job identity
- sweep metadata
- output routing
- run labels / provenance
- result aggregation metadata

That way the campaign layer does not need its own competing solve-description language. It just enriches a core run spec with experiment-management concerns.

## Important caution

The right answer is **not** a giant free-form YAML or JSON bag containing every internal knob in the repo.

That would make front ends easier in the short term, but it would also freeze a lot of accidental internal detail into the public contract.

The better route is:

- a typed serialisable run spec
- strict schema validation
- clear defaults
- role-based scorer composition
- compile to lower-level internal configs at the boundary

## Scorer direction

The scoring side is one of the reasons this matters.

The newer scoring features are real, but benchmark code is still expressing several distinct scorer jobs through copied config dicts and runner-local plumbing.

The better final shape is not “one even bigger bag of scorer flags”.

It is **explicit scorer roles**, for example:

- `search_primary`
- `basin_judge`
- `gate`
- `report_word_ngram`
- `report_span`
- `report_aux`

Those roles can then compile into concrete scoring configs at the boundary.

That keeps benchmark-local intent out of the core scorer contract while still allowing rich scorer combinations.

## Why this is worth doing before v1

This is one of the few remaining features that genuinely helps almost every part of the project at once:

- core API usability
- tutorials and example solves
- LP and solved-page fixtures
- benchmark reproducibility
- community campaign workflows
- future GUI or web front-end support
- cleaner provenance and result comparison

So although it is a feature, it is really a **convergence feature**.

## Other late-stage feature work still worth considering

Only a small number of things still look worth adding before v1:

1. **Core config runner**
2. **Fixture / locator-backed problem sources** so tutorials, LP pages, and campaign jobs can use the same entrypoint
3. **Explicit scorer-role contract** rather than wider copied config dicts
4. **Canonical artifact/output policy** for JSON, JSONL, hashing, and path redaction

Everything else should mostly be hardening, simplification, tuning, and proof.

## Broader review note

The rest of the system still does need holistic review and convergence work, especially around:

- telemetry ownership
- extensible ciphers
- key-op registries
- file saving
- data path handling
- file loading
- build/install story

The current local review bundle is strong for `src`, `tests`, and benchmark subtrees, but it is not a full build/install surface. So judgement on packaging and installation is still more partial than judgement on core code and benchmark wiring.

## Current recommendation

The one major new feature I would still actively support before v1 is:

**a first-class core config runner**

implemented in a way that campaign tooling can build on directly.

Everything else should mostly serve:

- hardening
- convergence
- simplification
- debloating
- tuning
- proving the system works

## Practical design rule

A good test for whether a new addition should be allowed before v1 is:

> Does this reduce the number of distinct ways to express and run a solve?

If yes, it is probably a convergence feature and worth considering.
If no, it is probably more alpha churn and should be resisted.
