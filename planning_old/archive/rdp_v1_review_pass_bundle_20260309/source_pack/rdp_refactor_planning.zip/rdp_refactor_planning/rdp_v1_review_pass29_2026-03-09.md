# RDP v1 review – pass 29 (repo shape, campaign vs tools, solving surfaces)

Date: 2026-03-09
Scope in this pass:
- repo-shape review against the user’s updated direction
- whether `tools/benchmarks` should stay under `tools`
- whether a first-class `solving` / `campaign` surface now makes sense
- where I agree, and where I would sharpen the structure differently

---

## 1) Main judgement

I agree with the direction.

From the current code shape, `tools/benchmarks` is no longer acting like a private helper area. It is already behaving like a **first-class product surface**:
- it has schemas, examples, fixtures, orchestration, import/export, validation, and many direct tests against it
- benchmark paths and outputs are treated as stable contracts
- community execution is already using it as the organiser/runner surface rather than as an ad hoc scratch area

So I think the repo has drifted into a misleading structure:
- the **name** says “tools”
- the **actual role** is now closer to “campaign system” or “experiment system”

That mismatch is worth fixing before v1.

---

## 2) Evidence that `tools/benchmarks` is already first-class

### 2.1 Tests treat it as core surface, not incidental helper code

`tests/community/conftest.py` explicitly says community tests use repo-relative fixture paths under `tools/...`, `docs/...`, and `assets_packed/...`, and it forces the working directory to repo root so that contract stays stable.

That is not how people normally treat a personal helper directory.

### 2.2 Community tests and result flow hardcode benchmark paths as contract

`tests/community/test_run_shard_v1_1.py` imports directly from `tools.benchmarks.community`, and repeatedly loads:
- `tools/benchmarks/community/examples/campaign_config_v1_1.json`
- `tools/benchmarks/community/profile_catalog_v1_1.json`
- `tools/benchmarks/community/schemas/manifest_schema_v1_1.json`
- `tools/benchmarks/community/schemas/result_schema_v1_1.json`

Again, that is first-class system behaviour, not private helper glue.

### 2.3 Output layout mirrors `tools/benchmarks` on purpose

`tools/benchmarks/periodic_sub_trans/common/paths.py` defines the canonical benchmark output root as:
- `output/tools/benchmarks`

and the helper explicitly says this mirrors the `tools/` path under output.

That makes the current repo layout part of the persisted artifact contract.

### 2.4 Community bootstrap is also built around `tools/benchmarks`

`tools/benchmarks/community/bootstrap.py` uses fixed paths under `tools/benchmarks/community/...` for the default campaign config, profile catalog, setup script, manifest generation, sharding, and shard execution.

So the benchmark system is not only *stored* there; it is *defined* there.

---

## 3) My view on your proposed top-level split

I think you are basically right, with one important refinement.

### 3.1 Benchmarks / campaigns should move out of `tools`

Yes.

But I would seriously consider naming the top-level folder **`campaigns/`** rather than `benchmarks/`.

Why:
- what you described is broader than benchmarking
- it is becoming a **distributed experiment system**
- some runs are not “benchmarks” in the narrow sense; they are tuning, fitting, fixture-based validation, or community solve sweeps

So the shape I currently prefer is:

```text
campaigns/
  community/
  periodic_sub_trans/
```

with the current community and periodic benchmark code moved there.

If you want to keep the word “benchmark” for continuity, a compromise would be:

```text
campaigns/
  benchmarks/
  community/
```

but I think that is probably one layer too many.

### 3.2 `tools/` should stay small and honestly auxiliary

I agree that `tools/` should become what you intended it to be:
- helper scripts
- repo-sharing helpers
- documentation helpers
- one-off tidy/sweep utilities
- migration helpers

That means anything that is:
- schema-backed
- test-backed as a public contract
- used by organisers/runners/contributors as a normal workflow

probably should **not** live under `tools/` long-term.

### 3.3 A first-class solving surface also makes sense

Yes, but I would be careful with the exact shape.

I agree there should be a clearer first-class surface for:
- tutorials
- reproducible example solves
- LP-based solves
- solved-page fixtures / validation cases
- future config-runner examples

However, I would **not** bundle all of that under one folder called `solving/` unless the semantics are very clear.

My preferred split is:

```text
tutorials/
  v1/

problem_sources/
  liber_primus/
  fixtures/

campaigns/
  ...
```

Reason:
- `tutorials/` are for humans learning the system
- `problem_sources/` are reusable machine-readable inputs / locators / fixture-backed payloads
- `campaigns/` are distributed experiment workflows

If you put tutorials under `solving/`, that can work, but I think it risks mixing “human teaching material” with “machine-facing fixture/problem definitions”.

So my mild pushback is:
- **yes** to a clearer solving surface
- **no** to overloading one folder with too many roles if we can separate them cleanly

---

## 4) There is already evidence of shape drift around tutorials/examples

The repo already shows this kind of drift today.

`src/rune_decrypter_prime/README.md` says tutorials live in:
- `rune_decrypter_prime/examples/`

But `tests/tutorials/test_railfence_tutorial.py` expects an actual top-level script at:
- `tutorials/v1/Tutorial_Railfence.py`

So the public story and the tested story already disagree.

That is a good example of why a repo-shape pass matters now.

---

## 5) What I think should become the three first-class repo surfaces

Given the current state, I think RDP wants three clearly named first-class surfaces:

### A. `src/rune_decrypter_prime/`
The actual library and public API.

Owns:
- ciphers
- keyops
- scorers
- solvers
- telemetry
- config types
- config runner
- problem-source abstractions
- artifact/output policy

### B. `campaigns/`
Distributed experiment / benchmark / organiser-runner infrastructure.

Owns:
- manifests
- shard generation
- run orchestration
- aggregation
- community run bundle import/export
- campaign schemas
- campaign examples
- campaign fixtures and sweep metadata

### C. `tutorials/` and `problem_sources/`
Two related but distinct surfaces.

`tutorials/` owns:
- user examples
- teaching scripts
- example config runs
- simple reproducible solve walkthroughs

`problem_sources/` owns:
- LP master transcript accessors
- solved-page locators
- fixture-backed ciphertext/plaintext sources
- reusable problem registries

This is cleaner than trying to force all three into either `src/` or `tools/`.

---

## 6) What should probably *not* stay where it is

### 6.1 `tools/benchmarks/community`
This is already closer to `campaigns/community`.

### 6.2 `tools/benchmarks/periodic_sub_trans`
This is already closer to `campaigns/periodic_sub_trans`.

### 6.3 `tools/benchmarks/scoring`
This one is more mixed.

I would split it.

Some of it is true campaign/research support.
Some of it is more like scorer asset-building / exploratory evaluation.

So I would probably separate:
- campaign-facing scoring experiment assets
- scorer research/build helpers

rather than moving the whole subtree intact.

### 6.4 LP loading under API data helpers
`src/rune_decrypter_prime/api/data_helpers.py` still looks like a temporary convenience location, not the final ownership point for LP/problem-source loading.

That strengthens the case for a distinct `problem_sources` ownership boundary.

---

## 7) What I would *not* do yet

Even though I agree with the structural direction, I would still avoid a big-bang tree move before three things are in place:

1. a clearer core `RunSpec` / config-runner contract
2. a single artifact/output policy owner
3. a small migration layer for old import/path surfaces

Reason:
- the current repo has many hardcoded path assumptions around `tools/benchmarks`
- tests, output paths, bootstrap scripts, and JSON examples all depend on those names
- moving first and redesigning later would create a lot of churn at once

So my recommended order is:
- define the target ownership model first
- add migration shims / path constants where needed
- then move the tree in a controlled pass

---

## 8) My concrete shape recommendation right now

If I had to sketch the likely v1.1-ish repo shape from today’s review, it would be roughly:

```text
src/
  rune_decrypter_prime/
    api/
    core/
    ciphers/
    keyops/
    scoring/
    solvers/
    telemetry/
    problem_sources/
    artifacts/

campaigns/
  community/
  periodic_sub_trans/

problem_sources/
  liber_primus/
  fixtures/

tutorials/
  v1/

tools/
  repo_tidy/
  sharing/
  migration/
  dev_helpers/
```

Possible naming variant:
- if you dislike `problem_sources/` at repo top level, then keep machine-facing source definitions under `src/rune_decrypter_prime/problem_sources/` and leave only user-facing fixtures/examples at repo top level.

That may actually be the cleaner option.

---

## 9) Final judgement from this pass

I agree with the spirit of your proposal.

My refinements are:
- move benchmark/community infrastructure out of `tools/`
- consider naming it `campaigns/`, not `benchmarks/`
- keep tutorials distinct from machine-facing problem-source definitions
- do not use one overloaded `solving/` folder if we can separate teaching, fixtures, and distributed experiment infrastructure more cleanly
- make the core config runner the bridge that ties these surfaces together

So my current architectural picture is now:

- **core library** owns execution and types
- **campaigns** own distributed experiment orchestration
- **problem sources** own reusable inputs and locators
- **tutorials** own human-facing examples
- **tools** go back to being honestly auxiliary

That feels much closer to the repo the codebase is already trying to become.
