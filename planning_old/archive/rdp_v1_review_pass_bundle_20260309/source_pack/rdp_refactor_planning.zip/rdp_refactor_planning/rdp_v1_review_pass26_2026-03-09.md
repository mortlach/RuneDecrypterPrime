# RDP v1 review pass 26 — internal policy enforcement and boundary drift

Date: 2026-03-09

## Scope of this pass

This pass focuses on the internal policies that should stop the codebase drifting over time:
- strict core vs forgiving boundary
- enums vs raw strings in core-facing config
- live guardrail tests vs aspirational guardrails
- console/output behaviour as a policy, not local habit

This is still a static engineering review against the local `src/tests/tools` bundle.

---

## Main conclusion

The repo now has the **right policy direction**, but it is still only **partly enforced**.

The intended rule looks like this:
- boundary surfaces may accept convenient strings or loose inputs
- core should normalise once, then stay strict
- guardrail tests should make important rules hard to regress

That shape is already visible in parts of the codebase.

But some of the most important config classes still blur boundary and core responsibilities, which means the anti-drift story is not yet fully real.

---

## Strongest concrete findings

### 1) `CipherConfig` accepts `keyops_family: KeyOpsFamily | str`, but does not normalise it

`CipherConfig.__post_init__()` normalises `device` and `encoding_dir`, but it does **not** normalise `keyops_family`.

That matters because:
- the type annotation says both enum and string are accepted
- the rest of the repo already has `ensure_keyops_family(...)`
- active cipher code expects `KeyOpsFamily` discipline elsewhere

So this is a real boundary/core drift hole:
- boundary-forgiving input is accepted
- but core config does not immediately collapse it into the canonical enum

This is exactly the kind of thing the “strict core” policy is supposed to prevent.

### 2) `ScoringConfig` is becoming a policy sink inside core

`ScoringConfig` now carries a very large number of scorer and benchmark-local policy knobs, many of them as raw strings or `Literal[...]` tokens inside a core-facing config object.

Examples include:
- `smoothing`
- `oov_policy`
- `hamming_direction_mode`
- `span_hamming_mode`
- `span_hamming_bucket_policy`
- `span_hamming_combine_mode`
- `span_hamming_gate_fail_policy`
- `span_hamming_lm_profile_source`

To be clear: the problem is **not** that these options exist.
The problem is that a growing amount of benchmark-local or scorer-role intent is being encoded directly in one widening core config object via raw policy tokens.

That weakens the desired policy split:
- boundary/config runner should interpret flexible user specs
- core should receive a narrower, more canonical set of enums/value objects

This does not need a rewrite now, but it is one of the clearest long-term anti-drift risks in the whole repo.

### 3) One of the most useful guardrail tests is currently not enforced

`tests/guardrails/test_only_scoring_can_say_fwd_rev.py` still has its main assertion commented out.

So the repo has a guardrail file for an important policy, but that rule is not actually live.

That is a valuable finding because it shows the difference between:
- “we believe in this rule”, and
- “the tree really enforces this rule”.

For v1, important anti-drift rules need to be in the second category.

### 4) `RunConfig` still mixes boundary forgiveness and core storage

`RunConfig` still accepts string unions in core-facing fields such as:
- `scorer_name: ScorerName | str`
- `optimizer_name: SolverName | str | None`

and normalises them in `__post_init__()`.

That is survivable, but it means the core config layer is still doing boundary cleanup work rather than receiving already-canonical values.

There is also another sign of transitional drift in `RunConfig.asdict()`:
- it serialises the solver object
- then forcibly sets `optimizer_name = None`
- and `optimizer_params = None`

That suggests the run contract is still carrying historical compatibility shape rather than one fully converged serialisable form.

### 5) Console/output policy is still more convention than contract

The codebase already shows that stdout/printing needs the same kind of anti-drift policy as enums and paths.

From the local bundle:
- `src/rune_decrypter_prime` still contains direct `print(...)` usage
- `tools/benchmarks` contains a lot more
- benchmark/runtime output remains heavily `print(...)`-driven rather than going through one consistent console/report surface

This reinforces the earlier output/privacy review passes:
- file writing
- JSON / JSONL
- trace events
- console status output

should all be treated as policy-owned behaviour, not local habit.

---

## Architectural reading

The repo is now very clearly telling us this:

**The next stage is not “add more features everywhere”.**
It is:
- make core strictness real
- keep boundary forgiveness at the edges
- make important rules live in tests
- stop large config objects from becoming policy dumping grounds
- unify output/console behaviour under one owner

That fits the broader review direction so far:
- convergence
- hardening
- simplification
- anti-drift ownership

---

## Recommended internal policy set for v1

I would now write these as explicit project rules.

### Policy A — strict core, forgiving boundary
- API/UI/config-file inputs may accept strings and aliases.
- Normalisation happens once at the boundary.
- Core config and runtime objects should use enums or canonical value objects only.

### Policy B — no raw policy tokens in core unless they are truly core concepts
- If a token only matters to a benchmark role or config runner interpretation, keep it out of the core runtime object.
- Prefer small enums/value objects over widening string bags.

### Policy C — every important anti-drift rule gets a live guardrail test
- No commented-out main assertions.
- No “placeholder guardrail” files that do not actually fail on drift.

### Policy D — one output/artifact owner
- JSON
- JSONL
- hashing
- path redaction
- identity redaction
- telemetry dump placement
- console/report output policy

These should not be reimplemented locally.

### Policy E — serialisable public contracts should converge
- One clear solve/run spec shape.
- One clear result shape.
- Avoid historical compatibility fields lingering as null placeholders once the new contract exists.

---

## Keep / merge / tighten view from this pass

### Keep
- the general enum-centred direction in `core/types.py`
- forgiving boundary normalisation in API-facing layers
- guardrail tests as a real tool, not just unit tests

### Tighten
- normalise `keyops_family` inside `CipherConfig`
- decide which current `ScoringConfig` policy tokens truly belong in core
- restore the live assertion in `test_only_scoring_can_say_fwd_rev.py`
- tighten `RunConfig` toward one cleaner serialisable contract

### Merge into broader hardening work
- console/print policy into the output/artifact contract work
- enum/strictness work into the core config-runner design
- scorer-role separation into the `ScoringConfig` convergence work

---

## Bottom line

The codebase already knows what “good discipline” looks like.
The issue now is that some of the most important rules are still:
- unevenly enforced,
- half boundary / half core,
- or present as conventions rather than hard contracts.

That is good news for v1.
It means the repo does not mainly need more invention here.
It needs stronger enforcement of the design philosophy it already prefers.
