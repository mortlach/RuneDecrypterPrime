# RDP v1 review pass 13 — campaign unification and config-driven runs

Date: 2026-03-09
Reviewer: ChatGPT
Scope: holistic campaign direction after user clarification that no-WLI should be treated as part of the wider campaign rather than a separate side effort.

## Updated framing

The earlier review language risked treating the community campaign and the no-WLI work as too separate.
That is not the best final framing.

A better view is:
- there should be **one experiment system**
- it should support **multiple problem classes** and **multiple runner policies**
- no-WLI should be a **first-class campaign mode**, not an awkward bolt-on
- WLI and no-WLI should share as much of the experiment, fixture, result, and analysis machinery as possible
- only the genuinely different pipeline/scoring/search policy should vary by mode

This fits the actual direction of the code better than a strict split.
The current repo already contains pieces of this:
- community campaign schema/profile machinery
- no-WLI fixture-matrix and schedule tooling
- API-side typed specs
- benchmark-side profile overrides and schedule application

So the problem is not “invent a whole new architecture”.
The problem is “converge the current pieces into one coherent experiment model”.

## Revised target architecture

### 1. One campaign umbrella

Treat the campaign as a way to run controlled, distributed experiments over:
- fixture set
- problem family
- order/cipher family
- period/columns grid
- runner policy
- scorer policy
- solver policy
- seed/replicate policy
- analysis/report bundle

In that model:
- WLI is one problem family / evidence regime
- no-WLI is another problem family / evidence regime
- both are part of the same campaign framework

### 2. Separate “experiment contract” from “pipeline internals”

Right now the benchmark layer still pushes a lot of pipeline-local details around as mutable dicts and module globals.
For v1, the main unification move should be to introduce a clearer boundary:

- **Campaign config / job spec**
  - what experiment do we want to run?
- **Runner policy**
  - how should this class of problem be attacked?
- **Scorer role spec**
  - which scorers are used at which stages and for which reporting side channels?
- **Pipeline compiler / adapter**
  - translate the above into the concrete runtime objects and old pipeline knobs

That lets you add new scorer methods and experiment styles without dumping every benchmark-local concept into core scorer config.

### 3. Make no-WLI a first-class variant, not a separate tree in spirit

I now think the right target is:
- one campaign vocabulary
- one job-manifest vocabulary
- one result-row vocabulary
- one artifact/output policy
- one fixture model
- one report model
- multiple runner variants underneath

So no-WLI should sit under the same campaign umbrella but may still keep its own internal runner package because the search behaviour can differ materially.

That means:
- share the outer experiment framework
- specialise the inner run policy only where necessary

## Config-driven runs: this is a good feature

I agree that a config-driven runner is useful and worth adding even at this stage.
In fact, I think it is one of the few new features that directly helps v1.

Why it is worth doing:
- it reduces hidden module-state coupling
- it makes community runs repeatable
- it makes distributed experimentation easier
- it gives a cleaner bridge from API to benchmark runner
- it becomes the natural place to express WLI vs no-WLI, scorer roles, profile choice, and fixture choice
- it helps prove that the system is a real instrument, not a collection of scripts

## But the right version is not “all knobs in one giant YAML”

I would strongly avoid one flat mega-config with every internal knob exposed.
That would be powerful but hard to reason about and easy to misuse.

The better structure is layered.

### Proposed config layers

#### Layer A — ProblemSpec
What is being solved?
- ciphertext reference / inline source
- fixture id or explicit text source
- period/columns/order if known or constrained
- WLI / no-WLI mode
- any interruptor or domain-specific constraints

#### Layer B — ExperimentSpec
How should this experiment be run?
- campaign id
- profile id
- run seeds / replicates
- schedule id
- backend choice
- time/budget controls
- output bundle policy

#### Layer C — RunnerPolicySpec
How should the runner behave?
- stage gating policy
- carry-through policy
- breadth policy
- basin exploration policy
- stage implementation choices
- scorer role bindings

#### Layer D — ScorerRoleSpec
What scorer fills each role?
- stage1_search
- stage2_search
- stage3_search
- basin_judge
- span_report
- word_ngram_report
- optional oracle / guard roles

These should not be arbitrary dicts. They should be typed and validated.
They can still compile down to current dict-based runtime configs for now.

## The best near-term design move

Do **not** try to replace the whole API or whole benchmark system at once.
Instead add a thin config-driven orchestration layer that compiles into current machinery.

In practical terms:
1. define one typed run spec for benchmark/community execution
2. let JSON be the canonical on-disk format for v1
3. keep YAML optional as a front-end convenience only if really needed
4. compile that run spec into:
   - profile lookup
   - schedule application
   - scorer role configs
   - runner mode selection
   - output paths / artifact manifest
5. run through the existing pipeline adapters

That is the safest path because it improves consistency without requiring a rewrite.

## Where the current code is already pointing this way

The existing code already suggests this direction:
- community profile catalog and knob validation
- campaign config examples and schemas
- no-WLI fixture matrix planning and schedule logic
- API typed specs for run/cipher/solver side inputs
- benchmark tests that validate config application and schema presence

So the config-runner idea is not alien to the repo.
It is the next natural convergence step.

## Recommended v1 campaign model

I would define the campaign as:

**A reproducible distributed experiment framework for hard cipher problems, where a job is a parameterised solving run against a known fixture or problem instance, and where different participants can execute different controlled configurations and return comparable artifacts.**

That means the campaign is not just a benchmark scoreboard.
It is also:
- parameter search
- robustness checking
- regression detection
- solver/scorer tuning
- comparative evidence gathering

That fits your “scientific instrument” framing.

## What should be shared between WLI and no-WLI

Shared:
- fixture definitions
- campaign/job schemas
- profile catalogues
- result-row contracts
- artifact/output policy
- config fingerprinting
- integrity / hashing rules
- schedule identifiers
- report format
- organiser aggregation flow

Potentially different:
- pipeline mode defaults
- scorer role bindings
- stage transitions / gating
- basin policy
- stage3 exploration policy
- some solver choices

## Strong recommendation on scoring structure

I do not think the best answer is to keep adding more benchmark-local flags directly into `ScoringConfig`.
That will blur responsibilities.

Instead:
- keep core scoring config focused on what a scorer needs to score
- move benchmark intent into scorer role specs / runner policy specs
- compile the role specs into concrete scorer configs at the benchmark boundary

This will make the newer span-hamming and word-ngram work easier to reason about.

## Concrete v1 additions I would support

I would support these new additions even during hardening:

1. **Config-driven run spec**
   - JSON-first
   - typed and validated
   - compiles into current runner/API

2. **Unified campaign/job contract for WLI and no-WLI**
   - same outer schema
   - different runner/scorer policies underneath

3. **Scorer role registry**
   - explicit named roles
   - avoids copied dict configs
   - makes span/word-ngram integration clearer

4. **Unified artifact policy**
   - one owner for JSON/JSONL/canonical hashing/path redaction

These are not “more alpha features”.
They are convergence infrastructure.

## Things I would avoid before v1

- a giant benchmark rewrite
- moving every benchmark knob into the public API
- YAML as the only canonical format
- flattening WLI and no-WLI so much that meaningful policy differences disappear
- continuing to grow config dict copy-paste patterns
- introducing more hidden auto-discovery defaults

## Current judgement

Your updated framing is stronger than the earlier split framing.

The campaign should be thought of holistically as one distributed experiment system.
No-WLI should be part of that system.
The way to get there is not “one runner for everything” but “one campaign contract with multiple specialised runner policies under it”.

The config-driven runner idea is good and worth doing, provided it is introduced as a typed adapter layer rather than a giant free-form bag of knobs.

## Suggested next review focus

Next, review should turn this into a concrete design package:
- target schema for config-driven run specs
- ownership split between campaign config, runner policy, and scorer role specs
- migration plan from current profile/override dicts to explicit typed structures
- minimum test set to lock that new contract
