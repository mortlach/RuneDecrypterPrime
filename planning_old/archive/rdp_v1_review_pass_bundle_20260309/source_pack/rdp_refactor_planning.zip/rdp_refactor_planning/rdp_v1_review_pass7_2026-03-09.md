# RDP v1 engineering review - pass 7 (scoring wiring, report plumbing, defaults)

Date: 2026-03-09
Branch surface reviewed: `experimental/merge` (surfaced via `repo_links.csv`)

## Scope of this pass

This pass focused on the exact area you flagged as likely to hide real release risk:

- score configuration shape
- span-hamming and word-ngram runtime wiring
- scorer-report plumbing
- default discovery / pass-through behaviour in no-WLI benchmark code

The aim here was not to check whether the new scorer features merely exist. It was to check whether they are wired in a way that is coherent, intuitive, and release-safe.

## Main findings

### F1. Word-ngram judge is integrated into the core scorer, but benchmark-side construction is still too implicit

**What I checked**

- `ScoringConfig` now explicitly carries word-ngram judge fields.
- `RuneScorer` reads those fields, opens the SQLite judge, and publishes word-ngram telemetry/stats.
- no-WLI benchmark code builds a separate `scorer_word_ngram_report_runtime`.

**What is good**

The feature is not just a benchmark-side bolt-on. The core scorer really does know about:
- `word_ngram_judge_enabled`
- sqlite path
- alpha / miss logp / min positions / thresholds

and it publishes word-ngram fields into scorer telemetry/stats.

That is a good sign for v1, because it means the feature is in the runtime contract rather than living only in ad hoc benchmark scripts.

**What is not good**

The no-WLI runtime still constructs the report scorer by copying a broader base scorer config and then adding judge fields on top.

That means the report scorer is not built from a narrow, dedicated “word-ngram judge report” contract. It inherits whichever other scorer knobs were already present in the chosen base config.

In practice, that currently means the report scorer can inherit span-hamming settings from the basin-judge profile.

**Why this matters**

This is not just a style issue. It makes it harder to answer simple release questions such as:

- Is the report scorer intended to depend on calibrated span-hamming state?
- Which knobs actually matter for the report scorer?
- Can two benchmark modes accidentally change the report scorer because they changed an unrelated base scorer?

For v1, this should be made explicit.

**Judgement**

- Keep the core word-ngram scorer integration.
- Simplify the benchmark-side report-scorer construction.
- Give the report scorer its own narrow config builder, or at least explicitly strip inherited fields that are not part of the report contract.

Severity: **high**

---

### F2. Word-ngram report extraction still relies on mutable scorer state rather than an explicit returned report object

**What I checked**

The report helper scores one plaintext at a time via `score_plaintexts_chunked(...)`, then reads `scorer_runtime.last_stats()` and builds the report payload from that state.

The current tests explicitly lock this behaviour.

**Important nuance**

This is less dangerous than it first looked, because:
- the helper forces `chunk_size=1`
- it passes only one plaintext at a time
- the top-K helper also loops row by row

So today, this is not obviously mixing multiple candidates in one shared batch call.

**But it is still an awkward contract**

The report helper is effectively saying:

1. score this candidate
2. assume the scorer’s mutable `last_stats()` now corresponds to that same candidate
3. reconstruct the report from that mutable state

That is workable, but it is not a clean contract. It would be clearer if the scorer exposed a dedicated per-candidate report/result object for this use.

**Why this matters**

The current pattern is harder to reason about when you later change batching, parallelism, or internal scorer caching.

Severity: **medium**

---

### F3. `scorer_report` is real and useful, but still not integrated as a general benchmark-side output contract

**What I checked**

- `ScorerReport` and `build_scorer_report(...)` are real structured helpers.
- The common benchmark sidecar helper appends JSONL rows containing a structured report and context.
- The inspected smoke test proves the Gate-0 preflight path writes one JSONL row.
- In the inspected no-WLI files, `scorer_report` is otherwise only embedded inside `word_ngram_report` payloads.

**What this means**

The `scorer_report` machinery is not fake or dead. It is genuinely usable.

But from the surfaces inspected in this pass, it is still **not** the single consistent reporting contract across the benchmark system.

Right now it looks more like:
- a proper helper type
- a preflight sidecar in the common benchmark path
- an embedded nested payload in the word-ngram report helper

That is useful, but it is still partial.

**Why this matters**

For v1, I would want one clear answer to:

> When a benchmark wants a structured scorer report, where does it go and in what shape?

At the moment, the answer still depends on which path you are in.

Severity: **medium-high**

---

### F4. no-WLI word-ngram defaults can change automatically depending on what SQLite asset happens to exist most recently

**What I checked**

The no-WLI runner defaults auto-discover a word-ngram SQLite asset from:
- `assets/scoring/...`
- `assets_packed/...`
- `output/tools/benchmarks/scoring/word_ngrams_sqlite_assets/...`

and then choose the candidate with the newest modification time.

If one is found, word-ngram reporting is enabled by default.

**Why this matters**

This is convenient during development, but it is too implicit for a release-facing default path.

Two working copies of the same branch can silently pick different assets, and therefore get different default benchmark behaviour, purely because file modification times differ.

That is a reproducibility and explainability problem.

The existing tests cover:
- enable when present
- disable when absent
- use repo root rather than current working directory

Those are good tests, but they do not lock the release-risky part: mtime-based winner selection.

Severity: **high**

---

### F5. Core scorer integration between calibrated span-hamming and word-ngram judge is more coupled than the benchmark naming suggests

**What I checked**

In `RuneScorer`, the word-ngram judge report depends on `selected_intervals` coming from span-hamming scoring state.

If there are no selected intervals, the judge stays inactive with `no_selected_intervals`.

Also, when a word-ngram judge is enabled, the scorer can force span-hamming debug intervals on so those intervals exist.

**What this means**

This is a coherent design if the intended meaning is:

> word-ngram judge is a report over exact-match word segments extracted from span-hamming-selected intervals

But it also means the judge is not an independently-evaluated text-wide report. It is tied to the span-hamming extraction path.

That is probably the right design for the feature, but the benchmark code and naming should make this relationship much more obvious.

Otherwise it is easy to believe the judge is a general side-channel over plaintext when in fact it is a span-dependent report.

Severity: **medium-high**

---

### F6. Scorer report details are duplicated across several nested shapes

**What I checked**

For word-ngram reporting, the code currently produces at least three related representations:

1. raw `word_ngram_judge_*` fields in the payload
2. a nested `scorer_report`
3. within that nested report, a `details.word_ngrams` section derived from the same fields

Then the iteration finaliser copies a selected subset into `inst_row` and stores the full report structures into artifact payloads.

**Why this matters**

This is a common sign that the reporting model has not yet settled.

It is not wrong, but it does create:
- more file size
- more places for drift
- more decisions for future callers about which field shape is canonical

For v1, I would choose one canonical report structure and make any flattened convenience fields a clearly secondary projection.

Severity: **medium**

---

## Overall judgement from this pass

The good news is that the newer scorer work is **more real than superficial**:

- word-ngram judge is in core scorer config
- it is active in the scorer runtime
- span-hamming, LM-extension, and judge telemetry all exist in the scorer
- `scorer_report` is a real structured helper rather than a placeholder

The bad news is that the **benchmark-side integration contract is still too implicit**:

- inherited base configs rather than narrow role-specific configs
- auto-discovered default assets affecting behaviour
- partial rather than end-to-end `scorer_report` adoption
- duplicated report shapes
- naming that understates the coupling between span-selected intervals and word-ngram reporting

That is exactly the kind of state I would expect late in alpha work. It is also exactly the kind of thing I would want to clean up before calling the project v1-ready.

## Priority for the v1 programme

### Must-fix before v1

1. Stop auto-selecting word-ngram SQLite assets by newest mtime in release-facing defaults.
2. Replace the inherited-base-config pattern for `word_ngram_report` with an explicit narrow config contract.
3. Decide whether `scorer_report` is a general benchmark output contract or just a helper, then wire it consistently.

### Should-fix before v1

4. Make the span-hamming → selected-intervals → word-ngram-judge dependency explicit in naming/docs/config roles.
5. Reduce duplicate report shapes so one structure is canonical.
6. Add at least one stronger end-to-end benchmark test covering the new scorer/report plumbing together.

### Later / post-v1 acceptable if needed

7. Further tidy of report payload volume and helper/module count.
8. Broader repo-wide naming cleanup once behaviour is locked.

## What would help me review faster

A separate external “deep research” pass is **not** the main bottleneck here.

What would help more than that is one of these:

- a full repo ZIP pinned to the merge branch
- or a smaller code-only ZIP for `src/`, `tools/benchmarks/`, and `tests/`
- or a manifest with commit SHA plus direct local copies of the benchmark/scoring tree

That would let me do broader cross-file tracing without GitHub/raw fetch friction.

So yes, more depth would help, but the best kind of “deep” help here is **better repo access**, not outside research.
