# RDP v1 review – pass 28 (solver / progress / telemetry seam)

## Scope of this pass

This pass focuses on the remaining high-value static review area before first collation:
- solver internals
- progress and console behaviour
- solver stop reasons and result shape
- telemetry/result contracts at the engine boundary
- whether the current code already wants a narrow `SolverReport`

The local review bundle remains a good static review surface for this work, but this is still a static engineering review rather than a full runtime certification.

---

## Main findings

### 1) The engine boundary is still too thin to be the final canonical run-result contract

`core/engine/engine.py` wraps solver execution with `run_start` / `run_end` telemetry and returns the solver’s `Solution`, but the engine-level `result_payload` is very small: essentially just score plus optional stop reason.

That means a lot of useful solve summary data remains scattered across:
- the returned `Solution`
- solver span telemetry
- run-level telemetry envelope
- benchmark-side remapping code

This is a strong sign that the repo is ready for a narrow `SolverReport` summary object built from the final solve state, rather than forcing downstream code to reconstruct solver meaning from multiple places.

### 2) Stop-reason ownership is still split and stringly

Core solver code stores stop reasons as plain strings, for example:
- `target_score`
- `no_improve_<N>`
- `stall_slip_limit_<N>`
- `test_key`
- `all_rejected_by_hard_crib`

The community benchmark layer then maps these into its own result-schema stop reasons. So the current system works, but stop-reason meaning is not owned in one place.

This is not just a cosmetic issue. It creates three separate vocabularies:
- solver-internal stop reasons
- core solution stop reasons
- campaign/community result stop reasons

For v1, this wants tightening. The clean route is:
- keep solver-local raw reason strings if useful for debugging
- add a narrower canonical solve/result stop category at the report boundary
- let campaign result mapping build on that rather than scraping raw solver strings directly

### 3) Progress / console behaviour is still local and print-driven

`SolverBase` still prints progress directly with `print(...)` from `_print_progress_line(...)`.

At the same time, there is a `solvers/progress/` package containing:
- `logger.py`
- `mixin.py`

but those files currently look like placeholders rather than an active shared progress system. I did not find surfaced uses of `ProgressMixin`, `SimpleLogger`, or `TQDMAdapter` in the local bundle.

So the repo currently has two stories at once:
- real progress behaviour lives in solver-local printing
- a not-really-live progress abstraction exists beside it

That is exactly the sort of drift that should be resolved before v1.

### 4) The preferred module-logger path is still not truthful

`io/logging_adapter.py` says module-level logging should prefer `run_logger` if available, but the shapes it tries to call do not match the current `RunLogger` API:
- it tries `run_logger.get_logger(name)`
- current `get_logger()` takes no name
- it tries `run_logger.RunLogger(name)`
- current `RunLogger(...)` accepts keyword args like `out_dir=` and `echo=` rather than a module name

So this “prefer run logger” path is not really live in the current code shape.

That matters because it reinforces the earlier output-policy finding: there is still no single truthful owner for screen logging, JSONL events, and module logging.

### 5) `api/pipeline.py` still hardcodes engine verbosity rather than treating it as part of the run contract

`execute_run(...)` still builds:

```python
EngineConfig(..., verbose=True, ...)
```

This matches an earlier pattern we saw: the top-level run path is close to declarative, but not fully declarative yet. A future core config runner should own this kind of runtime knob explicitly rather than inheriting local defaults from the pipeline implementation.

### 6) Telemetry tests are good on structure, but weaker on summary semantics

The surfaced tests do a useful job on:
- minimum telemetry presence
- canonical timing keys
- pipeline block presence and stability
- telemetry-off dump guard

That is a good foundation.

What still looks under-tested from a v1 architecture point of view:
- canonical solve/stop summary semantics
- JSONL event privacy / path redaction in the actual event stream
- whether the final solve result exposes a stable enough compact summary for downstream consumers
- whether progress/console behaviour is governed by one policy

### 7) The current state strengthens the case for `ScorerReport` + `SolverReport`, not report sprawl

This pass makes the earlier report discussion clearer.

The system is not missing “more telemetry”. It is missing a better stable summary boundary.

So I still think the right shape is:
- telemetry = rich event bag
- `ScorerReport` = compact scorer summary
- `SolverReport` = compact solve summary
- artifact/output policy = one owner for JSON / JSONL / hashing / redaction / placement

That would reduce benchmark-side scraping and make APIs, campaigns, and future GUIs easier to build against.

---

## Current judgement after this pass

The repo is now very close to the point where continued gathering will give diminishing returns.

My current assessment is:
- roughly **80–85%** of the useful static engineering review is now done
- roughly **15–20%** remains before first collation is the right move

The remaining high-value review slices are now:
1. final architecture sweep across boundary/examples/tutorials/config-runner readiness
2. script/tooling/repo-shape last pass
3. one consolidation pass specifically on duplicate helpers / shim debt / safe cleanup candidates

After that, I think we should switch from gathering to:
- collation
- grouping into must-fix / should-fix / later
- checking against intended architecture and policy rules
- proposing the v1 hardening programme

---

## Strong recommendations from this pass

### Must clarify before v1
- one canonical owner for solve-summary semantics
- one canonical story for progress / console output
- one truthful module-logger story
- one canonical policy for JSONL event path/privacy handling

### Strongly recommended design direction
- keep telemetry as events
- keep `ScorerReport`
- add a narrow `SolverReport`
- do not replace telemetry with reports
- do not let campaign code keep scraping raw solver state and ad hoc files where a typed run/report result should exist

---

## Bottom line

This pass makes the holistic direction stronger, not weaker.

RDP does **not** mainly need more feature invention here.
It needs a cleaner centre for:
- solve results
- progress/output policy
- report summaries
- canonical stop semantics

That fits the wider picture from the review so far: the project now looks like a **convergence and hardening** job, not an exploration job.
